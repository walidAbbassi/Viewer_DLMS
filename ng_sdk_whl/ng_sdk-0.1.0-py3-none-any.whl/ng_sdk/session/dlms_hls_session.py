import os
from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.configuration.config_manager import ConfigModuleProxy
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.constant.session.constant import CONFORMANCE, CLIENT_MAX_RECEIVE_PDU_SIZE, HLS_RANDOM_LENGTH
from ng_sdk.error.security_exception import SecurityException, SecurityError
from ng_sdk.frame_builder.dlms.acse.aare_apdu import AARE
from ng_sdk.frame_builder.dlms.acse.aarq_apdu import AARQ
from ng_sdk.frame_builder.dlms.acse.models.association_result import AssociationResultEnum
from ng_sdk.frame_builder.dlms.acse.models.authentication_functional_unit import AuthenticationFunctionalUnit
from ng_sdk.frame_builder.dlms.acse.models.authentication_value import AuthenticationValue
from ng_sdk.frame_builder.dlms.acse.models.conformance import Conformance
from ng_sdk.frame_builder.dlms.acse.models.initiate_request import InitiateRequest
from ng_sdk.frame_builder.dlms.acse.models.initiate_response import InitiateResponse
from ng_sdk.frame_builder.dlms.acse.models.object_identifier import ObjectIdentifier
from ng_sdk.frame_builder.dlms.acse.rlre_apdu import RLRE
from ng_sdk.frame_builder.dlms.acse.rlrq_apdu import RLRQ
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_normal import DLMSActionRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.action.response.dlms_action_response_normal import DLMSActionResponseNormal
from ng_sdk.frame_builder.dlms.xdlms.data_type.octet_string import OctetStringData
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.security.security_constant import DlmsSecurityPolicy, DlmsCipheringType
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.session.dlms_session import DLMSSession
from ng_sdk.session.hls_mechanism import HlsMechanism
from ng_sdk.util.bytes_util import to_bytes_from_hexish
from ng_sdk.util.tag_length_value import TagLengthValue

logger = get_logger()


class DLMSHlsSession(DLMSSession):

    def __init__(self, communication: AbstractCommunication, security_context: SecurityContext,
                 configuration: ConfigModuleProxy):
        super().__init__(configuration, communication)
        self.__security_context = security_context
        self.__usr_inf = None
        self._mod = {LoggingConstants.MODULES_NAME: "DLMSHlsSession"}  # module tag for logs

    def open(self):


        if not self.communication.is_opened:
            self.communication.open()

        pre_established = getattr(self.configuration.session, "pre_established", False)
        if not isinstance(pre_established, bool):
            pre_established = False
        if pre_established:
            logger.info("Association already established", **self._mod)
            self.is_established = True
            return
        ciphering_type = self.configuration.security.ciphering_type
        try:

            self.configuration.security.ciphering_type = DlmsCipheringType.GLOBAL_CIPHERING
            logger.info("Setup Association", **self._mod)  # pass one
            security_level = self.configuration.security.security_level
            hls_mechanism = HlsMechanism[security_level.name]
            if not isinstance(self.configuration.session.initiate_request.proposed_conformance, ConfigModuleProxy):
                conformance = Conformance.from_bytes(self.configuration.session.initiate_request.proposed_conformance)
            else:
                conformance_kwargs = {k: self.configuration.get("session", "initiate_request.conformance." + k, v) for k, v
                                      in
                                      CONFORMANCE.items()}
                conformance = Conformance(**conformance_kwargs)
            client_max_receive_pdu_size = self.configuration.session.buffer_size

            if isinstance(client_max_receive_pdu_size, ConfigModuleProxy):
                client_max_receive_pdu_size = CLIENT_MAX_RECEIVE_PDU_SIZE
            logger.debug("Client max receive pdu size " + str(client_max_receive_pdu_size), **self._mod)
            dedicated_key = None
            if self.configuration.session.initiate_request.use_dedicated_key == True:
                if self.configuration.session.initiate_request.random_dedicated_key == True:
                    if self.configuration.security.security_suite == 2:
                        self.configuration.security.key.dedicated_key = os.urandom(32)
                    else:
                        self.configuration.security.key.dedicated_key = os.urandom(16)
                dedicated_key=self.configuration.security.key.dedicated_key
            usr_inf = InitiateRequest(proposed_conformance=conformance,
                                      client_max_receive_pdu_size=client_max_receive_pdu_size,
                                      dedicated_key = dedicated_key)
            self.__usr_inf = usr_inf
            oid = ObjectIdentifier(hls_mechanism)
            afu = AuthenticationFunctionalUnit(True)
            c_to_s = self.__generate_random()
            logger.debug("Generated CtoS: " + c_to_s, **self._mod)
            auv = AuthenticationValue(c_to_s)
            aarq = AARQ(application_context_name=ObjectIdentifier(Constant.LN_REFERENCING_WITH_CIPHERING),
                        user_information=usr_inf, sender_acse_requirements=afu, calling_authentication_value=auv,
                        mechanism_name=oid, calling_ap_title=self.configuration.security.system_title)
            use_dedicated_key = self.__security_context.configuration.session.initiate_request.use_dedicated_key
            self.__security_context.configuration.session.initiate_request.use_dedicated_key = False
            aarq_bytes = aarq.to_bytes(self.__security_context)
            logger.info("AARQ: " + aarq_bytes.hex().upper(), **self._mod)
            aare_bytes = self.communication.transceive(aarq_bytes)
            # pass 2
            logger.info("AARE: " + aare_bytes.hex().upper(), **self._mod)

            aare = AARE.from_bytes(aare_bytes, self.__security_context)
            self.__security_context.configuration.session.initiate_request.use_dedicated_key = use_dedicated_key
            if aare.result.result == AssociationResultEnum.ACCEPTED:
                logger.info("Association Accepted", **self._mod)
                if isinstance(aare.user_information.content, InitiateResponse):
                    self.configuration.session.server_max_receive_pdu_size = aare.user_information.content.server_max_receive_pdu_size
                    self.configuration.session.conformance = aare.user_information.content.negotiated_conformance.to_bytes().hex().upper()

                s_to_c = aare.responding_authentication_value.password
                logger.debug("StoC: " + s_to_c, **self._mod)
                # pass 3
                data = self.prepare_pass_3_4_data(bytes.fromhex(s_to_c), c_to_s.encode('utf-8'))
                authentication_data = self.__security_context.authenticate(data)
                if getattr(self.__security_context.configuration.session.initiate_request,
                                                            'use_dedicated_key', False):
                    self.configuration.security.ciphering_type  = DlmsCipheringType.DEDICATED_CIPHERING
                    self.configuration.security.frame_counter = 1
                reply_to_hls_authentication_request = DLMSActionRequestNormal(
                    self.configuration.session.hls_action.hls_action_class,
                    self.configuration.session.hls_action.hls_action_obis,
                    self.configuration.session.hls_action.hls_action_methode,
                    OctetStringData(value=authentication_data).to_bytes())

                logger.info("PASS3 request: " + reply_to_hls_authentication_request.to_bytes().hex().upper(), **self._mod)
                reply_to_hls_authentication_response_bytes = self.communication.transceive(
                    reply_to_hls_authentication_request.to_bytes(self.__security_context))
                tag, length, data = TagLengthValue.from_bytes(reply_to_hls_authentication_response_bytes)
                data = self.__security_context.decipher(data)
                logger.info(
                    "Pass4 response: " + data.hex().upper(),
                    **self._mod)
                data = data[2:]

                reply_to_hls_authentication_response = DLMSActionResponseNormal(data)

                if not reply_to_hls_authentication_response.is_success():
                    raise SecurityException(SecurityError.HLS_PASS_3_ERROR)
                # pass 4
                server_authentication = reply_to_hls_authentication_response.return_parameter.data.value
                server_authentication_pass4 = self.prepare_pass_3_4_data(bytes.fromhex(s_to_c), c_to_s.encode('utf-8'),
                                                                         True)

                logger.trace(
                    "Server Authentication " + server_authentication.hex().upper(),
                    **self._mod)
                if self.__security_context.is_authenticated(server_authentication_pass4, server_authentication):
                    self.is_established = True
                    logger.info("Setup Association successful", **self._mod)
                else:
                    raise Exception("Setup Association failed" )
                    logger.error("Setup Association failed", **self._mod)

            else:
                raise Exception("Setup Association failed: " + aare.result.result.name)
            self.configuration.security.ciphering_type = ciphering_type
        except Exception as e:
            self.configuration.security.ciphering_type = ciphering_type
            raise e

    def close(self):
        pre_established = getattr(self.configuration.session, "pre_established", False)
        if not isinstance(pre_established, bool):
            pre_established = False
        if not pre_established:
            # Send RLRQ (Release Request)
            rlrq = RLRQ()
            if self.__usr_inf is not None:
                rlrq.user_information = self.__usr_inf
            rlrq_bytes = rlrq.to_bytes(self.__security_context)
            logger.info("RLRQ: " + rlrq_bytes.hex().upper(), **self._mod)
            rlre_bytes = self.communication.transceive(rlrq_bytes)
            logger.info("RLRE: " + rlre_bytes.hex().upper(), **self._mod)
            rlre = RLRE.from_bytes(rlre_bytes,self.__security_context)

        self.is_established = False
        self.communication.close()

    def prepare_pass_3_4_data(self, s_to_c: bytes, c_to_s: bytes, is_pass_4=False) -> bytes:
        security_level = self.configuration.security.security_level
        hls_mechanism = HlsMechanism[security_level.name]
        prepared_data = bytearray()
        if hls_mechanism == HlsMechanism.HIGH_ECDSA:
            system_title_client = self.configuration.security.system_title
            system_title_server = self.configuration.security.server_system_title
            if not system_title_client or not isinstance(system_title_client, (bytes, bytearray, str)):
                raise SecurityException(SecurityError.SYSTEM_TITLE_CLIENT_INCORRECT)
            if not system_title_server or not isinstance(system_title_server, (bytes, bytearray, str)):
                raise SecurityException(SecurityError.SYSTEM_TITLE_SERVER_INCORRECT)
            system_title_server = to_bytes_from_hexish(system_title_server)
            system_title_client = to_bytes_from_hexish(system_title_client)
            if not is_pass_4:
                # pass 3 ECDSA(SystemTitle-C || SystemTitle-S || StoC || CtoS)
                prepared_data.extend(system_title_client)
                prepared_data.extend(system_title_server)
                prepared_data.extend(s_to_c)
                prepared_data.extend(c_to_s)
                print("prepared_data", prepared_data.hex().upper())
            else:
                # pass 4 ECDSA(SystemTitle-S || SystemTitle-C || CtoS || StoC)
                prepared_data.extend(system_title_server)
                prepared_data.extend(system_title_client)
                prepared_data.extend(c_to_s)
                prepared_data.extend(s_to_c)

        elif hls_mechanism == HlsMechanism.HIGH_SHA256:
            hls_secret = self.configuration.security.key.hls_secret_key
            system_title_client = self.configuration.security.system_title
            system_title_server = self.configuration.security.server_system_title
            if not hls_secret or not isinstance(hls_secret, (bytes, bytearray, str)):
                raise SecurityException(SecurityError.HLS_SECRET_INCORRECT)
            if not system_title_client or not isinstance(system_title_client, (bytes, bytearray, str)):
                raise SecurityException(SecurityError.SYSTEM_TITLE_CLIENT_INCORRECT)
            if not system_title_server or not isinstance(system_title_server, (bytes, bytearray, str)):
                raise SecurityException(SecurityError.SYSTEM_TITLE_SERVER_INCORRECT)

            system_title_server = to_bytes_from_hexish(system_title_server)
            system_title_client = to_bytes_from_hexish(system_title_client)
            hls_secret = to_bytes_from_hexish(hls_secret)
            prepared_data.extend(hls_secret)
            if not is_pass_4:
                # pass 3 SHA-256(HLS_Secret || SystemTitle-C || SystemTitle-S || StoC II CtoS)
                prepared_data.extend(system_title_client)
                prepared_data.extend(system_title_server)
                prepared_data.extend(s_to_c)
                prepared_data.extend(c_to_s)
            else:
                # pass 4 SHA-256(HLS_Secret || SystemTitle-S || SystemTitle-C || CtoS || StoC)
                prepared_data.extend(system_title_server)
                prepared_data.extend(system_title_client)
                prepared_data.extend(c_to_s)
                prepared_data.extend(s_to_c)
        elif hls_mechanism == HlsMechanism.HIGH_GMAC:
            ak = self.configuration.security.key.authentication_key
            security_suite = getattr(self.configuration.security, "security_suite", 0)
            sc = DlmsSecurityPolicy.A + security_suite
            if ak is None or not isinstance(ak, (bytes, bytearray, str)):
                raise SecurityException(SecurityError.INVOCATION_COUNTER_INCORRECT)
            sc = sc.to_bytes()
            ak = to_bytes_from_hexish(ak)
            prepared_data.extend(sc)
            prepared_data.extend(ak)
            if not is_pass_4:
                # pass 3 GMAC(SC || AK || StoC)
                prepared_data.extend(s_to_c)
            else:
                # pass 4 GMAC(SC || AK || CtoS)
                prepared_data.extend(c_to_s)
        elif hls_mechanism == HlsMechanism.HIGH_SHA1 or hls_mechanism == HlsMechanism.HIGH_MD5:
            hls_secret = self.configuration.security.key.hls_secret_key
            if isinstance(hls_secret, (bytes, bytearray, str)):
                raise SecurityException(SecurityError.HLS_SECRET_INCORRECT)
            hls_secret = to_bytes_from_hexish(hls_secret)
            if not is_pass_4:
                # pass 3 MD5(StoC || HLS Secret) SHA-1(StoC || HLS Secret)
                prepared_data.extend(s_to_c)
            else:
                # pass 4 MD5(CtoS || HLS Secret) SHA-1(CtoS || HLS Secret)
                prepared_data.extend(c_to_s)
            prepared_data.extend(hls_secret)

        return prepared_data

    def __generate_random(self) -> str:
        hls_ctos = self.configuration.session.initiate_request.hls_ctos
        if isinstance(hls_ctos, ConfigModuleProxy):
            n = self.configuration.session.initiate_request.hls_ctos_size
            if isinstance(n, ConfigModuleProxy):
                n = HLS_RANDOM_LENGTH
            return ''.join(str(i % 10) for i in range(1, n + 1))
        return hls_ctos
