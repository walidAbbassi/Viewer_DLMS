from abc import ABC, abstractmethod
from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.configuration.config_manager import ConfigModuleProxy


class AbstractSession(ABC):
    def __init__(self,configuration:ConfigModuleProxy,communication:AbstractCommunication):
        self.is_established = False
        self.communication = communication
        self.configuration = configuration

    @abstractmethod
    def open(self):
        pass

    @abstractmethod
    def close(self):
        pass
