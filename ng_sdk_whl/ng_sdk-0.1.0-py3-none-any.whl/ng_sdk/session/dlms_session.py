from typing import Optional

from ng_sdk.configuration.config_manager import ConfigModuleProxy
from ng_sdk.constant.session.constant import CONFORMANCE, CLIENT_MAX_RECEIVE_PDU_SIZE
from ng_sdk.frame_builder.dlms.acse.aare_apdu import AARE
from ng_sdk.frame_builder.dlms.acse.aarq_apdu import AARQ
from ng_sdk.frame_builder.dlms.acse.models.association_result import AssociationResultEnum
from ng_sdk.frame_builder.dlms.acse.models.conformance import Conformance
from ng_sdk.frame_builder.dlms.acse.models.initiate_request import InitiateRequest
from ng_sdk.frame_builder.dlms.acse.models.initiate_response import InitiateResponse
from ng_sdk.frame_builder.dlms.acse.rlrq_apdu import RLRQ
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_normal import DLMSActionRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.action.response.dlms_action_response_normal import DLMSActionResponseNormal
from ng_sdk.frame_builder.dlms.xdlms.get.request.dlms_get_request_normal import DLMSGetRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.get.response.dlms_get_response_normal import DLMSGetResponseNormal
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.session.abstract_session import AbstractSession

logger = get_logger()
_mod = {LoggingConstants.MODULES_NAME: "DLMSSession"}


class DLMSSession(AbstractSession):

    def __init__(self, configuration, communication):
        super().__init__(configuration, communication)
        self._mod = dict(_mod)

    def open(self):

        if not self.communication.is_opened:
            self.communication.open()

        logger.info("Setup Association", **_mod)

        pre_established = getattr(self.configuration.session, "pre_established", False)
        if not isinstance(pre_established, bool):
            pre_established = False
        if pre_established:
            logger.debug("Pre-established Association", **_mod)
            self.is_established = True
            return

        if not isinstance(self.configuration.session.initiate_request.proposed_conformance, ConfigModuleProxy):
            print("conformance",self.configuration.session.initiate_request.proposed_conformance.hex())
            conformance = Conformance.from_bytes(self.configuration.session.initiate_request.proposed_conformance)
        else:
            conformance_kwargs = {k: self.configuration.get("session", "initiate_request.conformance." + k, v) for k, v
                                  in
                                  CONFORMANCE.items()}
            conformance = Conformance(**conformance_kwargs)
        client_max_receive_pdu_size = self.configuration.session.buffer_size
        if isinstance(client_max_receive_pdu_size, ConfigModuleProxy):
            client_max_receive_pdu_size = CLIENT_MAX_RECEIVE_PDU_SIZE
        usr_inf = InitiateRequest(client_max_receive_pdu_size=client_max_receive_pdu_size,
                                  proposed_conformance=conformance)
        aarq = AARQ(user_information=usr_inf)
        logger.info("AARQ: " + aarq.to_bytes().hex().upper(), **_mod)
        aare_bytes = self.communication.transceive(aarq.to_bytes())
        logger.info("AARE: " + aare_bytes.hex().upper(), **_mod)
        aare = AARE.from_bytes(aare_bytes)
        if aare.result.result == AssociationResultEnum.ACCEPTED:
            if isinstance(aare.user_information, InitiateResponse):
                self.configuration.session.conformance = aare.user_information.negotiated_conformance.to_bytes().hex().upper()
                if aare.user_information.server_max_receive_pdu_size is not None:
                    self.configuration.session.server_max_receive_pdu_size = aare.user_information.server_max_receive_pdu_size
                self.configuration.security.server_system_title = aare.responding_ap_title
            self.is_established = True
            logger.info("Setup Association successfully\n", **_mod)
        else:
            logger.error("Failed to open Association: " + aare.result.result.name + "\n", **_mod)

    def close(self, **kwargs):
        pre_established = getattr(self.configuration.session, "pre_established", False)
        if not isinstance(pre_established, bool):
            pre_established = False
        if pre_established:
            logger.debug("Pre-established Association", **_mod)
        else:
            # Send RLRQ (Release Request)
            rlrq_bytes = RLRQ().to_bytes()
            logger.info("RLRQ: " + rlrq_bytes.hex().upper(), **_mod)
            rlre_bytes = self.communication.transceive(rlrq_bytes)
            logger.info("RLRE: " + rlre_bytes.hex().upper(), **_mod)
        self.is_established = False
        self.communication.close()

    def get_frame_counter(self, configuration: Optional[ConfigModuleProxy] = None):
        if configuration is None:
            configuration = self.configuration
        if configuration.security.frame_counter_param.get_frame_counter:
            logger.info("==============================================", **_mod)
            logger.info("Retrieve Frame Counter from Meter", **_mod)
            logger.info("==============================================", **_mod)
            #src_addr = configuration.communication.client_addr
            #self.configuration.communication.client_addr = configuration.security.frame_counter_param.public_addr
            class_id = configuration.security.frame_counter_param.frame_counter_class
            obis_code = configuration.security.frame_counter_param.frame_counter_obis
            attribute_id = configuration.security.frame_counter_param.frame_counter_attribute
            if not configuration.security.frame_counter_param.action_frame_counter:
                logger.info(f" GET operation: class_id={class_id}, obis={obis_code}, attr={attribute_id}", **_mod)
                frame_counter_request = DLMSGetRequestNormal(
                    class_id,
                    obis_code,
                    attribute_id)
                frame_request = frame_counter_request.to_bytes()
                logger.info(f" Get Request: {frame_request.hex().upper()}", **_mod)
                frame_counter_response = self.communication.transceive(frame_request)
                logger.info(f" Get Response: {frame_counter_response.hex().upper()}", **_mod)
                frame_counter_response = DLMSGetResponseNormal(frame_counter_response[2:])
            else:
                logger.info(f" Action operation: class_id={class_id}, obis={obis_code}, attr={attribute_id}", **_mod)

                frame_counter_request = DLMSActionRequestNormal(
                    class_id,
                    obis_code,
                    attribute_id)
                frame_request = frame_counter_request.to_bytes()
                logger.info(f" Action Request: {frame_request.hex().upper()}", **_mod)
                frame_counter_response = self.communication.transceive(frame_request)
                logger.info(f" Get Response: {frame_counter_response.hex().upper()}", **_mod)
                frame_counter_response = DLMSActionResponseNormal(frame_counter_response[2:])
            if frame_counter_response.is_success():
                value = frame_counter_response.data.to_python()
                logger.info(f" Retrieved Frame Counter Value: {frame_counter_response.data} {value}", **_mod)
                if isinstance(value, list) and len(
                        value) > configuration.security.frame_counter_param.frame_counter_index:
                    self.configuration.security.frame_counter = value[
                                                                   configuration.security.frame_counter_param.frame_counter_index] + 1

                elif isinstance(value, int):
                    self.configuration.security.frame_counter = value + 1
                else:
                    self.configuration.security.frame_counter = 0
            #self.configuration.communication.client_addr = src_addr
            logger.info("==============================================", **_mod)
            logger.info("Retrieve Frame Counter from Meter - Completed", **_mod)
            logger.info("==============================================\n", **_mod)

        else:
            self.configuration.security.frame_counter = self.configuration.security.frame_counter_param.proposed_frame_counter_value
