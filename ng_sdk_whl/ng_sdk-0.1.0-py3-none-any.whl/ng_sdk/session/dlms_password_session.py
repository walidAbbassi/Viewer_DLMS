from ng_sdk.configuration.config_manager import ConfigModuleProxy
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.constant.session.constant import CONFORMANCE, CLIENT_MAX_RECEIVE_PDU_SIZE
from ng_sdk.frame_builder.dlms.acse.aare_apdu import AARE
from ng_sdk.frame_builder.dlms.acse.aarq_apdu import AARQ
from ng_sdk.frame_builder.dlms.acse.models.association_result import AssociationResultEnum
from ng_sdk.frame_builder.dlms.acse.models.authentication_functional_unit import AuthenticationFunctionalUnit
from ng_sdk.frame_builder.dlms.acse.models.authentication_value import AuthenticationValue
from ng_sdk.frame_builder.dlms.acse.models.conformance import Conformance
from ng_sdk.frame_builder.dlms.acse.models.initiate_request import InitiateRequest
from ng_sdk.frame_builder.dlms.acse.models.initiate_response import InitiateResponse
from ng_sdk.frame_builder.dlms.acse.models.object_identifier import ObjectIdentifier
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.session.dlms_session import DLMSSession

logger = get_logger()
_mod = {LoggingConstants.MODULES_NAME: "DLMSPasswordSession"}


class DLMSPasswordSession(DLMSSession):

    def open(self):
        if not self.communication.is_opened:
            self.communication.open()

        pre_established = getattr(self.configuration.session, "pre_established", False)
        if not isinstance(pre_established, bool):
            pre_established = False
        if pre_established:
            logger.info("Association already established", **self._mod)
            self.is_established = True
            return

        logger.info("Setup Association", **_mod)
        client_system_title = self.configuration.security.system_title
        password = self.configuration.session.initiate_request.password
        if not isinstance(self.configuration.session.initiate_request.proposed_conformance, ConfigModuleProxy):
            conformance = Conformance.from_bytes(self.configuration.session.initiate_request.proposed_conformance)
        else:
            conformance_kwargs = {k: self.configuration.get("session", "initiate_request.conformance." + k, v) for k, v
                                  in
                                  CONFORMANCE.items()}
            conformance = Conformance(**conformance_kwargs)
        client_max_receive_pdu_size = self.configuration.session.buffer_size
        if client_max_receive_pdu_size is None:
            client_max_receive_pdu_size = CLIENT_MAX_RECEIVE_PDU_SIZE
        usr_inf = InitiateRequest(proposed_conformance=conformance,
                                  client_max_receive_pdu_size=client_max_receive_pdu_size)
        afu = AuthenticationFunctionalUnit(True)
        oid = ObjectIdentifier(Constant.LOW_LEVEL_SECURITY)
        auv = AuthenticationValue(password)
        aarq = AARQ(user_information=usr_inf, sender_acse_requirements=afu, calling_authentication_value=auv,
                    mechanism_name=oid, calling_ap_title=client_system_title)
        logger.info("AARQ: " + aarq.to_bytes().hex().upper(), **_mod)
        aare_bytes = self.communication.transceive(aarq.to_bytes())
        aare = AARE.from_bytes(aare_bytes)
        logger.info("AARE: " + aare_bytes.hex().upper(), **_mod)
        if aare.result.result == AssociationResultEnum.ACCEPTED:
            if isinstance(aare.user_information, InitiateResponse):
                self.configuration.session.server_max_receive_pdu_size = aare.user_information.server_max_receive_pdu_size
                self.configuration.session.conformance = aare.user_information.negotiated_conformance.to_bytes().hex().upper()
            self.is_established = True
            logger.info("Setup Association successful", **_mod)
        else:
            logger.error("DLMS session not opened: " + aare.result.result.name, **_mod)
