from enum import StrEnum

from ng_sdk.constant.dlms.constant import Constant


class HlsMechanism(StrEnum):
    MAN_SPEC = Constant.HIGH_SECURITY
    HIGH_MD5 = Constant.HIGH_SECURITY_MD5
    HIGH_SHA1 = Constant.HIGH_SECURITY_SHA1
    HIGH_GMAC = Constant.HIGH_SECURITY_GMAC
    HIGH_SHA256 = Constant.HIGH_SECURITY_SHA256
    HIGH_ECDSA = Constant.HIGH_SECURITY_ECDSA