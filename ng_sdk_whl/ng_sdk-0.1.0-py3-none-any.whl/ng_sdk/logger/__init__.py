# logger/__init__.py
"""
Package bootstrap (lazy):
- Do NOT create a Logger() on import.
- Provide a global slot `g_logger` that app code may fill.
- Install a safe excepthook which uses `g_logger` if set.
"""

# logger/__init__.py

