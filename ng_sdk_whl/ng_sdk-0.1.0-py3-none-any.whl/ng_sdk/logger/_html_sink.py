# ──────────────────────────────────────────────────────────────────────────────
# HTML sink: we build a complete HTML page with sticky header, filters & search.
# We add rows by calling the instance (Loguru calls our __call__ with Message).
# ──────────────────────────────────────────────────────────────────────────────
import html
import os


class _HTMLSink:
    def __init__(self, path, title="Log"):
        self._path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        # Open file once; write header now, rows as they arrive, footer at close()
        self._f = open(path, "w", encoding="utf-8")
        self._f.write(self._header(title))
        self._f.flush()

    def _header(self, title):
        # Inline CSS and a tiny client-side filter bar (levels + search)
        return f"""<!doctype html>
    <html lang="en"><head><meta charset="utf-8">
    <title>{html.escape(title)}</title>
    <style>
      :root {{
        --bg:#0b0f14; --panel:#0f1720; --muted:#93a4b7; --grid:#253140; --row:#0e1621; --rowAlt:#0c131e;
        --dbg:#8ab4f8; --info:#34d399; --warn:#fbbf24; --err:#f87171; --crit:#fb7185;
      }}
      * {{ box-sizing: border-box; }}
      body {{ margin:0; background:var(--bg); color:#e6edf3; font:13px/1.5 ui-monospace, Menlo, Consolas, monospace; }}
      h3 {{ margin:16px 16px 8px; font-weight:700; }}
      .toolbar {{
        display:flex; gap:12px; align-items:center; padding:10px 16px; background:var(--panel);
        border-block:1px solid var(--grid); position:sticky; top:0; z-index:5;
      }}
      .toolbar label {{ display:inline-flex; align-items:center; gap:6px; cursor:pointer; color:var(--muted); }}
      .toolbar input[type="search"] {{
        margin-left:auto; background:#0b1220; border:1px solid var(--grid); color:#e6edf3;
        padding:6px 10px; border-radius:6px; width:300px;
      }}
      table {{ width:100%; border-collapse:collapse; background:var(--panel); border:1px solid var(--grid); }}
      thead th {{
        position:sticky; top:46px; background:#0b1220; color:var(--muted); text-align:left; font-weight:600;
        padding:8px 10px; border-bottom:1px solid var(--grid); z-index:4;
      }}
      tbody td {{ padding:8px 10px; border-bottom:1px solid #1b2533; vertical-align:top; }}
      tbody tr:nth-child(even) {{ background:var(--rowAlt); }}
      tbody tr:nth-child(odd)  {{ background:var(--row); }}
      tbody tr:hover {{ outline:1px solid #2b3a4f; background:#0f1a29; }}
      .time,.delta {{ color:var(--muted); font-variant-numeric:tabular-nums; white-space:nowrap; }}
      .lvlchip {{
        display:inline-block; min-width:64px; text-align:center; font-weight:700; padding:2px 8px; border-radius:999px;
        background:#18202b; border:1px solid var(--grid);
      }}
      .lvlchip.DEBUG {{ color:var(--dbg);  border-color:#1a2a46; background:#0b1424; }}
      .lvlchip.INFO  {{ color:var(--info); border-color:#1a3a2f; background:#0b1713; }}
      .lvlchip.WARNING{{ color:var(--warn); border-color:#3f320f; background:#181307; }}
      .lvlchip.ERROR {{ color:var(--err);  border-color:#3f1b1d; background:#170b0d; }}
      .lvlchip.CRITICAL{{ color:var(--crit); border-color:#4a1821; background:#17090d; }}
      /* left severity bar for quick visual scanning */
      tr.l-DEBUG   td:first-child {{ box-shadow: inset 3px 0 0 0 var(--dbg); }}
      tr.l-INFO    td:first-child {{ box-shadow: inset 3px 0 0 0 var(--info); }}
      tr.l-WARNING td:first-child {{ box-shadow: inset 3px 0 0 0 var(--warn); }}
      tr.l-ERROR   td:first-child {{ box-shadow: inset 3px 0 0 0 var(--err); }}
      tr.l-CRITICAL td:first-child{{ box-shadow: inset 3px 0 0 0 var(--crit); }}
      .msg {{ white-space:pre-wrap; word-break:break-word; }}
      .icon {{ width:1.4em; display:inline-block; text-align:center; margin-right:.4em; opacity:.9; }}
      a {{ color:#9ecbff; }}
    </style>
    </head><body>
    <h3>{html.escape(title)}</h3>
    <div class="toolbar">
      <!-- per-level toggles -->
      <label><input type="checkbox" data-lvl="DEBUG" checked> DEBUG</label>
      <label><input type="checkbox" data-lvl="INFO" checked> INFO</label>
      <label><input type="checkbox" data-lvl="WARNING" checked> WARNING</label>
      <label><input type="checkbox" data-lvl="ERROR" checked> ERROR</label>
      <label><input type="checkbox" data-lvl="CRITICAL" checked> CRITICAL</label>
      <!-- client-side substring search -->
      <input id="searchBox" type="search" placeholder="Search message…">
    </div>
    <table>
      <thead><tr><th>Time</th><th>Δ (s.ms)</th><th>Level</th><th>Message</th></tr></thead>
      <tbody>
    <script>
    // Tiny filter engine: toggles rows by level + search text (no backend needed)
    (function(){{
      const checks=[...document.querySelectorAll('.toolbar input[type=checkbox]')];
      const box=document.getElementById('searchBox');
      function apply(){{
        const on = new Set(checks.filter(c=>c.checked).map(c=>c.dataset.lvl));
        const q = (box.value||'').trim().toLowerCase();
        document.querySelectorAll('tbody tr').forEach(tr=>{{
          const lvl=tr.dataset.level;
          const text=tr.dataset.text||'';
          tr.style.display = (on.has(lvl) && (!q || text.includes(q))) ? '' : 'none';
        }});
      }}
      checks.forEach(c=>c.addEventListener('change',apply));
      box.addEventListener('input',apply);
      window.addEventListener('load',apply);
    }})();
    </script>
    """

    def _footer(self):
        # Close the table/page at shutdown
        return "</tbody></table></body></html>"

    def __call__(self, message):
        # Build one <tr> per Loguru message with safe HTML escaping and metadata
        r = message.record
        dt = r["time"].astimezone()
        time_str = f"{dt:%Y-%m-%d %H:%M:%S}.{int(dt.microsecond / 1000):03d}"
        extra = r.get("extra") or {}
        delta = extra.get("delta", "00.000")
        level = r["level"].name

        # Tiny level icon set (optional, purely visual)
        icon = {"DEBUG": "🐞", "INFO": "ℹ️", "WARNING": "⚠️", "ERROR": "⛔", "CRITICAL": "🔥"}.get(level, "•")

        # Escape message content to avoid breaking markup
        msg = html.escape(r["message"])
        # Lowercased text for the client-side search index
        searchable = (f"{level} {r['message']}").lower().replace('"', '&quot;')

        row = (
            f"<tr class='l-{level}' data-level='{level}' data-text=\"{searchable}\">"
            f"<td class='time'><span class='icon'>{icon}</span>{time_str}</td>"
            f"<td class='delta'>{delta}</td>"
            f"<td><span class='lvlchip {level}'>{level}</span></td>"
            f"<td class='msg'>{msg}</td>"
            f"</tr>\n"
        )
        self._f.write(row)
        self._f.flush()

    def close(self):
        # Ensure the HTML file is always well-formed
        try:
            self._f.write(self._footer())
            self._f.flush()
            self._f.close()
        except Exception:
            pass
