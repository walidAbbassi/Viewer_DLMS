# ──────────────────────────────────────────────────────────────────────────────
# Lightweight INI loader for (1) constants and (2) profile-specific config.
# ──────────────────────────────────────────────────────────────────────────────
import os
from configparser import ConfigParser
from typing import Optional, Dict

from ng_sdk.constant.logger.constant import LoggingConstants


class LoggerConfigurator:
    def __init__(self, constants_path: str, config_path: Optional[str]):
        self.constants_path = os.path.abspath(constants_path)
        self.constants = self.load_ini(self.constants_path)

        self.config_path = os.path.abspath(config_path) if config_path else self.get_profile_config_path()
        self.config = self.load_ini(self.config_path)

        self.profile: Optional[str] = None
        self.profile_config: Dict[str, str] = {}

    @staticmethod
    def load_ini(filepath: str) -> ConfigParser:
        parser = ConfigParser(inline_comment_prefixes=(";", "#"))
        parser.optionxform = str  # preserve case for keys
        parser.read(filepath, encoding="utf-8")
        return parser

    def get_profile_config_path(self, default_name: str = "logging_config.ini") -> str:
        # Resolve the path of the profile-based logging config ini
        if (self.constants.has_section(LoggingConstants.LOGGING_CONFIG)
                and self.constants.has_option(LoggingConstants.LOGGING_CONFIG, LoggingConstants.PROFILE_CONFIG_PATH)):
            raw = self.constants.get(LoggingConstants.LOGGING_CONFIG, LoggingConstants.PROFILE_CONFIG_PATH)
            value = raw.strip().strip('"').strip("'")
            if os.path.isabs(value):
                return value
            base = os.path.dirname(self.constants_path)
            return os.path.join(base, value)
        base = os.path.dirname(self.constants_path)
        return os.path.join(base, default_name)

    def _get_profile_config(self) -> Dict[str, str]:
        # Return the entire key/value map for the current profile section
        if not self.profile or self.profile not in self.config.sections():
            return {}
        return dict(self.config.items(self.profile))

    def set_profile(self, profile: str) -> None:
        self.profile = profile
        self.profile_config = self._get_profile_config()

    def get_constant(self, section: str, key: str, fallback=None):
        if self.constants.has_section(section) and self.constants.has_option(section, key):
            return self.constants.get(section, key)
        return fallback

    def get_profile_option(self, key: str, fallback=None):
        return self.profile_config.get(key, fallback)