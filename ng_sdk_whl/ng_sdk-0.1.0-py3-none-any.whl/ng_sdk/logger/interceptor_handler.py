# ──────────────────────────────────────────────────────────────────────────────
# Stdlib -> Loguru interception so logging.getLogger() also flows to Loguru.
# ──────────────────────────────────────────────────────────────────────────────
import logging

from loguru import logger as _global_logger

class InterceptHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        # Map stdlib level to a Loguru level (fallback to levelno)
        try:
            level = _global_logger.level(record.levelname).name
        except Exception:
            level = record.levelno

        # Re-emit through Loguru; depth skips stdlib frames for nicer callsites
        _global_logger.bind(name=record.name).opt(
            depth=6,
            exception=record.exc_info
        ).log(level, record.getMessage())