# logger.py — Centralized Loguru wrapper with HTML/JSONL/file sinks.

from __future__ import annotations

import atexit
import contextvars
import json
import logging
import os
import re
import sys
import uuid
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Optional

from loguru import logger as _global_logger

from ng_sdk.constant.logger.constant import LoggingConstants
from ng_sdk.logger._html_sink import _HTMLSink
from ng_sdk.logger.interceptor_handler import InterceptHandler
from ng_sdk.logger.logger_configurator import LoggerConfigurator
from ng_sdk.util.singleton_meta import SingletonMeta

# Per-context correlation id and last-timestamp (used to compute Δ)
_CORR_ID: contextvars.ContextVar[str] = contextvars.ContextVar("corr_id", default="-")
_LAST_MS: contextvars.ContextVar[Optional[int]] = contextvars.ContextVar("last_ms", default=None)


def _get_base_path() -> str:
    """
    Get the base path for the application, handling frozen executables.
    
    Returns:
        Base directory path for the application
    """
    if getattr(sys, 'frozen', False):
        # Running as frozen executable (cx_Freeze, PyInstaller, etc.)
        exe_dir = os.path.dirname(sys.executable)
        
        # Check if running from Program Files (read-only location)
        # If so, use AppData for writable files like logs
        program_files = os.environ.get('ProgramFiles', 'C:\\Program Files')
        program_files_x86 = os.environ.get('ProgramFiles(x86)', 'C:\\Program Files (x86)')
        
        if exe_dir.startswith(program_files) or exe_dir.startswith(program_files_x86):
            # Use AppData for logs and writable files
            appdata = os.environ.get('LOCALAPPDATA', os.path.expanduser('~'))
            app_data_dir = os.path.join(appdata, 'DLMS_SDK_Remote_Server')
            os.makedirs(app_data_dir, exist_ok=True)
            return app_data_dir
        
        return exe_dir
    else:
        # Running as normal Python script
        return os.getcwd()


# ──────────────────────────────────────────────────────────────────────────────
# Main Logger wrapper – configures sinks, formats and provides a tiny API.
# ──────────────────────────────────────────────────────────────────────────────
class Logger(metaclass=SingletonMeta):
    """Singleton wrapper around Loguru's global logger."""


    def __init__(self) -> None:
        # Default initialization with SDK's logger config
        # Projects can override by calling init_logger() before importing SDK modules
        self.configure("configuration/logger/configuration.ini","configuration/logger/logging_config.ini","SDK_NG_CONFIGURATION_DEBUG")

    def configure(self,constants_path: str, ini_path: Optional[str] = None, profile: Optional[str] = None):
        # Load constants + pick the profile ini
        self.configurator = LoggerConfigurator(constants_path, None)
        profile_ini_path = self.configurator.get_profile_config_path()
        if ini_path:
            profile_ini_path = os.path.abspath(ini_path)

        self.configurator.config_path = profile_ini_path
        self.configurator.config = self.configurator.load_ini(profile_ini_path)

        # Timestamp used for default HTML filename etc.
        self.run_ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

        # Choose the profile (from constants if not provided)
        if profile is None:
            profile = self.configurator.get_constant(
                LoggingConstants.DEFAULT_PROFILE,
                LoggingConstants.INITIAL_PROFILE,
                fallback=LoggingConstants.SDK_NG_CONFIGURATION_DEFAULT,
            )
        self.profile = profile
        self.configurator.set_profile(profile)

        # Keep a plain dict view for easy .get() access
        self.config = dict(self.configurator.profile_config)

        # Cache for potential per-day JSONL handles (not required for basic flow)
        self._json_handles = {}

        # Register custom levels if necessary
        self.LOGGING_EXCEPTION = int(self.configurator.get_constant(
            LoggingConstants.LOGGING_CONSTANTS, LoggingConstants.LOGGING_EXCEPTION, fallback=str(logging.CRITICAL + 1)
        ))
        self.LOGGING_TRACE = int(self.configurator.get_constant(
            LoggingConstants.LOGGING_CONSTANTS, LoggingConstants.LOGGING_TRACE, fallback=str(logging.NOTSET)
        ))
        logging.addLevelName(self.LOGGING_TRACE, LoggingConstants.TRACE)
        logging.addLevelName(self.LOGGING_EXCEPTION, LoggingConstants.EXCEPTION)
        try:
            _global_logger.level(LoggingConstants.EXCEPTION)
        except ValueError:
            _global_logger.level(LoggingConstants.EXCEPTION, no=self.LOGGING_EXCEPTION)

        # Defaults for contextual extras
        self._extra_modules = LoggingConstants.EXTRA_CONTEXT
        self._extra_users = LoggingConstants.EXTRA_CONTEXT

        # Configure all sinks and interceptors
        self._configure_logger()

        # Ensure graceful finalization (flush queues, close HTML properly)
        atexit.register(self._shutdown)

        _global_logger.bind().trace(f"Logger initialized with profile '{self.profile}'.")


    # ───── Correlation-ID helpers (optional, handy for request tracing) ─────
    def set_correlation_id(self, corr_id: str | None = None) -> str:
        if corr_id is None:
            corr_id = str(uuid.uuid4())
        _CORR_ID.set(corr_id)
        return corr_id

    def clear_correlation_id(self):
        _CORR_ID.set("-")

    @contextmanager
    def with_correlation_id(self, corr_id: str | None = None):
        token = _CORR_ID.set(corr_id or str(uuid.uuid4()))
        try:
            yield corr_id
        finally:
            _CORR_ID.reset(token)

    # ──────────────────────────────────────────────────────────────────────
    # Shutdown: drain Loguru, close JSON handles, write HTML footer.
    # ──────────────────────────────────────────────────────────────────────
    def _shutdown(self):
        try:
            _global_logger.complete()
        except Exception:
            pass
        for fh in list(self._json_handles.values()):
            try:
                fh.flush()
                fh.close()
            except Exception:
                pass
        self._json_handles.clear()
        try:
            if getattr(self, "_html_sink", None):
                self._html_sink.close()
        except Exception:
            pass

    # ──────────────────────────────────────────────────────────────────────
    # Patcher enriches every record with extras (Modules/Users/Δ etc.).
    # Δ is computed from the previous log time in the current context.
    # ──────────────────────────────────────────────────────────────────────
    def _patch_extras(self) -> None:
        def _patch(record):
            # Fully defensive: any exception here causes Loguru (catch=True) to
            # silently drop the message — especially dangerous in worker threads
            # spawned by asyncio.to_thread() where the ContextVar context is a
            # read-only copy and ContextVar.set() raises RuntimeError.
            try:
                extra = record.setdefault("extra", {})
                extra.setdefault("Modules", self._extra_modules)
                extra.setdefault("Users", self._extra_users)
                # If CorrID is needed in logs, uncomment the next line.
                # extra.setdefault("CorrID", _CORR_ID.get() or "-")

                # Normalize <module> frames so the "function" column looks cleaner
                if record.get("function") == "<module>":
                    record["function"] = None

                # Epoch milliseconds for this record
                now_ms = int(record["time"].timestamp() * 1000)
                extra["ms"] = now_ms

                # Delta from previous message in this context (min 0).
                # ContextVar.get() is always safe (has a default).
                # ContextVar.set() raises RuntimeError in read-only contexts
                # (asyncio.to_thread worker threads) — catch it explicitly.
                try:
                    last = _LAST_MS.get()
                    delta_ms = 0 if last is None else max(0, now_ms - last)
                    _LAST_MS.set(now_ms)
                except RuntimeError:
                    # Read-only context (worker thread): delta stays 0, no update
                    delta_ms = 0

                # Format Δ as "SS.mmm"
                extra["delta"] = f"{delta_ms // 1000:02d}.{delta_ms % 1000:03d}"
            except Exception:
                # Last-resort: ensure delta always exists so format strings never
                # raise KeyError and cause Loguru to silently drop the message
                record.setdefault("extra", {})["delta"] = "00.000"

        _global_logger.configure(patcher=_patch)

    # Small helpers to read booleans/strings from the active profile dict
    def _get_bool(self, key: str, default: bool = False) -> bool:
        return self.config.get(key, str(default)).lower() in ("true", "1", "yes", "on")

    def _get_str(self, key: str, default: str = "") -> str:
        return self.config.get(key, default)

    def _b(self, key: str, default: str) -> str:
        return self.configurator.get_constant(LoggingConstants.LOGGING_CONSTANTS, key, fallback=default)

    # Build the text format string used by console/file sinks
    def _build_format(self) -> str:
        parts = [
            self._b(LoggingConstants.TIME_FORMAT, LoggingConstants.TIME_FORMAT_VALUE),
            "{extra[delta]}",
            self._b(LoggingConstants.LEVEL_FORMAT, "{level:<5}"),
            self._b(LoggingConstants.MESSAGE_FORMAT, "{message}"),
        ]
        return " | ".join(filter(None, parts))

    # Guard Loguru's colorizer from misreading arbitrary <tags> in the format
    @staticmethod
    def _escape_unknown_color_tags(fmt: str) -> str:
        allowed = {
            "level", "red", "green", "yellow", "blue", "magenta", "cyan", "white",
            "black", "bold", "underline", "reverse",
            "bgred", "bggreen", "bgyellow", "bgblue", "bgmagenta", "bgcyan", "bgwhite", "bgblack",
        }
        tag_re = re.compile(r"</?\s*([A-Za-z]+)(?:\s+[^<>]*)?>")

        def repl(m: re.Match) -> str:
            name = m.group(1).lower()
            return m.group(0) if name in allowed else "\\" + m.group(0)

        return tag_re.sub(repl, fmt)

    # Remove all color tags for file sinks (avoid angle-bracket parsing issues)
    @staticmethod
    def _strip_all_color_tags(fmt: str) -> str:
        return re.sub(r"</?\s*[A-Za-z]+(?:\s+[^<>]*)?>", "", fmt)

    def _fix_escaped_format_specs(s: str) -> str:
        # Undo accidental escapes around alignment tokens inside {...}
        return (
            s.replace(":\\<", ":<")
             .replace(":\\>", ":>")
             .replace(":\\^", ":^")
        )

    # JSONL sink helper (not required in the typical flow, kept for extensibility)
    def _open_json_file_for_date(self, date_str: str):
        path = Path(self._json_dir) / f"structured_{date_str}.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        fh = self._json_handles.get(date_str)
        if fh and not fh.closed:
            return fh
        fh = open(path, "a", encoding="utf-8")
        self._json_handles[date_str] = fh
        return fh

    # Minimal HTML helpers if you ever want to use string-format sink variant
    @staticmethod
    def _html_header(title: str, inline_css: bool = True) -> str:
        # (kept for compatibility; the callable sink is preferred)
        css = ("<style> ... </style>") if inline_css else ""
        return f"<!doctype html><html><head><meta charset='utf-8'><title>{title}</title>{css}</head><body><h1>{title}</h1><table><thead><tr><th>Time</th><th>Δ (s.ms)</th><th>Level</th><th>Message</th></tr></thead><tbody>\n"

    @staticmethod
    def _html_footer() -> str:
        return "</tbody></table></body></html>\n"

    @staticmethod
    def _html_row_formatter(record: dict) -> str:
        # Only used if you add the file path directly as a sink with format=html
        from html import escape
        dt = record["time"].astimezone()
        time_str = f"{dt:%Y-%m-%d %H:%M:%S}.{int(dt.microsecond / 1000):03d}"
        delta = (record.get("extra") or {}).get("delta", "00.000")
        level = record["level"].name
        msg = escape(record["message"])
        return (f"<tr><td class='time'>{time_str}</td><td class='delta'>{delta}</td><td class='lvl {level}'>{level}</td><td>{msg}</td></tr>\n")

    # Write one JSON object per line; called when structured_enabled=true
    def _json_sink(self, record):
        dt = record["time"].astimezone()
        out = {
            "time": f"{dt:%Y-%m-%d %H:%M:%S}.{int(dt.microsecond / 1000):03d}",
            "delta": (record.get("extra") or {}).get("delta", "00.000"),
            "level": record["level"].name,
            "message": record["message"],
        }
        profiles_dir = os.path.dirname(self.configurator.config_path)
        path_log = self.configurator.get_profile_option(LoggingConstants.PATH_LOG, LoggingConstants.LOGGING)
        
        # Handle frozen executables
        if not os.path.isabs(path_log):
            if getattr(sys, 'frozen', False):
                path_log = os.path.join(_get_base_path(), path_log)
            else:
                path_log = os.path.join(profiles_dir, path_log)
        os.makedirs(path_log, exist_ok=True)
        path = os.path.join(path_log, f"structured_{dt:%Y-%m-%d}.jsonl")
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(out, ensure_ascii=False) + "\n")

    # Resolve/create the log directory (base is constants ini location)
    def _resolve_log_dir(self) -> str:
        constants_base = os.path.dirname(self.configurator.constants_path)
        path_log_cfg = self.configurator.get_profile_option(LoggingConstants.PATH_LOG, LoggingConstants.LOGGING)
        
        # Handle frozen executables
        if os.path.isabs(path_log_cfg):
            path_log = path_log_cfg
        elif getattr(sys, 'frozen', False):
            # For frozen executables, create logs relative to executable directory
            path_log = os.path.join(_get_base_path(), path_log_cfg)
        else:
            path_log = os.path.join(constants_base, path_log_cfg)
            
        path_log = os.path.normpath(path_log)
        os.makedirs(path_log, exist_ok=True)
        return path_log

    # ──────────────────────────────────────────────────────────────────────
    # Core: configure all sinks (file, console, jsonl, html) and interceptors
    # ──────────────────────────────────────────────────────────────────────
    def _configure_logger(self) -> None:
        _global_logger.remove()  # start clean

        # Build the base formats and guard them against accidental tags
        fmt_console_cfg = self._escape_unknown_color_tags(self._build_format())
        fmt_file_cfg = self._strip_all_color_tags(fmt_console_cfg)

        # Normalize alignment spec spacing (e.g. "{level: <8}" -> "{level:<8}")
        def _fix_alignment_spaces(s: str) -> str:
            return re.sub(r":\s*([<>\^])", r":\1", s)

        fmt_console_cfg = _fix_alignment_spaces(fmt_console_cfg)
        fmt_file_cfg = _fix_alignment_spaces(fmt_file_cfg)

        # Undo any accidental escaping of alignment tokens
        def _fix_escaped_format_specs(s: str) -> str:
            return s.replace(":\\<", ":<").replace(":\\>", ":>").replace(":\\^", ":^")

        fmt_console_cfg = _fix_escaped_format_specs(fmt_console_cfg)
        fmt_file_cfg = _fix_escaped_format_specs(fmt_file_cfg)

        # Fallbacks in case custom formats explode.
        # IMPORTANT: use callables (not strings with {extra[delta]}) — a missing
        # "delta" key raises KeyError which Loguru with catch=True swallows
        # silently, dropping the message. This is the root cause of lost INFO logs
        # from asyncio.to_thread() worker threads.
        def FALLBACK_FILE_FMT(record) -> str:
            extra = record.get("extra") or {}
            delta = extra.get("delta", "00.000")
            t = record["time"]
            ts = f"{t:%Y-%m-%d %H:%M:%S}.{int(t.microsecond / 1000):03d}"
            exc = ""
            if record["exception"]:
                import traceback as _tb
                exc = "\n" + "".join(_tb.format_exception(*record["exception"]))
            return f"{ts} | {delta} | {record['level'].name:<8} | {record['message']}{exc}\n"

        def FALLBACK_CONSOLE_FMT(record) -> str:
            return FALLBACK_FILE_FMT(record)

        # Resolve paths and options from profile
        profiles_dir = os.path.dirname(self.configurator.config_path)
        path_log = self.configurator.get_profile_option(LoggingConstants.PATH_LOG, LoggingConstants.LOGGING)
        
        # Handle frozen executables - use executable directory instead of profiles_dir
        if not os.path.isabs(path_log):
            if getattr(sys, 'frozen', False):
                # For frozen executables, create logs relative to executable directory
                path_log = os.path.join(_get_base_path(), path_log)
            else:
                path_log = os.path.join(profiles_dir, path_log)

        file_log = self.configurator.get_profile_option(LoggingConstants.FILE_LOG, LoggingConstants.FILE_LOG_VALUE)
        console_log = self._get_bool(LoggingConstants.CONSOLE_LOG, False)
        level_file = self.configurator.get_profile_option(LoggingConstants.LEVEL_FILE, LoggingConstants.LEVEL_VALUE).upper()
        level_console = self.configurator.get_profile_option(LoggingConstants.LEVEL_CONSOLE, LoggingConstants.LEVEL_VALUE).upper()
        rotation = self.configurator.get_profile_option(LoggingConstants.ROTATION, LoggingConstants.ROTATION_VALUE)
        enqueue = self._get_bool(LoggingConstants.ENQUEUE, False)
        backtrace = self._get_bool(LoggingConstants.BACKTRACE, False)
        diagnose = self._get_bool(LoggingConstants.DIAGNOSE, False)
        color_con = self._get_bool(LoggingConstants.COLORIZE_CONSOLE, False)
        catch = self._get_bool(LoggingConstants.CATCH, True)
        compression = self.configurator.get_profile_option("compression", None)

        structured_enabled = self._get_bool("structured_enabled", False)
        structured_format = (self.configurator.get_profile_option("structured_format", "jsonl") or "jsonl").lower()
        structured_file = self.configurator.get_profile_option("structured_file", "structured_{time:YYYY-MM-DD}.jsonl")

        # HTML toggle + optional fixed filename
        html_enabled = self._get_bool("html_enabled", False)
        html_file = self.configurator.get_profile_option("html_file", None)

        full_log_path = os.path.join(path_log, file_log)
        os.makedirs(os.path.dirname(full_log_path), exist_ok=True)

        # Ensure extras are attached to all records going forward
        self._patch_extras()

        # Add NOTSET/FATAL aliases if they don't exist yet
        for name, no in (("NOTSET", 0), ("FATAL", 50)):
            try:
                _global_logger.level(name)
            except ValueError:
                _global_logger.level(name, no=no)

        common = dict(enqueue=enqueue, backtrace=backtrace, diagnose=diagnose, catch=catch)

        # ── File sink (rotating) ──
        file_base_kwargs = dict(level=level_file, rotation=rotation, colorize=False, encoding="utf-8")
        if compression:
            file_base_kwargs["compression"] = compression
        try:
            _global_logger.add(full_log_path, format=fmt_file_cfg, **common, **file_base_kwargs)
        except Exception:
            _global_logger.add(full_log_path, format=FALLBACK_FILE_FMT, **common, **file_base_kwargs)

        # ── Console sink (optional) ──
        if console_log:
            try:
                _global_logger.add(sys.stderr, format=fmt_console_cfg, level=level_console, colorize=color_con, **common)
            except Exception:
                _global_logger.add(sys.stderr, format=FALLBACK_CONSOLE_FMT, level=level_console, colorize=True, **common)

        # ── Structured sink (jsonl) ──
        if structured_enabled and structured_format == "jsonl":
            def _kv_fmt(record) -> str:
                extra = record.get("extra") or {}
                delta = extra.get("delta", "00.000")
                t = record["time"]
                ts = f"{t:%Y-%m-%d %H:%M:%S}.{int(t.microsecond / 1000):03d}"
                return f"{ts} | {delta} | {record['level'].name:<5} | {record['message']}\n"
            try:
                jsonl_path = os.path.join(os.path.dirname(full_log_path), structured_file)
                _global_logger.add(
                    jsonl_path, level=level_file, format=_kv_fmt, rotation=rotation,
                    enqueue=enqueue, backtrace=backtrace, diagnose=diagnose, catch=catch, encoding="utf-8",
                )
            except Exception:
                _global_logger.warning("Structured KV sink could not be added; continuing without it.")
        elif structured_enabled:
            _global_logger.warning(f"Unknown structured_format='{structured_format}', skipping structured sink.")

        # ── HTML sink (callable) ──
        self._html_sink = None
        if html_enabled:
            # Allow a fixed filename; otherwise use a timestamped default
            html_name = (html_file or f"log_{self.run_ts}.html").replace("{time:YYYY-MM-DD-HH-mm-ss-SSS}", self.run_ts)
            html_path = os.path.join(os.path.dirname(full_log_path), html_name)
            try:
                self._html_sink = _HTMLSink(html_path, title=f"{self.profile} logs")
                _global_logger.add(
                    self._html_sink, level=level_file,
                    format="{message}",  # leave HTML generation to the callable
                    enqueue=enqueue, backtrace=backtrace, diagnose=diagnose, catch=catch,
                )
                _global_logger.trace(f"HTML sink -> {html_path}")
            except Exception as e:
                _global_logger.warning(f"HTML sink failed: {e}")

        # Intercept stdlib logging so everything funnels through Loguru
        root_logger = logging.getLogger()
        root_logger.handlers = [InterceptHandler()]
        root_logger.setLevel(logging.NOTSET)

        # Friendly banner at startup (kept minimal to avoid noise)
        self._post_banner()


    def _post_banner(self):
        _global_logger.trace(f"Logger initialized with profile '{self.profile}'")

    # ──────────────────────────────────────────────────────────────────────
    # Public conveniences
    # ──────────────────────────────────────────────────────────────────────
    def set_profile(self, profile: str) -> None:
        self.profile = profile
        self.configurator.set_profile(profile)
        self.config = dict(self.configurator.profile_config)
        self._configure_logger()
        _global_logger.debug(f"Profile switched to '{profile}'.")

    def update_modules(self, modules_str: str) -> None:
        self.extra_modules = modules_str

    def update_users(self, users_str: str) -> None:
        self.extra_users = users_str

    @staticmethod
    def _normalize_level(level) -> str:
        # Map ints/aliases into names that Loguru understands
        if isinstance(level, int):
            if level == logging.NOTSET:
                return "TRACE"
            name = logging.getLevelName(level)
            return name if isinstance(name, str) else str(level)
        if isinstance(level, str):
            up = level.upper()
            if up == "NOTSET":
                return "TRACE"
            if up == "FATAL":
                return "CRITICAL"
            return up
        return str(level)

    def log(self, level: int | str, message: str, *, include_exc: bool = False, **kwargs) -> None:
        # Allow callers to set a logical module label per message
        modules_name = kwargs.pop(LoggingConstants.MODULES_NAME, LoggingConstants.MODULES_NAME_VALUE)
        self.update_modules(modules_name)

        # Shortcut path for your custom EXCEPTION level
        is_exception = (
            (isinstance(level, int) and level == self.LOGGING_EXCEPTION)
            or (isinstance(level, str) and level.upper() in (LoggingConstants.EXCEPTION, "LOGGING_EXCEPTION"))
        )
        if is_exception:
            if include_exc:
                _global_logger.opt(depth=1, exception=True).log(LoggingConstants.EXCEPTION, message)
            else:
                _global_logger.opt(depth=1).log(LoggingConstants.EXCEPTION, message)
            return

        # Normal path
        level_norm = self._normalize_level(level)
        _global_logger.opt(depth=1).log(level_norm, message)

    @property
    def logger(self):
        # Return a bound Loguru logger for direct usage if desired
        return _global_logger.bind()

    def catch(self, *args, **kwargs):
        return _global_logger.catch(*args, **kwargs)

    def bind(self, **kwargs):
        return _global_logger.bind(**kwargs)


def init_logger(constants_path: str, ini_path: Optional[str] = None, profile: Optional[str] = None) -> None:
    Logger().configure(constants_path,ini_path,profile)
def get_logger():
        return Logger().logger