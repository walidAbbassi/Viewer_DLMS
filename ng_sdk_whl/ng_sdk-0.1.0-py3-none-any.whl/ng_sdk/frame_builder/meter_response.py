

class MeterResponse:
    def __init__(self,frame:bytes):
        self.frame = frame
