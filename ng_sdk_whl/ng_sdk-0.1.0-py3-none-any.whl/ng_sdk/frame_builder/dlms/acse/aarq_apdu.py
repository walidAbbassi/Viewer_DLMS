from typing import ClassVar, Optional

from attr import define, field

from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.acse.models.authentication_functional_unit import AuthenticationFunctionalUnit
from ng_sdk.frame_builder.dlms.acse.models.authentication_value import AuthenticationValue
from ng_sdk.frame_builder.dlms.acse.models.initiate_request import InitiateRequest
from ng_sdk.frame_builder.dlms.acse.models.object_identifier import ObjectIdentifier
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.tag_length_value import TagLengthValue


@define
class AARQ:
    TAG: ClassVar[int] = 0x60

    user_information: Optional[InitiateRequest] = field(default=None)
    application_context_name: ObjectIdentifier = field(
        default=ObjectIdentifier(Constant.LN_REFERENCING_WITH_NO_CIPHERING))

    mechanism_name: Optional[ObjectIdentifier] = field(default=None)
    protocol_version: Optional[bytes] = field(default=None)
    called_ap_title: Optional[bytes] = field(default=None)
    called_ae_qualifier: Optional[bytes] = field(default=None)
    called_ap_invocation_id: Optional[bytes] = field(default=None)
    called_ae_invocation_id: Optional[bytes] = field(default=None)
    calling_ap_title: Optional[bytes] = field(default=None)
    calling_ae_qualifier: Optional[bytes] = field(default=None)
    calling_ap_invocation_id: Optional[bytes] = field(default=None)
    calling_ae_invocation_id: Optional[bytes] = field(default=None)
    sender_acse_requirements: Optional[AuthenticationFunctionalUnit] = field(default=None)
    calling_authentication_value: Optional[AuthenticationValue] = field(default=None)
    implementation_information: Optional[bytes] = field(default=None)

    def to_bytes(self, security_context: Optional[SecurityContext] = None):
        apdu = bytearray()
        if self.protocol_version is not None:
            apdu.extend(TagLengthValue.to_tlv(0x80, TagLengthValue.to_tlv(0x03, self.protocol_version)))
        if self.application_context_name is not None:
            apdu.extend(TagLengthValue.to_tlv(0xA1, self.application_context_name.to_bytes()))
        if self.called_ap_title is not None:
            apdu.extend(TagLengthValue.to_tlv(0xA2, TagLengthValue.to_tlv(0x04, self.called_ap_title)))
        if self.called_ae_qualifier is not None:
            apdu.extend(TagLengthValue.to_tlv(0xA3, TagLengthValue.to_tlv(0x04, self.called_ae_qualifier)))
        if self.called_ap_invocation_id is not None:
            apdu.extend(TagLengthValue.to_tlv(0xA4, TagLengthValue.to_tlv(0x02, self.called_ap_invocation_id)))
        if self.called_ae_invocation_id is not None:
            apdu.extend(TagLengthValue.to_tlv(0xA5, TagLengthValue.to_tlv(0x02, self.called_ae_invocation_id)))
        if self.calling_ap_title is not None:
            apdu.extend(TagLengthValue.to_tlv(0xA6, TagLengthValue.to_tlv(0x04, self.calling_ap_title)))
        if self.calling_ae_qualifier is not None:
            apdu.extend(TagLengthValue.to_tlv(0xA7, TagLengthValue.to_tlv(0x04, self.calling_ae_qualifier)))
        if self.calling_ap_invocation_id is not None:
            apdu.extend(TagLengthValue.to_tlv(0xA8, TagLengthValue.to_tlv(0x04, self.calling_ap_invocation_id)))
        if self.calling_ae_invocation_id is not None:
            apdu.extend(TagLengthValue.to_tlv(0xA9, TagLengthValue.to_tlv(0x04, self.calling_ae_invocation_id)))
        if self.sender_acse_requirements is not None:
            apdu.extend(TagLengthValue.to_tlv(0x8A, self.sender_acse_requirements.to_bytes()))
        if self.mechanism_name is not None:
            apdu.extend(TagLengthValue.to_tlv(0x8B, self.mechanism_name.encode()))
        if self.calling_authentication_value is not None:
            apdu.extend(TagLengthValue.to_tlv(0xAC, self.calling_authentication_value.to_bytes()))
        if self.implementation_information is not None:
            apdu.extend(TagLengthValue.to_tlv(0xBD, TagLengthValue.to_tlv(0x04, self.implementation_information)))
        if self.user_information is not None:
            apdu.extend(TagLengthValue.to_tlv(0xBE, TagLengthValue.to_tlv(0x04, self.user_information.to_bytes(
                security_context))))
        return TagLengthValue.to_tlv(self.TAG, apdu)

    def from_bytes(self):
        pass
