from typing import ClassVar, Any, Optional

from attr import define, field

from ng_sdk.frame_builder.dlms.acse.models.release_reason import ReleaseResponseReason
from ng_sdk.frame_builder.dlms.acse.models.user_information_response import UserInformationResponse
from ng_sdk.security.security_context import SecurityContext

RLRE_TAG = 0x63
USER_INFO_TAG = 0xBE
REASON_TAG = 0x80


@define
class RLRE:
    """
    Represents a Release Response (RLRE) APDU in DLMS/COSEM.
    """

    TAG: ClassVar[int] = RLRE_TAG

    PARSE_TAGS = {
        REASON_TAG: ("reason", ReleaseResponseReason),
        USER_INFO_TAG: ("user_information", UserInformationResponse),
    }

    reason: Optional[ReleaseResponseReason] = field(default=None)
    user_information: Optional[UserInformationResponse] = field(default=None)

    @classmethod
    def from_bytes(cls, source_bytes: bytes,security_context: Optional[SecurityContext] = None) -> "RLRE":
        """
        Parse RLRE APDU from bytes.

        Args:
            source_bytes (bytes): The bytes to parse.

        Returns:
            RLRE: Parsed RLRE object.

        Raises:
            ValueError: If the input does not match RLRE APDU format.
        """
        rlre_data = bytearray(source_bytes)

        try:
            rlre_tag = rlre_data.pop(0)
        except IndexError:
            raise ValueError("Input is too short to contain RLRE tag.")

        if rlre_tag != cls.TAG:
            raise ValueError(
                f"Bytes are not an RLRE APDU. Tag is {rlre_tag}, expected {cls.TAG}."
            )

        try:
            rlre_length = rlre_data.pop(0)
        except IndexError:
            raise ValueError("Input is too short to contain RLRE length.")

        if len(rlre_data) != rlre_length:
            raise ValueError(
                f"The APDU Data length ({len(rlre_data)}) does not correspond to length byte ({rlre_length})."
            )

        object_dict = dict()
        while rlre_data:
            try:
                object_tag = rlre_data.pop(0)
            except IndexError:
                raise ValueError("Unexpected end of data while parsing object tag.")

            object_desc = cls.PARSE_TAGS.get(object_tag)
            if object_desc is None:
                raise ValueError(
                    f"Could not find object with tag {hex(object_tag)} in RLRE definition"
                )

            try:
                object_length = rlre_data.pop(0)
                object_data = bytes(rlre_data[:object_length])
                rlre_data = rlre_data[object_length:]
            except IndexError:
                raise ValueError("Unexpected end of data while parsing object value.")

            object_name = object_desc[0]
            object_class: Any = object_desc[1]
            if object_class == UserInformationResponse:
                object_data = object_class.from_bytes(object_data, security_context)
            else:
                object_data = object_class.from_bytes(object_data,'big')
            object_dict[object_name] = object_data

        return cls(**object_dict)



