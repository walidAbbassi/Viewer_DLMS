import attr
from typing import ClassVar, List

from ng_sdk.util.tag_length_value import TagLengthValue


def validate_password_type(instance, attribute, value):
    if value not in AuthenticationValue.allowed_password_types:
        raise ValueError(f"{value} is not a valid auth value type")


@attr.s
class AuthenticationValue:

    password: str = attr.ib(default="")
    password_type: str = attr.ib(default="chars", validator=validate_password_type)
    allowed_password_types: ClassVar[List[str]] = ["chars", "bits"]

    def to_bytes(self):
        if self.password_type == "chars":
            return TagLengthValue.to_tlv(0x80, self.password.encode())
        elif self.password_type == "bits":
            return TagLengthValue.to_tlv(0x81, bytes.fromhex(self.password))
        else:
            raise ValueError(f"Unknown password_type: {self.password_type}")

    @classmethod
    def from_bytes(cls, _bytes):
        tag, length, data = TagLengthValue.from_bytes(_bytes)
        if tag[0] == 0x80:
            password_type = "chars"
            data = data.hex()
        elif tag[0] == 0x81:
            password_type = "bits"
            data = data.hex()
        else:
            raise ValueError(f"Tag {tag[0]} is not vaild for password")

        return cls(password=data, password_type=password_type)