from typing import ClassVar, Dict

from attrs import define, field

@define
class Conformance:

    general_protection: bool = field(default=False)
    general_block_transfer: bool = field(default=False)
    delta_value_encoding: bool = field(default=False)
    attribute_0_supported_with_set: bool = field(default=False)
    priority_management_supported: bool = field(default=False)
    attribute_0_supported_with_get: bool = field(default=False)
    block_transfer_with_get_or_read: bool = field(default=False)
    block_transfer_with_set_or_write: bool = field(default=False)
    block_transfer_with_action: bool = field(default=False)
    multiple_references: bool = field(default=False)
    data_notification: bool = field(default=False)
    access: bool = field(default=False)
    get: bool = field(default=False)
    set: bool = field(default=False)
    selective_access: bool = field(default=False)
    event_notification: bool = field(default=False)
    action: bool = field(default=False)
    read: bool = field(default=True)
    reserved: bool = field(default=True)


    conformance_bit_position: ClassVar[Dict[str, int]] = {
        "general_protection": 22,
        "general_block_transfer": 21,
        "delta_value_encoding": 17,
        "attribute_0_supported_with_set": 15,
        "priority_management_supported": 14,
        "attribute_0_supported_with_get": 13,
        "block_transfer_with_get_or_read": 12,
        "block_transfer_with_set_or_write": 11,
        "block_transfer_with_action": 10,
        "multiple_references": 9,
        "data_notification": 7,
        "access": 6,
        "get": 4,
        "set": 3,
        "selective_access": 2,
        "event_notification": 1,
        "action": 0,
        "read": 20,
        "reserved": 23,
    }

    @classmethod
    def from_bytes(cls, in_bytes: bytes):
        in_dict = dict()
        integer_representation = int.from_bytes(in_bytes[1:], "big")
        for attribute in Conformance.conformance_bit_position.keys():
            in_dict[attribute] = bool(
                integer_representation
                & (1 << Conformance.conformance_bit_position[attribute])
            )
        return cls(**in_dict)


    def to_bytes(self):
        out = 0
        for attribute, position in Conformance.conformance_bit_position.items():
            flag_is_set = getattr(self, attribute)
            if flag_is_set:
                out += 1 << position
        # It is a bit string so need to encode how many bits that are unused in the
        # last byte. Its none so we can just put 0x00 infront.
        return b"\x00" + out.to_bytes(3, "big")


