from typing import ClassVar

from ng_sdk.util.tag_length_value import TagLengthValue


class ObjectIdentifier:
    TAG: ClassVar[int] = 0x06
    def __init__(self, oid_str):
        """
        Initialise l'OID à partir d'une chaîne comme "1.3.6.1.2.1"
        """
        self.oid_str = oid_str
        self.oid_str_strip = oid_str.strip()
        self.oid_parts = list(map(int, self.oid_str_strip.split('.')))

        if len(self.oid_parts) < 2:
            raise ValueError("OID must have at least two numbers (e.g., 1.0)")

    def encode(self):
        """
        Encode l'OID au format ASN.1 BER (brut)
        """
        first_byte = 40 * self.oid_parts[0] + self.oid_parts[1]
        encoded = [first_byte]

        for num in self.oid_parts[2:]:
            subident = []
            while True:
                subident.insert(0, num & 0x7F)
                if num < 0x80:
                    break
                num >>= 7
            for i in range(len(subident) - 1):
                subident[i] |= 0x80
            encoded.extend(subident)

        return bytes(encoded)
    @classmethod
    def from_bytes(cls,_bytes: bytes,implicit:bool=False):

        if not implicit:
            tag, length, encoded_oid = TagLengthValue.from_bytes(_bytes)
            if tag[0] != cls.TAG:
                raise ValueError("Wrong tag for Object Identifier")
        else:
            encoded_oid = _bytes

        if not encoded_oid:
            raise ValueError("Encoded OID is empty")

        # First byte contains the first two OID parts
        first_byte = encoded_oid[0]
        first = first_byte // 40
        second = first_byte % 40
        oid_parts = [first, second]

        value = 0
        for byte in encoded_oid[1:]:
            value = (value << 7) | (byte & 0x7F)
            if not (byte & 0x80):  # Last byte of this subidentifier
                oid_parts.append(value)
                value = 0

        oid_string = '.'.join(str(part) for part in oid_parts)

        return cls(oid_string)

    def to_bytes(self):
        """
        Retourne le TLV complet avec le tag ASN.1 d'un OID (06)
        """
        value = self.encode()
        length = len(value)
        if length < 0x80:
            length_bytes = bytes([length])
        else:
            len_len = (length.bit_length() + 7) // 8
            length_bytes = bytes([0x80 | len_len]) + length.to_bytes(len_len, 'big')
        return bytes([0x06]) + length_bytes + value

    def hex(self):
        """Retourne la version hexadécimale encodée"""
        return self.encode().hex().upper()

    def __repr__(self):
        return f"ObjectIdentifier('{self.oid_str}')"



# oid = ObjectIdentifier("2.16.756.5.8.1.1")
#
# print("OID encodé (bytes):", oid.encode())
# print("OID encodé (hex)  :", oid.hex())
# print("OID TLV complet    :", oid.to_bytes().hex().upper())
# #
# #
# encoded_bin = b'`\x85t\x05\x08\x01\x01'  # Encoded form of 1.2.840.113549
# decode_string = ObjectIdentifier.from_bytes(bytes.fromhex("60857405080101"))
# print(decode_string.oid_str)