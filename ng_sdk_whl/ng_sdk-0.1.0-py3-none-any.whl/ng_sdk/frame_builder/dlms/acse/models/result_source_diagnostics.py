from enum import IntEnum
from typing import ClassVar

from attr import define

from ng_sdk.util.tag_length_value import TagLengthValue

class AssociateSourceDiagnostic(IntEnum):
    @classmethod
    def from_value(cls, value):
        return cls._value2member_map_.get(value)

class AcseServiceUser(AssociateSourceDiagnostic):
    NULL = 0
    NO_REASON_GIVEN = 1
    APPLICATION_CONTEXT_NAME_NOT_SUPPORTED = 2
    CALLING_AP_TITLE_NOT_RECOGNIZED = 3
    CALLING_AP_INVOCATION_IDENTIFIER_NOT_RECOGNIZED = 4
    CALLING_AE_QUALIFIER_NOT_RECOGNIZED = 5
    CALLING_AE_INVOCATION_IDENTIFIER_NOT_RECOGNIZED = 6
    CALLED_AP_TITLE_NOT_RECOGNIZED = 7
    CALLED_AP_INVOCATION_IDENTIFIER_NOT_RECOGNIZED = 8
    CALLED_AE_QUALIFIER_NOT_RECOGNIZED = 9
    CALLED_AE_INVOCATION_IDENTIFIER_NOT_RECOGNIZED = 10
    AUTHENTICATION_MECHANISM_NAME_NOT_RECOGNISED = 11
    AUTHENTICATION_MECHANISM_NAME_REQUIRED = 12
    AUTHENTICATION_FAILURE = 13
    AUTHENTICATION_REQUIRED = 14

class AcseServiceProvider(AssociateSourceDiagnostic):
    NULL = 0
    NO_REASON_GIVEN = 1
    NO_COMMON_ACSE_VERSION = 2


@define
class ResultSourceDiagnostics:
    value: int = 0
    result: AssociateSourceDiagnostic = AcseServiceUser.NULL
    TAG = [0xA1,0xA2]
    TAG_INTEGER: ClassVar[int] = 2
    @classmethod
    def from_bytes(cls, source_bytes: bytes):
        tag_choice, length_choice, data_choice = TagLengthValue.from_bytes(source_bytes)
        if tag_choice[0] not in cls.TAG:
            raise ValueError(
                f"Data provided is not of the correct type. Tag is {tag_choice} but should "
                f"be one of  [0xA1,0xA2]"
            )
        tag, length, data = TagLengthValue.from_bytes(data_choice)
        if tag[0] != cls.TAG_INTEGER:
            raise ValueError(
                f"Data provided is not of the correct type. Tag is {tag} but should "
                f"be {cls.TAG_INTEGER}"
            )

        asd = None
        if tag_choice[0]  == 0xA1:
            asd =AcseServiceUser(int.from_bytes(data, byteorder="big"))
        elif tag_choice[0]  == 0xA2:
            asd =AcseServiceProvider(int.from_bytes(data, byteorder="big"))
        return cls(value=int.from_bytes(data, byteorder="big"),result=asd)




t = ResultSourceDiagnostics.from_bytes(bytes.fromhex("A203020102"))

