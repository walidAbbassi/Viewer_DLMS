from typing import ClassVar, Optional

from attr import define, field

from ng_sdk.frame_builder.dlms.acse.models.conformance import Conformance
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.bytes_util import extract_length
from ng_sdk.util.tag_length_value import TagLengthValue
from .acse_tag import AcseTag

logger = get_logger()
_mod = {LoggingConstants.MODULES_NAME: "InitiateResponse"}  # module tag for logs


@define
class InitiateResponse:
    """
    Represents a DLMS InitiateResponse APDU, supporting clear and ciphered (GLO/DED/GENERAL) forms.
    Handles parsing, validation, and extraction of all relevant fields from the response.

    Attributes:
        TAG (int): Tag for plain InitiateResponse.
        GLO_TAG (int): Tag for GLO-ciphered InitiateResponse.
        DED_TAG (int): Tag for DED-ciphered InitiateResponse.
        GENERAL_TAG (int): Tag for general ciphering (0xDB).
        INITIATE_RESPONSE_TAGS (tuple): All supported tags for InitiateResponse.
        initiate_response_apdu (bytes): Raw APDU bytes (instance attribute).
        server_max_receive_pdu_size (int): Server's max receive PDU size.
        negotiated_dlms_version_number (int): Negotiated DLMS version (default 6).
        negotiated_quality_of_service (int): Negotiated QoS (default 0).
        negotiated_conformance (Conformance|None): Negotiated conformance object.
        security_context (SecurityContext|None): Security context if used.
    """
    TAG: ClassVar[int] = AcseTag.INITIATE_RESPONSE.value
    GLO_TAG: ClassVar[int] = AcseTag.GLO_INITIATE_RESPONSE.value
    DED_TAG: ClassVar[int] = AcseTag.DED_INITIATE_RESPONSE.value
    GENERAL_TAG: ClassVar[int] = 0xDB
    INITIATE_RESPONSE_TAGS: ClassVar[tuple] = (TAG, GLO_TAG, DED_TAG, GENERAL_TAG)
    server_max_receive_pdu_size: int
    initiate_response_apdu: bytes = field(default=b"", repr=False)
    negotiated_dlms_version_number: int = field(default=6)  # Always 6
    negotiated_quality_of_service: int = field(default=0)  # not used in dlms.
    negotiated_conformance: Optional[Conformance] = field(default=None)
    security_context: Optional[SecurityContext] = field(default=None)
    VAA_NAME_LN = b"\x00\x07"
    CONFORMANCE_TAG_AND_LENGTH = b"\x5f\x1f\x04"

    @classmethod
    def from_bytes(cls, source_bytes: bytes, security_context: Optional[SecurityContext] = None):
        """
        Parse an InitiateResponse from bytes, handling clear and ciphered (GLO/DED/GENERAL) forms.
        Args:
            source_bytes: The input bytes to parse.
            security_context: Optional security context for deciphering encrypted responses.
        Returns:
            InitiateResponse instance.
        Raises:
            ValueError: If the tag is invalid, the structure is not recognized, or a ciphered tag is encountered without a security context.
        """
        # Handle GLO/DED ciphered responses
        if source_bytes[0] in (cls.GLO_TAG, cls.DED_TAG):
            if security_context is None:
                raise ValueError(f"Encountered ciphered InitiateResponse tag ({source_bytes[0]!r}) but no security_context was provided.")
            ciphered_data_tag, ciphered_data_length, ciphered_data = TagLengthValue.from_bytes(source_bytes)
            source_bytes = security_context.decipher(ciphered_data)
        # Handle GENERAL ciphered response
        if source_bytes[0] == cls.GENERAL_TAG:
            if security_context is None:
                raise ValueError(f"Encountered GENERAL_TAG InitiateResponse but no security_context was provided.")
            source_bytes = source_bytes[1:]
            ap_title_length = int.from_bytes(source_bytes[:1], "big")
            source_bytes = source_bytes[1:]
            security_context.set_server_system_title(source_bytes[:ap_title_length])
            source_bytes = source_bytes[8:]
            length, source_bytes = extract_length(source_bytes)
        # Since Initiate response mixes BER and A-XDR we should just "handparse" it.
        if not source_bytes.endswith(cls.VAA_NAME_LN):
            raise ValueError("vaa-name in InitiateResponse is not \x00\x07")
        data = bytearray(source_bytes[:-2])
        tag = data.pop(0)
        if tag != cls.TAG:
            raise ValueError(f"Data is not a InitiateResponse APDU, got apdu tag {tag}")
        use_quality_of_service = data.pop(0)
        if use_quality_of_service:
            quality_of_service = data.pop(0)
        else:
            quality_of_service = 0
        dlms_version = data.pop(0)
        if cls.CONFORMANCE_TAG_AND_LENGTH != data[:3]:
            raise ValueError("Not correct conformance tag and length")
        conformance = Conformance.from_bytes(data[3:-2])
        max_pdu_size = int.from_bytes(data[-2:], "big")
        instance = cls(
            initiate_response_apdu=source_bytes,
            negotiated_conformance=conformance,
            negotiated_dlms_version_number=dlms_version,
            negotiated_quality_of_service=quality_of_service,
            server_max_receive_pdu_size=max_pdu_size,
        )
        return instance

    def to_bytes(self) -> bytes:
        return self.initiate_response_apdu

    def __attrs_post_init__(self):
        logger.debug(str(self), **_mod)

    def __str__(self):
        return f"InitiateResponse : 0x{self.to_bytes().hex().upper()}"
