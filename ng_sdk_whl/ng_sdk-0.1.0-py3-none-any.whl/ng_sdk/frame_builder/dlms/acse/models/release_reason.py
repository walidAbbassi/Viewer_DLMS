from enum import IntEnum


class ReleaseRequestReason(IntEnum):

    NORMAL = 0
    URGENT = 1
    USER_DEFINED = 30

class ReleaseResponseReason(IntEnum):

    NORMAL = 0
    NOT_FINISHED = 1
    USER_DEFINED = 30

    @classmethod
    def from_value(cls, value):
        return cls._value2member_map_.get(value)
