

class BitString:
    pass
