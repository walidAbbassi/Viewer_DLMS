

class ApplicationContextName:
    pass