

class GraphicString:
    pass