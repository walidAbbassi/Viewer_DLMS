import attr


@attr.s(auto_attribs=True)
class AuthenticationFunctionalUnit:
    authentication: bool = attr.ib(default=False)

    def to_bytes(self):
        if self.authentication:
            return b"\x07\x80"
        else:
            # when not using authentication this the sender-acse-requirements
            # should not be in the data.
            return b""

    @classmethod
    def from_bytes(cls, _bytes):
        #0780 authentication = True , 0700 authentication = False
        if len(_bytes) != 2:
            raise ValueError(
                f"Authentication Functional Unit data should by 2 "
                f"bytes. Got: {_bytes}"
            )
        last_byte = bool(_bytes[-1])
        return cls(authentication=last_byte)