from enum import IntEnum
from typing import ClassVar
from attr import define, field
from ng_sdk.frame_builder.dlms.acse.models.service_error import ServiceError

class ServiceType(IntEnum):
    INITIATE_ERROR = 1
    GET_STATUS = 2
    GET_NAME_LIST = 3
    GET_VARIABLE_ATTRIBUTE = 4
    READ = 5
    WRITE = 6
    GET_DATA_SET_ATTRIBUTE = 7
    GET_TI_ATTRIBUTE = 8
    CHANGE_SCOPE = 9
    START = 10
    STOP = 11
    RESUME = 12
    MAKE_USABLE = 13
    INITIATE_LOAD = 14
    LOAD_SEGMENT = 15
    TERMINATE_LOAD = 16
    INITIATE_UP_LOAD = 17
    UP_LOAD_SEGMENT = 18
    TERMINATE_UP_LOAD = 19

@define
class ConfirmedServiceError:
    TAG: ClassVar[int] = 0x0E
    value: ServiceError = field(default=None)
    service: ServiceType = field(default=None)

    @classmethod
    def from_bytes(cls, _bytes:bytes):
        service_error_bytes = bytearray(_bytes)
        service_error_tag = service_error_bytes.pop(0)
        if not service_error_tag == cls.TAG:
            raise ValueError("Bytes are not an Service Error Tag . TAg is not '0x0E'")
        confirmed_service_tag  = ServiceType(service_error_bytes.pop(0))
        attr_value = ServiceError.get_by_tag_value(service_error_bytes.pop(0),service_error_bytes.pop(0))

        return cls(service=confirmed_service_tag,value=attr_value)


# t = ConfirmedServiceError.from_bytes(bytes.fromhex("0E0E0701"))
# print(t)