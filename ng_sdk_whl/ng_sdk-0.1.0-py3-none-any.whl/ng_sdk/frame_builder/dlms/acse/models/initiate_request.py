from typing import Optional, ClassVar

from attr import define, field

from ng_sdk.frame_builder.dlms.acse.models.conformance import Conformance
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.bytes_util import encode_length
from ng_sdk.util.tag_length_value import TagLengthValue
from .acse_tag import AcseTag

logger = get_logger()
_mod = {LoggingConstants.MODULES_NAME: "InitiateRequest"}  # module tag for logs


@define
class InitiateRequest:
    """
    Represents a DLMS InitiateRequest APDU, supporting clear and ciphered (GLO/DED/GENERAL) forms.
    Handles encoding, tag selection, and optional encryption for the request.

    Attributes:
        TAG (int): Tag for plain InitiateRequest.
        GLO_TAG (int): Tag for GLO-ciphered InitiateRequest.
        DED_TAG (int): Tag for DED-ciphered InitiateRequest.
        GENERAL_CIPHERING (int): Tag for general ciphering (0xDB).
        INITIATE_REQUEST_TAGS (tuple): All supported tags for InitiateRequest.
        proposed_conformance (Conformance): Proposed conformance object.
        dedicated_key (str|None): Optional dedicated key.
        proposed_quality_of_service (int|None): Proposed QoS.
        client_max_receive_pdu_size (int): Max PDU size.
        proposed_dlms_version_number (int): Proposed DLMS version.
        response_allowed (bool|None): If response is allowed.
    """
    TAG: ClassVar[int] = AcseTag.INITIATE_REQUEST.value
    GLO_TAG: ClassVar[int] = AcseTag.GLO_INITIATE_REQUEST.value
    DED_TAG: ClassVar[int] = AcseTag.DED_INITIATE_REQUEST.value
    GENERAL_CIPHERING: ClassVar[int] = 0xDB  # Tag for general ciphering
    INITIATE_REQUEST_TAGS: ClassVar[tuple] = (TAG, GLO_TAG, DED_TAG, GENERAL_CIPHERING)

    proposed_conformance: Conformance = field(default=Conformance())
    dedicated_key: Optional[bytes] = field(default=None)
    proposed_quality_of_service: Optional[int] = field(default=0)
    client_max_receive_pdu_size: int = field(default=1200)
    proposed_dlms_version_number: int = field(default=6)
    response_allowed: bool = field(default=None)

    def to_bytes(self, security_context: Optional[SecurityContext] = None) -> bytes:
        """
        Encode the InitiateRequest as bytes, handling optional encryption and tag selection.
        Args:
            security_context: Optional security context for encryption.
        Returns:
            Encoded InitiateRequest as bytes.
        Raises:
            ValueError: If security_context is provided but configuration is inconsistent.
        """
        out = bytearray()
        # Always start with the plain tag
        out.append(self.TAG)
        # Dedicated key field
        if self.dedicated_key:
            out.extend(TagLengthValue.to_tlv(self.TAG, self.dedicated_key))
        else:
            out.append(0x00)
        # Response allowed field
        if self.response_allowed is None:
            out.append(0x00)
        elif not self.response_allowed:
            out.extend(b"\x01\x00")
        elif self.response_allowed:
            out.extend(b"\x01\x01")
        # Quality of service, version, conformance, PDU size
        out.append(self.proposed_quality_of_service)
        out.append(self.proposed_dlms_version_number)
        out.extend(b"\x5f\x1f\x04")
        out.extend(self.proposed_conformance.to_bytes())
        out.extend(self.client_max_receive_pdu_size.to_bytes(2, "big"))
        # Handle encryption and tag selection
        if security_context is not None:
            # General protection (GENERAL_CIPHERING)
            if getattr(security_context.configuration.features_activation, 'general_protection', False):
                ciphered_data = security_context.cipher(out)
                system_title = security_context.get_system_title()
                # GENERAL_CIPHERING tag, system title, and ciphered data
                return bytes([self.GENERAL_CIPHERING]) + encode_length(
                    len(system_title)) + system_title + encode_length(
                    len(ciphered_data)) + ciphered_data
            # Default to GLO_TAG
            elif hasattr(security_context.configuration, 'session'):
                return TagLengthValue.to_tlv(self.GLO_TAG, security_context.cipher(out))
            else:
                raise ValueError(
                    "Security context provided but configuration is inconsistent for InitiateRequest encryption.")
        return bytes(out)

    def __attrs_post_init__(self):
        logger.debug(str(self), **_mod)

    def __str__(self):
        return f"InitiateRequest : 0x{self.to_bytes().hex().upper()}"
