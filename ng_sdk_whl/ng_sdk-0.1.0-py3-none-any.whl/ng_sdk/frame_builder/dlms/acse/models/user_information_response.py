from typing import Optional

from attr import define, field

from ng_sdk.frame_builder.dlms.acse.models.confirmed_service_error import ConfirmedServiceError
from ng_sdk.frame_builder.dlms.acse.models.initiate_response import InitiateResponse
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.tag_length_value import TagLengthValue
from .acse_tag import AcseTag


@define
class UserInformationResponse:
    """
    Represents the user information response in the DLMS ACSE context.
    This class can decode both clear and ciphered (GLO/DED/GENERAL) InitiateResponse and ConfirmedServiceError from bytes,
    including support for deciphering encrypted responses if a SecurityContext is provided.

    Attributes:
        octet_string_tag (int): ASN.1 tag for octet string (should always be 0x04).
        content (InitiateResponse | ConfirmedServiceError): The decoded content.
        GENERAL_TAG (int): Tag for general ciphering (0xDB).
        INITIATE_RESPONSE_TAGS (tuple): Tags for all supported InitiateResponse types.
        CONFIRMED_SERVICE_ERROR_TAGS (tuple): Tags for all supported ConfirmedServiceError types.
    """

    octet_string_tag = 0x04
    content: InitiateResponse | ConfirmedServiceError = field(default=None)
    # Tag for general ciphering (not present in AcseTag enum for legacy reasons)
    GENERAL_TAG = 0xDB
    # Tags for all supported InitiateResponse types (plain, GLO, DED, GENERAL)
    INITIATE_RESPONSE_TAGS = (
        AcseTag.INITIATE_RESPONSE.value,  # 2
        AcseTag.GLO_INITIATE_RESPONSE.value,  # 40
        AcseTag.DED_INITIATE_RESPONSE.value,  # 72
        GENERAL_TAG  # 0xDB
    )
    # Tags for all supported ConfirmedServiceError types (plain, GLO, DED)
    CONFIRMED_SERVICE_ERROR_TAGS = (
        AcseTag.CONFIRMED_SERVICE_ERROR.value,  # 14
        AcseTag.GLO_CONFIRMED_SERVICE_ERROR.value,  # 46
        AcseTag.DED_CONFIRMED_SERVICE_ERROR.value  # 78
    )

    @classmethod
    def from_bytes(
            cls,
            _bytes: bytes,
            security_context: Optional[SecurityContext] = None,
    ) -> "UserInformationResponse":
        """
        Parse a UserInformationResponse from bytes.
        Handles InitiateResponse, ConfirmedServiceError, and deciphered ConfirmedServiceError.

        Args:
            _bytes: The input bytes to parse.
            security_context: Optional security context for deciphering encrypted responses.

        Returns:
            UserInformationResponse instance.

        Raises:
            ValueError: If the tag is invalid, the data tag is not recognized, or a ciphered tag is encountered without a security context.
        """
        tag, length, data = TagLengthValue.from_bytes(_bytes)
        # Check ASN.1 tag for octet string
        if tag[0] != UserInformationResponse.octet_string_tag:
            raise ValueError(
                f"The tag for UserInformation data should be 0x04, not {tag[0]!r}"
            )

        # Handle InitiateResponse (plain, GLO, DED, GENERAL)
        if data[0] in cls.INITIATE_RESPONSE_TAGS:
            return cls(InitiateResponse.from_bytes(data, security_context))
        # Handle ConfirmedServiceError (plain, GLO, DED)
        elif data[0] in cls.CONFIRMED_SERVICE_ERROR_TAGS:
            # Ciphered error tags require a security context
            if data[0] in (AcseTag.GLO_CONFIRMED_SERVICE_ERROR.value, AcseTag.DED_CONFIRMED_SERVICE_ERROR.value):
                if security_context is None:
                    raise ValueError(
                        f"Encountered ciphered ConfirmedServiceError tag ({data[0]!r}) but no security_context was provided."
                    )
                # Decipher the error content
                ciphered_data_tag, ciphered_data_length, ciphered_data = TagLengthValue.from_bytes(data)
                source_bytes = security_context.decipher(ciphered_data)
                return cls(ConfirmedServiceError.from_bytes(source_bytes))
            # Plain ConfirmedServiceError
            return cls(ConfirmedServiceError.from_bytes(data))
        # Unknown or unsupported tag
        raise ValueError(
            f"Unable to find a proper data tag in UserInformation. Got {data[0]!r}"
        )
