from enum import Enum


class AcseTag(Enum):
    """
    Enum for ACSE (Association Control Service Element) tags used in DLMS/COSEM communication.
    Each value corresponds to a specific APDU or ciphered APDU type.
    """
    INITIATE_REQUEST = 1  # 0x01
    INITIATE_RESPONSE = 8  # 0x08
    CONFIRMED_SERVICE_ERROR = 14  # 0x0E
    GLO_INITIATE_REQUEST = 33  # 0x21
    GLO_INITIATE_RESPONSE = 40  # 0x28
    GLO_CONFIRMED_SERVICE_ERROR = 46  # 0x2E
    DED_INITIATE_REQUEST = 65  # 0x41
    DED_INITIATE_RESPONSE = 72  # 0x48
    DED_CONFIRMED_SERVICE_ERROR = 78  # 0x4E

