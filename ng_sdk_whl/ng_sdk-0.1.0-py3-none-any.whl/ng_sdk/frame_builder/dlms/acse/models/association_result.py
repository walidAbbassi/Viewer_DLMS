from enum import IntEnum
from typing import ClassVar

from attr import define

from ng_sdk.util.tag_length_value import TagLengthValue

class AssociationResultEnum(IntEnum):
    ACCEPTED = 0
    REJECTED_PERMANENT = 1
    REJECTED_TRANSIENT = 2

    @classmethod
    def from_value(cls, value):
        return cls._value2member_map_.get(value)

@define
class AssociationResult:
    value: int = 0
    TAG: ClassVar[int] = 2  # ASN1 Universal tag 2, Integer.
    result: AssociationResultEnum = AssociationResultEnum.ACCEPTED

    @classmethod
    def from_bytes(cls, source_bytes: bytes):
        tag, length, data = TagLengthValue.from_bytes(source_bytes)
        if tag != cls.TAG.to_bytes(1, "big"):
            raise ValueError(
                f"Data provided is not of the correct type. Tag is {tag} but should "
                f"be {cls.TAG}"
            )
        return cls(value=int.from_bytes(data, byteorder="big"),result=AssociationResultEnum(int.from_bytes(data, byteorder="big")))

