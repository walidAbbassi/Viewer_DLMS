from enum import IntEnum


class ServiceError(IntEnum):
    @classmethod
    def from_value(cls, value):
        return cls._value2member_map_.get(value)
    @classmethod
    def get_by_tag_value(cls, tag:int,value:int):
        match tag :
            case 0 :
                return ApplicationReference(value)
            case 1 :
                return HardwareResource(value)
            case 2 :
                return VdeStateError(value)
            case 3 :
                return Service(value)
            case 4 :
                return Definition(value)
            case 5 :
                return Access(value)
            case 6 :
                return Initiate(value)
            case 7:
                return LoadDataSet(value)
            case 9 :
                return Task(value)
        raise ValueError("Service Error not defined")

class ApplicationReference(ServiceError):
    OTHER = 0
    TIME_ELAPSED = 1
    APPLICATION_UNREACHABLE = 2
    APPLICATION_REFERENCE_INVALID = 3
    APPLICATION_CONTEXT_UNSUPPORTED = 4
    PROVIDER_COMMUNICATION_ERROR = 5
    DECIPHERING_ERROR = 6

class HardwareResource(ServiceError):
    OTHER = 0
    MEMORY_UNAVAILABLE = 1
    PROCESSOR_RESOURCE_UNAVAILABLE = 2
    MASS_STORAGE_UNAVAILABLE = 3
    OTHER_RESOURCE_UNAVAILABLE = 4

class VdeStateError(ServiceError):
    OTHER = 0
    NO_DLMS_CONTEXT = 1
    LOADING_DATA_SET = 2
    STATUS_NOCHANGE = 3
    STATUS_INOPERABLE = 4

class Service(ServiceError):
    OTHER = 0
    PDU_SIZE = 1
    SERVICE_UNSUPPORTED = 2

class Definition(ServiceError):
    OTHER = 0
    OBJECT_UNDEFINED = 1
    OBJECT_CLASS_INCONSISTENT = 2
    OBJECT_ATTRIBUTE_INCONSISTENT = 3

class Access(ServiceError):
    OTHER = 0
    SCOPE_OF_ACCESS_VIOLATED = 1
    OBJECT_ACCESS_VIOLATED = 2
    HARDWARE_FAULT = 3
    OBJECT_UNAVAILABLE = 4

class Initiate(ServiceError):
    OTHER = 0
    DLMS_VERSION_TOO_LOW = 1
    INCOMPATIBLE_CONFORMANCE = 2
    PDU_SIZE_TOO_SHORT = 3
    REFUSED_BY_THE_VDE_HANDLER = 4

class LoadDataSet(ServiceError):
    OTHER = 0
    PRIMITIVE_OUT_OF_SEQUENCE = 1
    NOT_LOADABLE = 2
    DATASET_SIZE_TOO_LARGE = 3
    NOT_AWAITED_SEGMENT = 4
    INTERPRETATION_FAILURE = 5
    STORAGE_FAILURE = 6
    DATA_SET_NOT_READY = 7

class Task(ServiceError):
    OTHER = 0
    NO_REMOTE_CONTROL = 1
    TI_STOPPED = 2
    TI_RUNNING = 3
    TI_UNUSABLE = 4

