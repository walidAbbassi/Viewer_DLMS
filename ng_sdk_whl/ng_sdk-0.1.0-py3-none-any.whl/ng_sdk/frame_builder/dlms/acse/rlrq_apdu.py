from typing import ClassVar, Optional

from attr import define
from attrs import field

from ng_sdk.frame_builder.dlms.acse.models.initiate_request import InitiateRequest
from ng_sdk.frame_builder.dlms.acse.models.release_reason import ReleaseRequestReason
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.tag_length_value import TagLengthValue


@define
class RLRQ:
    TAG: ClassVar[int] = 0x62

    user_information: Optional[InitiateRequest] = field(default=None)
    reason: ReleaseRequestReason = field(default=ReleaseRequestReason.NORMAL)

    def to_bytes(self, security_context: Optional[SecurityContext] = None):
        apdu = bytearray()
        if self.reason is not None:
            apdu.extend(TagLengthValue.to_tlv(0x80, self.reason.to_bytes(1, "big")))
        if self.user_information is not None:
            apdu.extend(TagLengthValue.to_tlv(0xBE, TagLengthValue.to_tlv(0x04, self.user_information.to_bytes(
                security_context))))
        return TagLengthValue.to_tlv(self.TAG, apdu)
