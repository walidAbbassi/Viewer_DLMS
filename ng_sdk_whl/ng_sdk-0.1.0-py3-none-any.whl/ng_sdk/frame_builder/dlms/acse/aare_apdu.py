from typing import ClassVar, Optional, Any

from attr import define, field

from ng_sdk.frame_builder.dlms.acse.models.association_result import AssociationResult
from ng_sdk.frame_builder.dlms.acse.models.authentication_functional_unit import AuthenticationFunctionalUnit
from ng_sdk.frame_builder.dlms.acse.models.authentication_value import AuthenticationValue
from ng_sdk.frame_builder.dlms.acse.models.object_identifier import ObjectIdentifier
from ng_sdk.frame_builder.dlms.acse.models.result_source_diagnostics import ResultSourceDiagnostics
from ng_sdk.frame_builder.dlms.acse.models.user_information_response import UserInformationResponse
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.tag_length_value import TagLengthValue


@define
class AARE:
    TAG: ClassVar[int] = 0x61

    PARSE_TAGS = {
        0x80: ("protocol_version", None),  # Context specific, constructed? 0
        0xA1: ("application_context_name", ObjectIdentifier),
        0xA2: ("result", AssociationResult),
        0xA3: ("result_source_diagnostic", ResultSourceDiagnostics),
        0xA4: ("responding_ap_title", None),
        0xA5: ("responding_ae_qualifier", None),
        0xA6: ("responding_ap_invocation_id", None),
        0xA7: ("responding_ae_invocation_id", None),
        0x88: ("responder_acse_requirements", AuthenticationFunctionalUnit),
        0x89: ("mechanism_name", ObjectIdentifier, True),
        0xAA: ("responding_authentication_value", AuthenticationValue),
        0xBD: ("implementation_information", None),
        0xBE: ("user_information", UserInformationResponse),  # Context specific, constructed 30
    }

    application_context_name: ObjectIdentifier
    user_information: UserInformationResponse
    result: AssociationResult
    result_source_diagnostic: ResultSourceDiagnostics

    protocol_version: Optional[bytes] = field(default=None)
    responding_ap_title: Optional[bytes] = field(default=None)
    responding_ae_qualifier: Optional[bytes] = field(default=None)
    responding_ap_invocation_id: Optional[bytes] = field(default=None)
    responding_ae_invocation_id: Optional[bytes] = field(default=None)
    responder_acse_requirements: Optional[AuthenticationFunctionalUnit] = field(default=None)
    mechanism_name: Optional[ObjectIdentifier] = field(default=None)
    responding_authentication_value: Optional[AuthenticationValue] = field(default=None)
    implementation_information: Optional[bytes] = field(default=None)

    def to_bytes(self):
        pass

    @classmethod
    def from_bytes(cls, source_bytes: bytes, security_context: Optional[SecurityContext] = None):
        aare_data = bytearray(source_bytes)

        aare_tag = aare_data.pop(0)
        if not aare_tag == cls.TAG:
            raise ValueError("Bytes are not an AARE APDU. TAg is not int(96)")

        aare_length = aare_data.pop(0)

        if not len(aare_data) == aare_length:
            raise ValueError(
                "The APDU Data length does not correspond " "to length byte"
            )

        object_dict = dict()
        while True:
            object_tag = aare_data.pop(0)
            object_desc = AARE.PARSE_TAGS.get(
                object_tag, None
            )
            if object_desc is None:
                raise ValueError(
                    f"Could not find object with tag {object_tag} "
                    f"in AARE definition"
                )
            object_length = aare_data.pop(0)
            object_data = bytes(aare_data[:object_length])
            aare_data = aare_data[object_length:]

            object_name = object_desc[0]
            object_class: Any = object_desc[1]

            if object_class is not None:
                if len(object_desc) > 2:
                    object_data = object_class.from_bytes(object_data, object_desc[2])
                else:
                    if object_class == UserInformationResponse:
                        object_data = object_class.from_bytes(object_data, security_context)
                    else:
                        object_data = object_class.from_bytes(object_data)
            else:
                tag, length, data = TagLengthValue.from_bytes(object_data)
                object_data = data
            object_dict[object_name] = object_data

            if object_name == "responding_ap_title" and security_context is not None:
                security_context.set_server_system_title(object_data)

            if len(aare_data) <= 0:
                break
        return cls(**object_dict)
