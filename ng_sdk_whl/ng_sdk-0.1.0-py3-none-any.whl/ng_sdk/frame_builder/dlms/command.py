from enum import IntEnum


class Command(IntEnum):
    GET_REQUEST = 0xC0
    SET_REQUEST = 0xC1
    ACTION_REQUEST = 0xC3



