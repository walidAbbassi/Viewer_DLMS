import string
from typing import List, Optional

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.meter_frame_type import MeterFrameType
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.bytes_util import obis_code_to_bytes


class DLMSFrameRequest(AbstractFrameRequest):
    def __init__(self,command:Command, class_id :int,obis_code:str, attribute:int, payload: bytes):
        super().__init__(payload)
        self.command = command
        self.class_id = class_id
        self.obis_code = obis_code
        self.attribute = attribute


    def to_bytes(self,security_context: Optional[SecurityContext] = None) -> bytes:
        out = bytearray()
        out.append(self.command)
        out.append(MeterFrameType.REQUEST_NORMAL)
        out.append(Constant.INVOKED_ID)
        out.extend(bytes([self.class_id]))
        out.extend(obis_code_to_bytes(self.obis_code))
        out.extend(bytes([self.attribute]))
        if not self.payload or len(self.payload) == 0:
            out.append(0x00)
        else:
            out.extend(self.payload)
        return bytes(out)

    @classmethod
    def all_instances_of(cls,obj_list: List[AbstractFrameRequest], clss):
        return all(isinstance(obj, clss) for obj in obj_list)
