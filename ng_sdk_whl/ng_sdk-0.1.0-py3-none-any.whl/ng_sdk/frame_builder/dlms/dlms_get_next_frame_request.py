from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command


class DlmsGetNextFrameRequest(AbstractFrameRequest):
    def __init__(self, command:Command, last_block: bool, payload: bytes):
        super().__init__(payload)
        self.last_block = last_block
        self.command = command


