from enum import IntEnum


class Command(IntEnum):
    GET_REQUEST = 0xC0
    SET_REQUEST = 0xC1
    ACTION_REQUEST = 0xC3
    GET_RESPONSE = 0xC4
    SET_RESPONSE = 0xC5
    ACTION_RESPONSE = 0xC7
    EXCEPTION_RESPONSE = 0xD8


class GetRequestType(IntEnum):
    NORMAL = 1
    NEXT = 2
    WITH_LIST = 3

class GetResponseType(IntEnum):
    NORMAL = 1
    NEXT = 2
    WITH_LIST = 3


class SetRequestType(IntEnum):
    NORMAL = 1
    WITH_FIRST_DATABLOCK = 2
    WITH_DATABLOCK = 3
    WITH_LIST = 4
    WITH_LIST_AND_FIRST_DATABLOCK = 5

class SetResponseType(IntEnum):
    NORMAL = 1
    DATABLOCK = 2
    LAST_DATABLOCK = 3
    LAST_DATABLOCK_WITH_LIST = 4
    WITH_LIST = 5


class ActionRequestType(IntEnum):
    NORMAL = 1
    NEXT_PBLOCK = 2
    WITH_LIST = 3
    WITH_FIRST_PBLOCK = 4
    WITH_LIST_AND_FIRST_PBLOCK = 5
    WITH_PBLOCK = 6

class ActionResponseType(IntEnum):
    NORMAL = 1
    WITH_PBLOCK = 2
    WITH_LIST = 3
    NEXT_PBLOCK = 4


class DataAccessResult(IntEnum):
    SUCCESS = 0
    HARDWARE_FAULT = 1
    TEMPORARY_FAILURE = 2
    READ_WRITE_DENIED = 3
    OBJECT_UNDEFINED = 4
    OBJECT_CLASS_INCONSISTENT = 9
    OBJECT_UNAVAILABLE = 11
    TYPE_UNMATCHED = 12
    SCOPE_OF_ACCESS_VIOLATED = 13
    DATA_BLOCK_UNAVAILABLE = 14
    LONG_GET_ABORTED = 15
    NO_LONG_GET_IN_PROGRESS = 16
    LONG_SET_ABORTED = 17
    NO_LONG_SET_IN_PROGRESS = 18
    DATA_BLOCK_NUMBER_INVALID = 19
    OTHER_REASON = 250
    UNKNOWN_ERROR_TYPE = 999

    @classmethod
    def from_value(cls, value):
        return cls._value2member_map_.get(value, cls.UNKNOWN_ERROR_TYPE)


class ActionResult(IntEnum):
    SUCCESS = 0
    HARDWARE_FAULT = 1
    TEMPORARY_FAILURE = 2
    READ_WRITE_DENIED = 3
    OBJECT_UNDEFINED = 4
    OBJECT_CLASS_INCONSISTENT = 9
    OBJECT_UNAVAILABLE = 11
    TYPE_UNMATCHED = 12
    SCOPE_OF_ACCESS_VIOLATED = 13
    DATA_BLOCK_UNAVAILABLE = 14
    LONG_ACTION_ABORTED = 15
    NO_LONG_ACTION_IN_PROGRESS = 16
    DATA_BLOCK_NUMBER_INVALID = 19
    OTHER_REASON = 250
    UNKNOWN_ERROR_TYPE = 999

    @classmethod
    def from_value(cls, value):
        return cls._value2member_map_.get(value, cls.UNKNOWN_ERROR_TYPE)

class NotificationSelfDescriptive(IntEnum):
        NOT_SELF_DESCRIPTIVE = 0
        SELF_DESCRIPTIVE = 1
        UNKNOWN = 2

        @classmethod
        def from_value(cls, value):
            return cls._value2member_map_.get(value, cls.UNKNOWN)

class NotificationProcessingOption(IntEnum):
        CONTINUE_ON_ERROR = 0
        BREAK_ON_ERROR = 1
        UNKNOWN = 2

        @classmethod
        def from_value(cls, value):
            return cls._value2member_map_.get(value, cls.UNKNOWN)

class NotificationServiceClass(IntEnum):
        UNCONFIRMED = 0
        CONFIRMED = 1
        UNKNOWN = 2

        @classmethod
        def from_value(cls, value):
            return cls._value2member_map_.get(value, cls.UNKNOWN)

class NotificationPriority(IntEnum):
        NORMAL = 0
        HIGH = 1
        UNKNOWN = 2

        @classmethod
        def from_value(cls, value):
            return cls._value2member_map_.get(value, cls.UNKNOWN)

