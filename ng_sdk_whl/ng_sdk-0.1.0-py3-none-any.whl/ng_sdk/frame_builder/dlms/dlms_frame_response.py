from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse


class DLMSFrameResponse(AbstractFrameResponse):
    def __init__(self, frame: bytes):
        super().__init__(bytearray(frame))

    def parse(self):
        data = self.frame