from typing import List

from ng_sdk.configuration.config_manager import ConfigModuleProxy
from ng_sdk.error.frame_builder_exception import FrameBuilderException, FrameBuilderError
from ng_sdk.frame_builder.abstract_frame_builder import AbstractFrameBuilder
from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.dlms_enums import Command, GetResponseType, SetResponseType, \
    ActionResponseType
from ng_sdk.frame_builder.dlms.dlms_frame_request import DLMSFrameRequest
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_normal import DLMSActionRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_with_first_pblock import \
    DLMSActionRequestWithFirstPblock
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_with_list import DLMSActionRequestWithList
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_with_list_and_first_pblock import \
    DLMSActionRequestWithListAndFirstPblock
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_with_pblock import DLMSActionRequestWithPblock
from ng_sdk.frame_builder.dlms.xdlms.action.response.dlms_action_response_next_pblock import \
    DLMSActionResponseNextPblock
from ng_sdk.frame_builder.dlms.xdlms.action.response.dlms_action_response_normal import DLMSActionResponseNormal
from ng_sdk.frame_builder.dlms.xdlms.action.response.dlms_action_response_with_list import DLMSActionResponseWithList
from ng_sdk.frame_builder.dlms.xdlms.action.response.dlms_action_response_with_pblock import \
    DLMSActionResponseWithPblock
from ng_sdk.frame_builder.dlms.xdlms.datablock_sa import DataBlockSA
from ng_sdk.frame_builder.dlms.xdlms.exception.dlms_exception_response import DLMSExceptionResponse
from ng_sdk.frame_builder.dlms.xdlms.get.request.dlms_get_request_normal import DLMSGetRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.get.request.dlms_get_request_with_list import DLMSGetRequestWithList
from ng_sdk.frame_builder.dlms.xdlms.get.response.dlms_get_response_normal import DLMSGetResponseNormal
from ng_sdk.frame_builder.dlms.xdlms.get.response.dlms_get_response_with_datablock import DLMSGetResponseWithDatablock
from ng_sdk.frame_builder.dlms.xdlms.get.response.dlms_get_response_with_list import DLMSGetResponseWithList
from ng_sdk.frame_builder.dlms.xdlms.set.request.dlms_set_request_normal import DLMSSetRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.set.request.dlms_set_request_with_datablock import DLMSSetRequestWithDatablock
from ng_sdk.frame_builder.dlms.xdlms.set.request.dlms_set_request_with_first_datablock import \
    DLMSSetRequestWithFirstDatablock
from ng_sdk.frame_builder.dlms.xdlms.set.request.dlms_set_request_with_list import DLMSSetRequestWithList
from ng_sdk.frame_builder.dlms.xdlms.set.request.dlms_set_request_with_list_and_first_datablock import \
    DLMSSetRequestWithListAndFirstDatablock
from ng_sdk.frame_builder.dlms.xdlms.set.response.dlms_set_response_datablock import DLMSSetResponseDatablock
from ng_sdk.frame_builder.dlms.xdlms.set.response.dlms_set_response_last_datablock import DLMSSetResponseLastDatablock
from ng_sdk.frame_builder.dlms.xdlms.set.response.dlms_set_response_last_datablock_with_list import \
    DLMSSetResponseLastDatablockWithList
from ng_sdk.frame_builder.dlms.xdlms.set.response.dlms_set_response_normal import DLMSSetResponseNormal
from ng_sdk.frame_builder.dlms.xdlms.set.response.dlms_set_response_with_list import DLMSSetResponseWithList
from ng_sdk.frame_builder.meter_request import MeterRequest
from ng_sdk.frame_builder.meter_response import MeterResponse
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.security.security_constant import DlmsCipheringType
from ng_sdk.util.bytes_util import extract_length
from ng_sdk.util.tag_length_value import TagLengthValue

logger = get_logger()

_mod = {LoggingConstants.MODULES_NAME: "DLMSFrameBuilder"}  # module tag for logs


class DLMSFrameBuilder(AbstractFrameBuilder):

    def build(self, requests: List[AbstractFrameRequest], with_list: bool) -> List[MeterRequest]:
        max_apdu_size_bytes = self.configuration.session.buffer_size

        split_request = self.configuration.frame_builder.split_request
        if isinstance(split_request, ConfigModuleProxy):
            split_request = False
        if len(requests) == 0:
            return []
        frame = []
        if not with_list or not (DLMSFrameRequest.all_instances_of(requests,
                                                                   DLMSActionRequestNormal) or DLMSFrameRequest.all_instances_of(
            requests, DLMSGetRequestNormal) or DLMSFrameRequest.all_instances_of(requests, DLMSSetRequestNormal)):
            for request in requests:
                if split_request and len(request.to_bytes(self.security_context)) > max_apdu_size_bytes:
                    if isinstance(request, DLMSSetRequestNormal):
                        frame.append(MeterRequest(self.__build_set_normal_block(request, max_apdu_size_bytes), request))
                    elif isinstance(request, DLMSActionRequestNormal):
                        frame.append(
                            MeterRequest(self.__build_action_normal_block(request, max_apdu_size_bytes), request))
                    else:
                        frame.append(MeterRequest([request.to_bytes(self.security_context)], request))
                else:
                    frame.append(MeterRequest([request.to_bytes(self.security_context)], request))
        else:
            if isinstance(requests[0], DLMSActionRequestNormal):
                with_list_request = DLMSActionRequestWithList(requests)
            elif isinstance(requests[0], DLMSGetRequestNormal):
                with_list_request = DLMSGetRequestWithList(requests)
            else:
                with_list_request = DLMSSetRequestWithList(requests)
            if split_request and len(with_list_request.to_bytes(self.security_context)) > max_apdu_size_bytes:

                if isinstance(with_list_request, DLMSActionRequestWithList):
                    frame.append(MeterRequest(
                        self.__build_action_with_list_block(requests, with_list_request.payload, max_apdu_size_bytes),
                        with_list_request))
                elif isinstance(with_list_request, DLMSSetRequestWithList):
                    frame.append(MeterRequest(
                        self.__build_set_with_list_block(requests, with_list_request.payload, max_apdu_size_bytes),
                        with_list_request))
                else:
                    frame.append(MeterRequest([with_list_request.to_bytes(self.security_context)], with_list_request))
            else:
                frame.append(MeterRequest([with_list_request.to_bytes(self.security_context)], with_list_request))

        return frame

    def parse(self, meter_response: MeterResponse) -> AbstractFrameResponse:
        if meter_response.frame[0] == Command.EXCEPTION_RESPONSE:
            return DLMSExceptionResponse(meter_response.frame[1:])
        if self.security_context is not None and self.security_context.configuration.security.ciphering_type != DlmsCipheringType.NO_CIPHERING:
            if self.security_context.configuration.security.ciphering_type == DlmsCipheringType.GLOBAL_CIPHERING or self.security_context.configuration.security.ciphering_type == DlmsCipheringType.DEDICATED_CIPHERING:
                tag, length, data = TagLengthValue.from_bytes(meter_response.frame)
            elif self.security_context.configuration.security.ciphering_type == DlmsCipheringType.GENERAL_GLOBAL_CIPHERING or DlmsCipheringType.GENERAL_DEDICATED_CIPHERING:
                print("meter_response.frame", meter_response.frame.hex().upper())
                data = meter_response.frame
                tag = data[:1]
                data = data[1:]
                ap_title_length = int.from_bytes(data[:1], "big")
                data = data[1:]
                self.security_context.set_server_system_title(data[:ap_title_length])
                data = data[8:]
                length, data = extract_length(data)

            else:
                raise NotImplementedError
            meter_response.frame = self.security_context.decipher(data)
            logger.info(f"Plain:{meter_response.frame.hex().upper()} ",
                        **_mod)
        frame = bytearray(meter_response.frame)
        response_type = Command(frame.pop(0))
        if response_type == Command.GET_RESPONSE:
            response_get_type = GetResponseType(frame.pop(0))
            match response_get_type:
                case GetResponseType.NORMAL:
                    return DLMSGetResponseNormal(frame)
                case GetResponseType.NEXT:
                    return DLMSGetResponseWithDatablock(frame)
                case GetResponseType.WITH_LIST:
                    return DLMSGetResponseWithList(frame)
            raise FrameBuilderException(FrameBuilderError.RESPONSE_PARSING_ERROR)
        elif response_type == Command.SET_RESPONSE:
            response_set_type = SetResponseType(frame.pop(0))
            match response_set_type:
                case SetResponseType.NORMAL:
                    return DLMSSetResponseNormal(frame)
                case SetResponseType.WITH_LIST:
                    return DLMSSetResponseWithList(frame)
                case SetResponseType.DATABLOCK:
                    return DLMSSetResponseDatablock(frame)
                case SetResponseType.LAST_DATABLOCK:
                    return DLMSSetResponseLastDatablock(frame)
                case SetResponseType.LAST_DATABLOCK_WITH_LIST:
                    return DLMSSetResponseLastDatablockWithList(frame)
            raise FrameBuilderException(FrameBuilderError.RESPONSE_PARSING_ERROR)
        elif response_type == Command.ACTION_RESPONSE:
            response_action_type = ActionResponseType(frame.pop(0))
            match response_action_type:
                case ActionResponseType.NORMAL:
                    return DLMSActionResponseNormal(frame)
                case ActionResponseType.WITH_LIST:
                    return DLMSActionResponseWithList(frame)
                case ActionResponseType.WITH_PBLOCK:
                    return DLMSActionResponseWithPblock(frame)
                case ActionResponseType.NEXT_PBLOCK:
                    return DLMSActionResponseNextPblock(frame)
            raise FrameBuilderException(FrameBuilderError.RESPONSE_PARSING_ERROR)

        raise FrameBuilderException(FrameBuilderError.RESPONSE_PARSING_ERROR)

    def __build_set_normal_block(self, request: DLMSSetRequestNormal, max_apdu_size_bytes) -> List[bytes]:
        requests = []
        blocks = self.__to_data_blocks(request.payload, max_apdu_size_bytes - 19, max_apdu_size_bytes)
        requests.append(DLMSSetRequestWithFirstDatablock(request.class_id, request.obis_code, request.attribute,
                                                         blocks[0]).to_bytes(self.security_context))
        for i in range(1, len(blocks)):
            requests.append(DLMSSetRequestWithDatablock(blocks[i]).to_bytes(self.security_context))
        return requests

    def __build_set_with_list_block(self, requests: List[DLMSSetRequestNormal], all_payloads: bytes,
                                    max_apdu_size_bytes) -> List[bytes]:
        requests_frames = []
        blocks = self.__to_data_blocks(all_payloads, max_apdu_size_bytes - 19, max_apdu_size_bytes)
        requests_frames.append(
            DLMSSetRequestWithListAndFirstDatablock(requests, blocks[0]).to_bytes(self.security_context))
        for i in range(1, len(blocks)):
            requests_frames.append(DLMSSetRequestWithDatablock(blocks[i]).to_bytes(self.security_context))
        return requests_frames

    def __build_action_normal_block(self, request: DLMSActionRequestNormal, max_apdu_size_bytes) -> List[bytes]:
        requests = []
        blocks = self.__to_data_blocks(request.payload, max_apdu_size_bytes - 19, max_apdu_size_bytes)
        requests.append(
            DLMSActionRequestWithFirstPblock(request.class_id, request.obis_code, request.method, blocks[0]).to_bytes(
                self.security_context))
        for i in range(1, len(blocks)):
            requests.append(DLMSActionRequestWithPblock(blocks[i]).to_bytes(self.security_context))
        return requests

    def __build_action_with_list_block(self, requests: List[DLMSActionRequestNormal], all_payloads: bytes,
                                       max_apdu_size_bytes) -> List[bytes]:
        requests_frames = []
        blocks = self.__to_data_blocks(all_payloads, max_apdu_size_bytes - 19, max_apdu_size_bytes)
        requests_frames.append(
            DLMSActionRequestWithListAndFirstPblock(requests, blocks[0]).to_bytes(self.security_context))
        for i in range(1, len(blocks)):
            requests_frames.append(DLMSActionRequestWithPblock(blocks[i]).to_bytes(self.security_context))
        return requests_frames

    def __to_data_blocks(self, data: bytes, first_block_size: int, max_apdu_size_bytes) -> List[DataBlockSA]:

        blocks = []

        # Handle first block
        first_chunk = data[:first_block_size]
        remaining_payload = data[first_block_size:]

        blocks.append(DataBlockSA(
            last_block=(len(remaining_payload) == 0),
            block_number=1,
            raw_data=first_chunk
        ))

        # Handle remaining blocks
        for i in range(0, len(remaining_payload), max_apdu_size_bytes):
            chunk = remaining_payload[i:i + max_apdu_size_bytes]
            block_number = 2 + (i // max_apdu_size_bytes)
            last_block = (i + max_apdu_size_bytes) >= len(remaining_payload)
            blocks.append(DataBlockSA(last_block, block_number, chunk))
        return blocks
