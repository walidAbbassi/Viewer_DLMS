from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command


class DlmsSetBlockFrameRequest(AbstractFrameRequest):
    def __init__(self, command:Command, first_block: bool, last_block: bool, payload: bytes):
        super().__init__(payload)
        self.first_block = first_block
        self.last_block = last_block
        self.command = command


