from ng_sdk.util.bytes_util import bytearray_pop_range


class DataBlockSA:
    last_block : bool
    block_number : int
    raw_data : bytes
    def __init__(self,last_block: bool,block_number : int,raw_data: bytes):
        self.last_block = last_block
        self.block_number = block_number
        self.raw_data = raw_data

    def to_bytes(self) -> bytes :
        out = bytearray()
        out.extend(bytes([self.last_block]))
        out.extend(self.block_number.to_bytes(4, "big"))
        out.extend(bytes([len(self.raw_data)]))
        out.extend(self.raw_data)
        return out

    @classmethod
    def from_bytes(cls,frame:bytes):
        bytearray_frame = bytearray(frame)
        last_block = True if bytearray_frame.pop(0) else False
        block_number = int.from_bytes(bytearray_pop_range(bytearray_frame, 0, 4), 'big')
        raw_data = bytearray_frame
        return cls(last_block,block_number,raw_data)
