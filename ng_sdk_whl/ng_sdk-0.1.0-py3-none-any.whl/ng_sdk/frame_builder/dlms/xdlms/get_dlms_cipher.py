from ng_sdk.frame_builder.dlms.xdlms.base_dlms_cipher import BaseDlmsCipher


class GetDlmsCipher(BaseDlmsCipher):
    GLOBAL_CIPHERING = 0xC8
    DEDICATED_CIPHERING = 0xD0
    GENERAL_CIPHERING = 0xDB