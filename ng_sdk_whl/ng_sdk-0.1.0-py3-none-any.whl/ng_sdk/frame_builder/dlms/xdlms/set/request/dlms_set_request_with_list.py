from typing import List, Optional

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command, SetRequestType
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.set.request.dlms_set_request_normal import DLMSSetRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.set_dlms_cipher import SetDlmsCipher
from ng_sdk.security.security_constant import DlmsCipheringType
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.bytes_util import obis_code_to_bytes
from ng_sdk.util.tag_length_value import TagLengthValue


class DLMSSetRequestWithList(AbstractFrameRequest,SetDlmsCipher):
    def __init__(self, cosem_attribute_descriptor_list : List[DLMSSetRequestNormal]):
        super().__init__(bytes())
        self.command = Command.SET_REQUEST
        self.cosem_attribute_descriptor_list = cosem_attribute_descriptor_list



    def to_bytes(self,security_context: Optional[SecurityContext] = None) -> bytes:
        out = bytearray()
        descriptors = bytearray()
        values = bytearray()
        out.append(self.command)
        out.append(SetRequestType.WITH_LIST)
        out.append(Constant.INVOKED_ID)
        for cosem_object in self.cosem_attribute_descriptor_list:
            descriptors.extend(cosem_object.class_id.to_bytes(2, "big"))
            descriptors.extend(obis_code_to_bytes(cosem_object.obis_code))
            descriptors.extend(bytes([cosem_object.attribute]))
            if not cosem_object.selective_access:
                descriptors.append(0x00)
            else:
                descriptors.extend(cosem_object.selective_access.to_bytes())
            values.extend(cosem_object.payload)
        length = len(self.cosem_attribute_descriptor_list)
        self.payload = values
        out.extend(length.to_bytes(1, "big"))
        out.extend(bytes(descriptors))
        out.extend(length.to_bytes(1, "big"))
        out.extend(bytes(values))
        if security_context is not None:
            return self.cipher(security_context, out)
        return out
