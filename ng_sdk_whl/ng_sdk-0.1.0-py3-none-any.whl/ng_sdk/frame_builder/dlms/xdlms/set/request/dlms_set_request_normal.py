import string
from typing import Optional

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command, SetRequestType
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.selective_access.abstract_selective_access import AbstractSelectiveAccess
from ng_sdk.frame_builder.dlms.xdlms.set_dlms_cipher import SetDlmsCipher
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.bytes_util import obis_code_to_bytes


class DLMSSetRequestNormal(AbstractFrameRequest,SetDlmsCipher):
    def __init__(self, class_id :int,obis_code:str, attribute:int, payload:bytes,selective_access:AbstractSelectiveAccess=None):
        super().__init__(bytes())
        self.command = Command.SET_REQUEST
        self.class_id = class_id
        self.obis_code = obis_code
        self.attribute = attribute
        self.selective_access = selective_access
        self.payload = payload


    def to_bytes(self,security_context: Optional[SecurityContext] = None) -> bytes:
        out = bytearray()
        out.append(self.command)
        out.append(SetRequestType.NORMAL)
        out.append(Constant.INVOKED_ID)
        out.extend(self.class_id.to_bytes(2, "big"))
        out.extend(obis_code_to_bytes(self.obis_code))
        out.extend(bytes([self.attribute]))
        if not self.selective_access:
            out.append(0x00)
        else:
            out.extend(self.selective_access.to_bytes())
        out.extend(self.payload)
        if security_context is not None:
            return self.cipher(security_context, out)
        return out
