from typing import Optional

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command, SetRequestType
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.datablock_sa import DataBlockSA
from ng_sdk.frame_builder.dlms.xdlms.set_dlms_cipher import SetDlmsCipher
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.tag_length_value import TagLengthValue


class DLMSSetRequestWithDatablock(AbstractFrameRequest,SetDlmsCipher):
    def __init__(self, datablock:DataBlockSA):
        super().__init__(datablock.to_bytes())
        self.command = Command.SET_REQUEST




    def to_bytes(self,security_context: Optional[SecurityContext] = None) -> bytes:
        out = bytearray()
        out.append(self.command)
        out.append(SetRequestType.WITH_DATABLOCK)
        out.append(Constant.INVOKED_ID)
        out.extend(self.payload)
        if security_context is not None:
            return self.cipher(security_context, out)
        return out
