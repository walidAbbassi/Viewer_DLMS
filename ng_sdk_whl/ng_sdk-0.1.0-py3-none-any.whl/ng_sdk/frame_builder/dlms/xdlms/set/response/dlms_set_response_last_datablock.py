from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.dlms_enums import DataAccessResult
from ng_sdk.util.bytes_util import bytearray_pop_range


class DLMSSetResponseLastDatablock(AbstractFrameResponse):
    data_access_result : DataAccessResult
    invoked_id : int
    block_number : int
    def __init__(self, frame:bytes):
        super().__init__(bytearray(frame))
        self.invoked_id = self.frame.pop(0)
        self.data_access_result = DataAccessResult.from_value(self.frame.pop(0))
        self.block_number = int.from_bytes(bytearray_pop_range(self.frame, 0, 4), 'big')

    def is_success(self):
        return self.data_access_result == DataAccessResult.SUCCESS
