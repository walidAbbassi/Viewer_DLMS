from typing import List

from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.dlms_enums import DataAccessResult
from ng_sdk.util.bytes_util import bytearray_pop_range


class DLMSSetResponseLastDatablockWithList(AbstractFrameResponse):

    invoked_id : int
    result : List[DataAccessResult] = []
    block_number : int
    def __init__(self, frame:bytes):
        super().__init__(bytearray(frame))
        self.invoked_id = self.frame.pop(0)
        result_length = int(self.frame.pop(0))
        for i in range(0,result_length):
            self.result.append(DataAccessResult.from_value(self.frame.pop(0)))
        self.block_number = int.from_bytes(bytearray_pop_range(self.frame, 0, 4), 'big')
        if result_length != len(self.result):
            raise Exception
