from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.dlms_enums import DataAccessResult

class DLMSSetResponseNormal(AbstractFrameResponse):
    data_access_result : DataAccessResult
    invoked_id : int
    def __init__(self, frame:bytes):
        super().__init__(bytearray(frame))
        self.invoked_id = self.frame.pop(0)
        self.data_access_result = DataAccessResult.from_value(self.frame.pop(0))

    def is_success(self):
        return self.data_access_result == DataAccessResult.SUCCESS
