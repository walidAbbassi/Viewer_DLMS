from typing import List

from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.dlms_enums import Command, DataAccessResult, SetResponseType


class DLMSSetResponseWithList(AbstractFrameResponse):

    invoked_id : int
    result : List[DataAccessResult] = []
    def __init__(self, frame:bytes):
        self.result = []
        super().__init__(bytearray(frame))
        received_frame = bytearray(frame)
        self.invoked_id = received_frame.pop(0)
        result_length = int(received_frame.pop(0))
        while len(received_frame) != 0 :
            self.result.append(DataAccessResult.from_value(received_frame.pop(0)))

        if result_length != len(self.result):
            raise Exception

    def to_bytes(self) -> bytes:
        return bytes([Command.SET_RESPONSE, SetResponseType.WITH_LIST]) + self.frame

