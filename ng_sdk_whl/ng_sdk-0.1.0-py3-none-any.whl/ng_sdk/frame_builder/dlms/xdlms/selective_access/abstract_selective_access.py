from abc import abstractmethod, ABC


class AbstractSelectiveAccess(ABC):
    access_selector:int

    @abstractmethod
    def to_bytes(self) -> bytes:
        pass

