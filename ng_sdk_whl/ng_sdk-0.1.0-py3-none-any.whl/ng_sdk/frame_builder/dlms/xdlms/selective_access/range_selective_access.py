from typing import Optional, List

from ng_sdk.frame_builder.dlms.xdlms.data_type.array import ArrayData
from ng_sdk.frame_builder.dlms.xdlms.data_type.structure import StructureData
from ng_sdk.frame_builder.dlms.xdlms.selective_access.abstract_selective_access import AbstractSelectiveAccess
from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType
from ng_sdk.frame_builder.dlms.xdlms.selective_access.capture_object_definition import CaptureObjectDefinition


class RangeSelectiveAccess(AbstractSelectiveAccess):
    def __init__(self,from_value: AbstractDlmsType,to_value: AbstractDlmsType,restricting_object: Optional[CaptureObjectDefinition]=None,selected_values:List[CaptureObjectDefinition]=[]):
        super().__init__()
        self.from_value =  from_value
        self.to_value = to_value
        self.restricting_object = restricting_object
        self.selected_values = selected_values


    access_selector = 0x01


    def to_bytes(self) -> bytes:
        out = bytearray()
        out.append(self.access_selector)
        structure = StructureData(value=[self.restricting_object.to_structure() if self.restricting_object is not None else StructureData(value=[]),self.from_value,self.to_value,ArrayData(value=list(map(lambda selected_value: selected_value.to_structure(), self.selected_values)))])
        out.extend(structure.to_bytes())
        return bytes(out)

