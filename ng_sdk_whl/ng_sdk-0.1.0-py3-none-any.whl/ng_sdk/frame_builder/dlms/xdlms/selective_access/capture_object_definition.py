from dataclasses import dataclass, field
from typing import Optional

from ng_sdk.frame_builder.dlms.xdlms.data_type.integer_8 import Integer8
from ng_sdk.frame_builder.dlms.xdlms.data_type.octet_string import OctetStringData
from ng_sdk.frame_builder.dlms.xdlms.data_type.structure import StructureData
from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_16 import Unsigned16
from ng_sdk.frame_builder.dlms.xdlms.selective_access.restriction_element import RestrictionElement, RestrictionType


@dataclass
class CaptureObjectDefinition:
    class_id: int
    logical_name: bytes
    attribute_index: int
    data_index: int
    restriction: Optional[RestrictionElement] = None


    def to_structure(self) -> StructureData:
        if self.restriction is None:
            values = [Unsigned16(value=self.class_id), OctetStringData(value=self.logical_name),
                      Integer8(value=self.attribute_index), Unsigned16(value=self.data_index) ]
        else:
            values = [Unsigned16(value=self.class_id),OctetStringData(value=self.logical_name),Integer8(value=self.attribute_index),Unsigned16(value=self.data_index),self.restriction.to_structure()]
        return StructureData(value=values)