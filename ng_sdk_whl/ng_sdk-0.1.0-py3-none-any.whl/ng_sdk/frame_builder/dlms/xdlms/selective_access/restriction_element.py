from dataclasses import dataclass
from enum import IntEnum
from typing import Optional
from ng_sdk.frame_builder.dlms.xdlms.data_type.enum import EnumData
from ng_sdk.frame_builder.dlms.xdlms.data_type.null_data import NullData
from ng_sdk.frame_builder.dlms.xdlms.data_type.octet_string import OctetStringData
from ng_sdk.frame_builder.dlms.xdlms.data_type.structure import StructureData
from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_32 import Unsigned32


class RestrictionType(IntEnum):
    None_Restriction = 0
    Restriction_By_Date = 1
    Restriction_By_Entry = 2


@dataclass
class RestrictionByDate:
    from_date: OctetStringData
    to_date: OctetStringData

@dataclass
class RestrictionByEntry:
    from_entry: Unsigned32
    to_entry: Unsigned32

@dataclass
class RestrictionElement:
    restriction_type:RestrictionType = RestrictionType.None_Restriction
    restriction_value: Optional[RestrictionByDate|RestrictionByEntry] = None

    def to_structure(self) -> StructureData:
        values =[]
        if self.restriction_type == RestrictionType.None_Restriction:
            values=[EnumData(value=self.restriction_type.value),NullData()]
        elif self.restriction_type == RestrictionType.Restriction_By_Date:
            if isinstance(self.restriction_value, RestrictionByDate):
                values=[EnumData(value=self.restriction_type.value),StructureData(value=[self.restriction_value.from_date,self.restriction_value.to_date])]
        elif self.restriction_type == RestrictionType.Restriction_By_Entry:
            if isinstance(self.restriction_value, RestrictionByEntry):
                values = [EnumData(value=self.restriction_type.value),
                          StructureData(value=[self.restriction_value.from_entry, self.restriction_value.to_entry])]

        return StructureData(value=values)