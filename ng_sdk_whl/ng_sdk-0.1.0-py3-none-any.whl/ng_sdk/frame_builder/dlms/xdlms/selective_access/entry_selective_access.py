from ng_sdk.frame_builder.dlms.xdlms.data_type.structure import StructureData
from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_16 import Unsigned16
from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_32 import Unsigned32
from ng_sdk.frame_builder.dlms.xdlms.selective_access.abstract_selective_access import AbstractSelectiveAccess


class EntrySelectiveAccess(AbstractSelectiveAccess):

    def __init__(self, from_value: Unsigned32, to_value: Unsigned32,from_selected_value:Unsigned16, to_selected_value:Unsigned16):
        super().__init__()
        self.from_value = from_value
        self.to_value = to_value
        self.from_selected_value = from_selected_value
        self.to_selected_value = to_selected_value

    access_selector = 0x02

    def to_bytes(self) -> bytes:
        out = bytearray()
        out.append(self.access_selector)
        structure = StructureData(value=[self.from_value, self.to_value, self.from_selected_value, self.to_selected_value])
        out.extend(structure.to_bytes())
        return out