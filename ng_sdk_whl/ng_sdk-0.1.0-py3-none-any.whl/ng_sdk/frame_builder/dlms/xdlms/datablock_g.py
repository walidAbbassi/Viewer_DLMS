from ng_sdk.frame_builder.dlms.dlms_enums import DataAccessResult
from ng_sdk.util.bytes_util import bytearray_pop_range, extract_length


class DataBlockG:
    last_block: bool
    block_number: int
    raw_data: bytes
    data_access_result: DataAccessResult

    def __init__(self, frame: bytes):
        bytearray_frame = bytearray(frame)
        self.last_block = bytearray_frame.pop(0) == 1
        self.block_number = int.from_bytes(bytearray_pop_range(bytearray_frame, 0, 4), 'big')
        encoded_response_status = bytearray_frame.pop(0)
        self.data_access_result = DataAccessResult.SUCCESS
        if encoded_response_status != DataAccessResult.SUCCESS:
            self.data_access_result = DataAccessResult.from_value(bytearray_frame.pop(0))
        length,bytearray_frame = extract_length(bytearray_frame)
        self.raw_data = bytearray_frame


    def is_success(self):
        return self.data_access_result == DataAccessResult.SUCCESS
