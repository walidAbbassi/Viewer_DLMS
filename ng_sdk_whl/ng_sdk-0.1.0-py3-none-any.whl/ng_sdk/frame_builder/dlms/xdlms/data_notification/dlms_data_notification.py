from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.xdlms.data_notification.invoked_id_and_priority import InvokeIdAndPriority
from ng_sdk.frame_builder.dlms.xdlms.data_type.date_time import DateTime
from ng_sdk.frame_builder.dlms.xdlms.data_type.dlms_parser import DlmsDataParser


class DlmsDataNotification(AbstractFrameResponse):
    __parser: DlmsDataParser = DlmsDataParser()
    TAG = 0x0F
    def __init__(self,frame:bytes):
        if frame[0] != self.TAG:
            raise ValueError(f"Invalid tag for DlmsDataNotification, expected {self.TAG}, got {frame[0]}")
        frame= frame[1:]
        super().__init__(bytearray(frame))
        frame = bytearray(frame)
        self.invoke_id = InvokeIdAndPriority.from_bytes(bytes(frame[:4]))
        frame = frame[4:]
        if frame[0] == 0x00:
            self.date_time = None
            frame = frame[1:]
        else:
            self.date_time = DateTime.from_bytes( frame[2:14])
            frame = frame[14:]
        self.data = self.__parser.parse(frame)
