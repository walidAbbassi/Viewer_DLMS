
from dataclasses import dataclass

from ng_sdk.frame_builder.dlms.dlms_enums import NotificationSelfDescriptive, NotificationProcessingOption, \
    NotificationServiceClass, NotificationPriority



"""
-- Use of Long-Invoke-Id-And-Priority 
--    long-invoke-id           bits 0-23 
--    reserved                 bits 24-27 
--    self-descriptive         bit  28       0 = Not-Self-Descriptive, 1 = Self-Descriptive 
--    processing-option        bit  29       0 = Continue on Error, 1 = Break on Error 
--    service-class            bit  30       0 = Unconfirmed, 1 = Confirmed 
--    priority                 bit  31       0 = Normal, 1 = High 

"""
@dataclass
class InvokeIdAndPriority:
    invoke_id: int
    reserved: int
    self_descriptive: NotificationSelfDescriptive
    processing_option: NotificationProcessingOption
    service_class_confirmed: NotificationServiceClass
    high_priority: NotificationPriority

    def to_bytes(self) -> bytes:
        value = self.invoke_id & 0x00FFFFFF                         # bits 0-23
        value |= (self.reserved & 0x0F) << 24                       # bits 24-27
        value |= (self.self_descriptive.value & 0x01) << 28         # bit  28
        value |= (self.processing_option.value & 0x01) << 29        # bit  29
        value |= (self.service_class_confirmed.value & 0x01) << 30  # bit  30
        value |= (self.high_priority.value & 0x01) << 31            # bit  31
        return value.to_bytes(4, byteorder="big")

    @classmethod
    def from_bytes(cls, data: bytes) -> "InvokeIdAndPriority":
        """
        Parse 4 bytes according to DLMS invoke-id-and-priority.
        Expects big-endian byte order.
        """
        if len(data) != 4:
            raise ValueError("InvokeIdAndPriority requires exactly 4 bytes")

        value = int.from_bytes(data, byteorder="big", signed=False)
        self_descriptive = NotificationSelfDescriptive.from_value((value >> 28) & 0x01)
        processing_option = NotificationProcessingOption.from_value((value >> 29) & 0x01)
        service_class_confirmed = NotificationServiceClass.from_value((value >> 30) & 0x01)
        high_priority = NotificationPriority.from_value((value >> 31) & 0x01)
        return cls(
            invoke_id=value & 0x00FFFFFF,  # bits 0–23
            reserved=(value >> 24) & 0x0F,  # bits 24–27
            self_descriptive=self_descriptive,  # bit 28
            processing_option=processing_option,  # bit 29
            service_class_confirmed=service_class_confirmed,  # bit 30
            high_priority=high_priority,  # bit 31
        )

