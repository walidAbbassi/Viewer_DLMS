from ng_sdk.frame_builder.dlms.xdlms.data_notification.invoked_id_and_priority import InvokeIdAndPriority
from ng_sdk.frame_builder.dlms.xdlms.data_type.date_time import DateTime


class DlmsDataNotificationConfirm:
    def __init__(self, invoke_id_and_priority: InvokeIdAndPriority, date_time: DateTime = None):
        self.invoke_id_and_priority = invoke_id_and_priority
        self.date_time = date_time

    def to_bytes(self) -> bytes:
        return b'\x10' + self.invoke_id_and_priority.to_bytes() + (self.date_time.to_bytes() if self.date_time is not None else b'\x00')

    def __str__(self):
        return f"DLMS Data Notification Confirm: Invoke ID and Priority: {self.invoke_id_and_priority}, Date time: {self.date_time}"