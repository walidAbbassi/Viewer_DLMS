import attr

from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, register_dlms_type
from xml.etree.ElementTree import Element

@register_dlms_type
@attr.s(auto_attribs=True)
class Integer8(AbstractDlmsType):
    """8 bit integer"""

    TAG = 15
    LENGTH = 1
    XML_TAG = "integer8"

    @classmethod
    def from_bytes(cls, bytes_data: bytes):
        return cls(value=int.from_bytes(bytes_data, "big", signed=True))

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        return cls(value=int(elem.text))

    def value_to_bytes(self) -> bytes:
        return self.value.to_bytes(self.LENGTH, "big", signed=True)

    def to_xml(self) -> Element:
        el = Element(self.XML_TAG)
        el.text = str(self.value)
        return el

    def to_readable_format(self, keys=None) -> any:
        return self.value