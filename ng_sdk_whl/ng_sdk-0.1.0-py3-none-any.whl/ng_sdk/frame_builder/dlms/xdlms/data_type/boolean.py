import attr

from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, register_dlms_type
from xml.etree.ElementTree import Element

@register_dlms_type
@attr.s(auto_attribs=True)
class BooleanData(AbstractDlmsType):
    TAG = 3
    LENGTH = 1
    XML_TAG = "boolean"

    @classmethod
    def from_bytes(cls, bytes_data: bytes):
        value = bool(int.from_bytes(bytes_data, "big"))
        return cls(value=value)

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        text = (elem.text or "").strip().lower()
        return cls(value=text == "true")

    def value_to_bytes(self) -> bytes:
        return (0x01 if self.value else 0x00).to_bytes(1, 'big')

    def to_xml(self) -> Element:
        el = Element(self.XML_TAG)
        el.text = "true" if self.value == True else "false"
        return el
    def to_readable_format(self, keys=None) -> any:
        return self.value