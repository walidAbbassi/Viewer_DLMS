from datetime import datetime

import attr

from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, register_dlms_type
from ng_sdk.util.dlms_time import time_from_bytes, time_to_bytes
from xml.etree.ElementTree import Element

@register_dlms_type
@attr.s(auto_attribs=True)
class Time(AbstractDlmsType):
    """date"""

    TAG = 27
    LENGTH = 4
    XML_TAG = "time"


    @classmethod
    def from_bytes(cls, bytes_data: bytes):
        if len(bytes_data) != cls.LENGTH:
            raise ValueError(f"Datetime should be 12 bytes long, got {len(bytes_data)}")
        return cls(value=time_from_bytes(bytes_data))

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        return cls(value=datetime.strptime(elem.text, "%H:%M:%S").time())


    def to_xml(self) -> Element:
        el = Element(self.XML_TAG)
        el.text = self.value.strftime("%H:%M:%S")
        return el

    def value_to_bytes(self) -> bytes:
        return time_to_bytes(self.value)


