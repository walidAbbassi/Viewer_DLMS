import attr

from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, register_dlms_type

from ng_sdk.constant.dlms.constant import Constant
from xml.etree.ElementTree import Element

@register_dlms_type
@attr.s(auto_attribs=True)
class OctetStringData(AbstractDlmsType):
    TAG = 9
    LENGTH = Constant.NO_LENGTH
    XML_TAG = "octet-string"

    @classmethod
    def from_bytes(cls, bytes_data: bytes):
        return cls(value=bytes_data)

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        return cls(value=bytes.fromhex(elem.text))

    def value_to_bytes(self) -> bytes:
        return self.value


    def to_xml(self) -> Element:
        el = Element(self.XML_TAG)
        el.set("size", str(len(self.value)))
        el.text = self.value.hex().upper()
        return el

    def to_readable_format(self, keys=None) -> any:
        return self.value.hex().upper()