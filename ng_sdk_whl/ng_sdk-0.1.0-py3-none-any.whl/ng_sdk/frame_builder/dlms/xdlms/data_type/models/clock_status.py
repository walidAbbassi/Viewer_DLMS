import attr


@attr.s(auto_attribs=True)
class ClockStatus:
    """
    :parameter invalid: Time could not be recovered after incident. Manufacturer dependant
        Shall not be set if `doubtful` is set.
    :parameter doubtful: Time could be recovered after incidnet, but correctness is not
        guaranteed. Manufacturer specific.
        Shall not be set if `invalid` is set.
    :parameter different_base: Set if timing source is different from the one
        specified in clock_base. (secondary clock for example)
    :parameter invalid_status: Something in the status itself is invalid.
        Manufacturer specific.
    :parameter daylight_saving_active: indicates if datetime contings daylight savings
        deviation (summer time)

    """

    invalid: bool = attr.ib(default=False)
    doubtful: bool = attr.ib(default=False)
    different_base: bool = attr.ib(default=False)
    invalid_status: bool = attr.ib(default=False)
    daylight_saving_active: bool = attr.ib(default=False)

    @classmethod
    def from_bytes(cls, source_bytes: bytes):
        if len(source_bytes) != 1:
            raise ValueError(f"ClockStatus is of 1 bytes, got: {len(source_bytes)}")
        if source_bytes[0] == 0xFF:
            return None
        value = int.from_bytes(source_bytes, "big")
        invalid = bool(value & 0b00000001)
        doubtful = bool(value & 0b00000010)
        different_base = bool(value & 0b00000100)
        invalid_status = bool(value & 0b00001000)
        daylight_saving_active = bool(value & 0b10000000)

        return cls(
            invalid, doubtful, different_base, invalid_status, daylight_saving_active
        )

    def to_bytes(self):
        value = 0
        if self.invalid:
            value += 0b00000001
        if self.doubtful:
            value += 0b00000010
        if self.different_base:
            value += 0b00000100
        if self.invalid_status:
            value += 0b00001000
        if self.daylight_saving_active:
            value += 0b10000000

        return value.to_bytes(1, "big")