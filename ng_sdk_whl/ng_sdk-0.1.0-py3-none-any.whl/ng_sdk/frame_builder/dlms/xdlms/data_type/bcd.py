import attr

from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, register_dlms_type
from xml.etree.ElementTree import Element

from ng_sdk.util.xml_data_type_parser import parse_clock_status


@register_dlms_type
@attr.s(auto_attribs=True)
class BCD(AbstractDlmsType):
    TAG = 13
    XML_TAG = "bcd"
    LENGTH = Constant.NO_LENGTH

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        return cls(value=elem.text)

    @classmethod
    def from_bytes(cls, bytes_data: bytes):
        digits = []
        for b in bytes_data:
            high = (b >> 4) & 0x0F
            low = b & 0x0F
            if high > 9 or low > 9:
                raise ValueError(f"Invalid BCD byte: {b:#x}")
            digits.append(f"{high}{low}")
        return cls(value=''.join(digits))

    def value_to_bytes(self) -> bytes:
        if not self.value.isdigit():
            raise ValueError("Input must be a decimal string")

            # Pad with leading 0 if odd number of digits
        if len(self.value) % 2 != 0:
            self.value = '0' + self.value

        bcd = bytes([(int(self.value[i]) << 4) | int(self.value[i + 1]) for i in range(0, len(self.value), 2)])
        return bcd

    def to_xml(self) -> Element:
        el = Element(self.XML_TAG)
        el.set("size", str(len(self.value)))
        el.text = self.value
        return el

    def to_readable_format(self, keys=None) -> any:
        return self.value