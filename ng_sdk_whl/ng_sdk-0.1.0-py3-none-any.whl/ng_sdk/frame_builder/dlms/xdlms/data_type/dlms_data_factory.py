from typing import ClassVar, Type, Dict
import attr


from ng_sdk.frame_builder.dlms.xdlms.data_type.array import ArrayData
from ng_sdk.frame_builder.dlms.xdlms.data_type.bcd import BCD
from ng_sdk.frame_builder.dlms.xdlms.data_type.boolean import BooleanData
from ng_sdk.frame_builder.dlms.xdlms.data_type.date import Date
from ng_sdk.frame_builder.dlms.xdlms.data_type.date_time import DateTime
from ng_sdk.frame_builder.dlms.xdlms.data_type.enum import EnumData
from ng_sdk.frame_builder.dlms.xdlms.data_type.float_32 import Float32
from ng_sdk.frame_builder.dlms.xdlms.data_type.float_64 import Float64
from ng_sdk.frame_builder.dlms.xdlms.data_type.integer_16 import Integer16
from ng_sdk.frame_builder.dlms.xdlms.data_type.integer_32 import Integer32
from ng_sdk.frame_builder.dlms.xdlms.data_type.integer_64 import Integer64
from ng_sdk.frame_builder.dlms.xdlms.data_type.integer_8 import Integer8
from ng_sdk.frame_builder.dlms.xdlms.data_type.null_data import NullData
from ng_sdk.frame_builder.dlms.xdlms.data_type.octet_string import OctetStringData
from ng_sdk.frame_builder.dlms.xdlms.data_type.structure import StructureData
from ng_sdk.frame_builder.dlms.xdlms.data_type.time import Time
from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_16 import Unsigned16
from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_32 import Unsigned32
from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_64 import Unsigned64
from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_8 import Unsigned8
from ng_sdk.frame_builder.dlms.xdlms.data_type.utf8_string import Utf8String
from ng_sdk.frame_builder.dlms.xdlms.data_type.visible_string import VisibleString
from ng_sdk.frame_builder.dlms.xdlms.data_type.bit_string import BitString


@attr.s(auto_attribs=True)
class DlmsDataFactory:
    MAP: ClassVar[Dict[int, Type]] = {
        NullData.TAG: NullData,
        ArrayData.TAG: ArrayData,
        StructureData.TAG: StructureData,
        Unsigned32.TAG: Unsigned32,
        Integer32.TAG: Integer32,
        OctetStringData.TAG: OctetStringData,
        VisibleString.TAG: VisibleString,
        BooleanData.TAG: BooleanData,
        BitString.TAG: BitString,
        BCD.TAG: BCD,
        Date.TAG:Date,
        DateTime.TAG: DateTime,
        EnumData.TAG: EnumData,
        Float32.TAG: Float32,
        Float64.TAG: Float64,
        Integer8.TAG: Integer8,
        Integer16.TAG: Integer16,
        Integer64.TAG: Integer64,
        Unsigned8.TAG: Unsigned8,
        Unsigned16.TAG: Unsigned16,
        Unsigned64.TAG: Unsigned64,
        Utf8String.TAG: Utf8String,
        Time.TAG: Time,

    }

    @classmethod
    def get_data_class(cls, tag: int):
        return cls.MAP[tag]

