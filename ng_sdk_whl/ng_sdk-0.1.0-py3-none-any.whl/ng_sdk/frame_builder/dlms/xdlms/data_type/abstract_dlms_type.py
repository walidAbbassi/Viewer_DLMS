from typing import ClassVar, Any, Optional

import attr

from ng_sdk.frame_builder.abstract_data_type import AbstractDataType
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.util.bytes_util import encode_length
from xml.etree.ElementTree import Element


@attr.s(auto_attribs=True)
class AbstractDlmsType(AbstractDataType):
    TAG: ClassVar[int] = 0
    LENGTH: ClassVar[int] = 0
    XML_TAG: ClassVar[str]  = "null"

    value: Optional[Any]=None

    @classmethod
    def from_bytes(cls, bytes_data: bytes):
        raise NotImplementedError(
            f"{cls.__name__} have not implemented byte conversion"
        )

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        raise NotImplementedError(
            f"{cls.__name__} have not implemented from_xml"
        )

    @classmethod
    def from_string(cls, value: str) -> "AbstractDlmsType":
        """Create an instance from a plain string value.

        Internally builds a minimal XML element whose text is *value* and
        delegates to :meth:`from_xml`, reusing the type-specific string→native
        conversion already implemented there (e.g. ``int(elem.text)`` for
        integer types, ``bytes.fromhex(elem.text)`` for octet-strings, …).

        Args:
            value: String representation of the value (e.g. ``"120"``,
                ``"FF00AA"``, ``"true"``, …)

        Returns:
            A properly typed instance of the concrete subclass.
        """
        elem = Element(cls.XML_TAG)
        elem.text = value
        return cls.from_xml(elem)

    def to_python(self) -> Any:
        return self.value

    def to_xml(self)->Element:
        raise NotImplementedError("to_xml must be implemented in subclass")

    def to_readable_format(self, keys=None) -> any:
        raise NotImplementedError("to_readable_format must be implemented in subclass")


    def value_to_bytes(self) -> bytes:
        raise NotImplementedError("value_to_bytes must be implemented in subclass")

    def to_bytes(self) -> bytes:
        out = bytearray()
        out.append(self.TAG)
        value_bytes = self.value_to_bytes()
        if self.LENGTH == Constant.NO_LENGTH:
            out.extend(encode_length(len(value_bytes)))
        out.extend(value_bytes)
        return bytes(out)

# Registry for reverse xml parsing
DLMS_TYPE_REGISTRY: dict[str, type[AbstractDlmsType]] = {}

def register_dlms_type(cls: type[AbstractDlmsType]):
    """Decorator to auto-register DLMS types by xml_tag."""
    DLMS_TYPE_REGISTRY[cls.XML_TAG] = cls
    return cls