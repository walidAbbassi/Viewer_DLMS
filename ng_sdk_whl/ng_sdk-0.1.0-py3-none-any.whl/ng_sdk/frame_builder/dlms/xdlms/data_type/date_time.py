from datetime import datetime

import attr

from ng_sdk.frame_builder.dlms.xdlms.data_type.octet_string import OctetStringData
from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, register_dlms_type
from ng_sdk.util.dlms_time import datetime_from_bytes, datetime_to_bytes
from xml.etree.ElementTree import Element

from ng_sdk.util.xml_data_type_parser import parse_clock_status


@register_dlms_type
@attr.s(auto_attribs=True)
class DateTime(AbstractDlmsType):
    """date time"""

    TAG = 25
    LENGTH = 12
    XML_TAG = "date-time"


    @classmethod
    def from_bytes(cls, bytes_data: bytes):
        if len(bytes_data) != cls.LENGTH:
            raise ValueError(f"Datetime should be 12 bytes long, got {len(bytes_data)}")
        return cls(value=datetime_from_bytes(bytes_data))

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        return cls(value=parse_clock_status(elem.text))

    def to_xml(self) -> Element:
        el = Element(self.XML_TAG)
        date_time,clock_status = self.value
        if clock_status:
            el.text = date_time.strftime("%d/%m/%Y %H:%M:%S") + " invalid: "+str(clock_status.invalid)+ " doubtful: "+str(clock_status.doubtful)+ " different_base: "+str(clock_status.different_base)+ " invalid_status: "+str(clock_status.invalid_status)+ " daylight_saving_active: "+str(clock_status.daylight_saving_active)
        else:
            el.text = date_time.strftime("%d/%m/%Y %H:%M:%S")
        return el

    def value_to_bytes(self) -> bytes:
        datetime,clock_status = self.value
        return datetime_to_bytes(datetime,clock_status)

    def to_octet_string(self) -> OctetStringData:
        return OctetStringData(value=self.value_to_bytes())




