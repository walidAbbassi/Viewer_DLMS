import struct

import attr

from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, register_dlms_type
from xml.etree.ElementTree import Element


@register_dlms_type
@attr.s(auto_attribs=True)
class Float64(AbstractDlmsType):
    """64 bit float"""

    TAG = 24
    LENGTH = 8
    XML_TAG = "float64"

    @classmethod
    def from_bytes(cls, bytes_data: bytes):
        return cls(value=struct.unpack('>d', bytes_data)[0])

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        return cls(value=float(elem.text))

    def value_to_bytes(self) -> bytes:
        return struct.pack('>d', self.value)

    def to_xml(self) -> Element:
        el = Element(self.XML_TAG)
        el.text = str(self.value)
        return el

    def to_readable_format(self, keys=None) -> any:
        return self.value