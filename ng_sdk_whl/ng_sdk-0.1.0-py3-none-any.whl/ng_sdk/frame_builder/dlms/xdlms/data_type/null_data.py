from typing import Any

import attr

from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, register_dlms_type
from xml.etree.ElementTree import Element

@register_dlms_type
@attr.s(auto_attribs=True)
class NullData(AbstractDlmsType):

    XML_TAG = "null"

    @classmethod
    def from_bytes(cls, bytes_data: bytes):
        return cls(value=None)

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        return cls(value=None)

    def value_to_bytes(self) -> bytes:
        return bytes()

    def to_python(self) -> Any:
        return None

    def to_xml(self) -> Element:
        el = Element(self.XML_TAG)
        return el
    def to_readable_format(self, keys=None) -> any:
        return None

