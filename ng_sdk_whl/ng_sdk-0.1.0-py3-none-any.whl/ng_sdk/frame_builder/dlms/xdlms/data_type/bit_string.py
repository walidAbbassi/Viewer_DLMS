import attr

from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, register_dlms_type
from xml.etree.ElementTree import Element

@register_dlms_type
@attr.s(auto_attribs=True)
class BitString(AbstractDlmsType):

    TAG = 4
    XML_TAG = "bit-string"
    LENGTH = Constant.NO_LENGTH
    @classmethod
    def from_bytes(cls, bytes_data: bytes):
        return cls(value=''.join(f'{byte:08b}' for byte in bytes_data))

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        return cls(value=elem.text)

    def value_to_bytes(self) -> bytes:
        return bytes.fromhex(self.value)

    def to_xml(self) -> Element:
        el = Element(self.XML_TAG)
        el.set("size", str(len(self.value)))
        el.text = self.value
        return el
    def to_readable_format(self, keys=None) -> any:
        return self.value
    