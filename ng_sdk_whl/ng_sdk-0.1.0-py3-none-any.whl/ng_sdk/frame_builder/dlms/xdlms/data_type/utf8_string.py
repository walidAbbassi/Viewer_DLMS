import attr

from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, register_dlms_type
from xml.etree.ElementTree import Element

@register_dlms_type
@attr.s(auto_attribs=True)
class Utf8String(AbstractDlmsType):
    TAG = 12
    LENGTH = Constant.NO_LENGTH
    XML_TAG = "utf8-string"

    @classmethod
    def from_bytes(cls, bytes_data: bytes):
        return cls(value=bytes_data.decode("utf-8"))

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        return cls(value=elem.text)

    def value_to_bytes(self) -> bytes:
        return self.value.encode("utf-8")

    def to_xml(self) -> Element:
        el = Element(self.XML_TAG)
        el.set("size", str(len(self.value)))
        el.text = self.value
        return el