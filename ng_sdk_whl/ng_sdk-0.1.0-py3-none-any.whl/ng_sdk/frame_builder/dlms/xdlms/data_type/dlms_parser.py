from typing import List, Optional

from ng_sdk.frame_builder.dlms.dlms_enums import DataAccessResult
from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType
import attr
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.data_type.array import ArrayData
from ng_sdk.frame_builder.dlms.xdlms.data_type.bit_string import BitString
from ng_sdk.frame_builder.dlms.xdlms.data_type.dlms_data_factory import DlmsDataFactory
from ng_sdk.frame_builder.dlms.xdlms.data_type.structure import StructureData
from ng_sdk.frame_builder.dlms.xdlms.get_data_result import GetDataResult


@attr.s(auto_attribs=True)
class DlmsDataParser:

    buffer: bytearray = attr.ib(factory=bytearray, init=False)
    pointer: int = attr.ib(default=0, init=False)
    data: List[AbstractDlmsType] | List[GetDataResult]  = attr.ib(factory=list, init=False)
    with_data_access:bool = False

    @property
    def buffer_empty(self) -> bool:
        return self.pointer >= len(self.buffer)

    def parse(self, data: bytes, with_data_access:bool = False,limit: Optional[int] = None):
        # clear previous results
        self.with_data_access = with_data_access
        self.data = list()
        self.buffer = bytearray()
        self.pointer = 0
        # fill the buffer
        self.buffer += data

        while not self.buffer_empty:
            self.data.append(self.parse_one_entry())
            if limit:
                if len(self.data) >= limit:
                    break

        return self.data

    def parse_one_entry(self):
        success = True
        data_access_result = DataAccessResult.SUCCESS
        parsed_data = None
        if self.with_data_access:
            success = int.from_bytes(self.get_bytes(1), "big") == 0
        tag = self.get_bytes(1)
        if success:
            klass = DlmsDataFactory.get_data_class(int.from_bytes(tag, "big"))
            if klass == ArrayData:
                parsed_data = self.parse_array()
            elif klass == StructureData:
                parsed_data = self.parse_structure()
            else:
                parsed_data = self.parse_data(klass)
        else:
            data_access_result = DataAccessResult(int.from_bytes(tag, "big"))

        if self.with_data_access:
            return GetDataResult(parsed_data, data_access_result)
        else:
            return parsed_data

    def get_buffer_tail(self) -> bytearray:
        return self.buffer[self.pointer :]

    def parse_data(self, data_class) -> AbstractDlmsType:
        if data_class.LENGTH == Constant.NO_LENGTH:
            length = self.parse_variable_integer()
            if data_class == BitString:
                length = (length + 7) // 8
            return data_class.from_bytes(self.get_bytes(length))
        else:
            return data_class.from_bytes(self.get_bytes(data_class.LENGTH))

    def parse_array(self) -> ArrayData:
        item_count = self.parse_variable_integer()
        elements = list()
        with_data_access = self.with_data_access
        self.with_data_access = False
        for _ in range(0, item_count):
            elements.append(self.parse_one_entry())
        self.with_data_access = with_data_access
        return ArrayData(value=elements)

    def parse_structure(self) -> StructureData:
        item_count = self.parse_variable_integer()
        elements = list()
        with_data_access = self.with_data_access
        self.with_data_access = False
        for _ in range(0, item_count):
            elements.append(self.parse_one_entry())
        self.with_data_access  = with_data_access
        return StructureData(value=elements)
    def get_bytes(self, length: int) -> bytearray:
        """Gets some bytes from the buffer and moves the pointer forward."""
        part = self.buffer[self.pointer : self.pointer + length]
        self.pointer += length
        return part

    @property
    def remaining_buffer(self) -> bytearray:
        return self.buffer[self.pointer :]

    def parse_variable_integer(self) -> int:
        length_data = bytearray()
        first_byte = int.from_bytes(self.get_bytes(1), "big")
        length_is_multiple_bytes = bool(first_byte & 0b10000000)
        if not length_is_multiple_bytes:
            return first_byte
        number_of_bytes_representing_the_length = first_byte & 0b01111111
        for _ in range(0, number_of_bytes_representing_the_length):
            length_data.extend(self.get_bytes(1))
        return int.from_bytes(length_data, "big")

