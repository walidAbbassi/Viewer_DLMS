from datetime import datetime


import attr

from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, register_dlms_type
from ng_sdk.util.dlms_time import date_from_bytes, date_to_bytes
from xml.etree.ElementTree import Element

@register_dlms_type
@attr.s(auto_attribs=True)
class Date(AbstractDlmsType):
    """date"""

    TAG = 26
    LENGTH = 5
    XML_TAG = "date"


    @classmethod
    def from_bytes(cls, bytes_data: bytes):
        if len(bytes_data) != cls.LENGTH:
            raise ValueError(f"Datetime should be 12 bytes long, got {len(bytes_data)}")
        return cls(value=date_from_bytes(bytes_data))

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        return cls(value=datetime.strptime(elem.text, "%d/%m/%Y").date())

    def to_xml(self) -> Element:
        el = Element(self.XML_TAG)
        el.text = self.value.strftime("%d/%m/%Y")
        return el

    def value_to_bytes(self) -> bytes:
        return date_to_bytes(self.value)


