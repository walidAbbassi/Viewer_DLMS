from typing import Any

import attr

from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, register_dlms_type
from ng_sdk.util.bytes_util import encode_variable_integer
from xml.etree.ElementTree import Element
from ng_sdk.util.xml_data_type_parser import parse_dlms_xml_element


@register_dlms_type
@attr.s(auto_attribs=True)
class StructureData(AbstractDlmsType):
    TAG = 2
    LENGTH = Constant.NO_LENGTH
    XML_TAG = "structure"

    @classmethod
    def from_xml(cls, elem: Element) -> "AbstractDlmsType":
        from_xml_value = parse_dlms_xml_element  # defined below
        items = [from_xml_value(child) for child in elem]
        return cls(value=items)

    def to_bytes(self) -> bytes:
        out = bytearray()
        out.append(self.TAG)
        out.extend(encode_variable_integer(len(self.value)))
        for item in self.value:
            out.extend(item.to_bytes())
        return bytes(out)

    def to_python(self) -> Any:
        values = list()
        for item in self.value:
            values.append(item.to_python())
        return values

    def to_xml(self) -> Element:
        el = Element(self.XML_TAG)
        el.set("size", str(len(self.value)))
        for item in self.value:
            el.append(item.to_xml())
        return el
    def to_readable_format(self, keys=None) -> any:
        if keys is None:
            return [item.to_readable_format() for item in self.value]
        values = dict()
        for index, item in enumerate(self.value):
            key_name = keys[index] if isinstance(keys, list) and index < len(keys) else 'key' + str(index)
            values[key_name] = item.to_readable_format()
        return values