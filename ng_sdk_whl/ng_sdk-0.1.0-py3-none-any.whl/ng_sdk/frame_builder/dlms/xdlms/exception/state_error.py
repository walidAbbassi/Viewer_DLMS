from enum import IntEnum

class StateError(IntEnum):
    SERVICE_NOT_ALLOWED = 1
    SERVICE_UNKNOWN = 2

    @classmethod
    def has_value(cls, value):
        return value in cls._value2member_map_
