from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.xdlms.exception.service_error import ServiceError
from ng_sdk.frame_builder.dlms.xdlms.exception.state_error import StateError


class DLMSExceptionResponse(AbstractFrameResponse):
    state_error: StateError = None
    service_error: ServiceError = None

    def __init__(self, frame:bytes):
        super().__init__(bytearray(frame))
        frame = bytearray(frame)
        state_error = frame.pop(0)
        if StateError.has_value(state_error):
            self.state_error = StateError(state_error)
        service_error = frame.pop(0)
        if ServiceError.has_value(service_error):
            self.service_error = ServiceError(service_error)
