from enum import IntEnum


class ServiceError(IntEnum):
    OPERATION_NOT_POSSIBLE = 1
    SERVICE_NOT_SUPPORTED = 2
    OTHER_REASON = 3
    PDU_TOO_LONG = 4
    DECIPHERING_ERROR = 5
    INVOCATION_COUNTER_ERROR = 6

    @classmethod
    def has_value(cls, value):
        return value in cls._value2member_map_