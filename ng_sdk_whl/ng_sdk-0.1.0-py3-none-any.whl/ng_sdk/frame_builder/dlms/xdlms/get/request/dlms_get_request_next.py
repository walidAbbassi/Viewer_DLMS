from typing import Optional

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command, GetRequestType
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.get_dlms_cipher import GetDlmsCipher
from ng_sdk.security.security_constant import DlmsCipheringType
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.tag_length_value import TagLengthValue


class DLMSGetRequestNext(AbstractFrameRequest,GetDlmsCipher):
    def __init__(self, block_number: int):
        super().__init__(bytes())
        self.command = Command.GET_REQUEST
        self.block_number = block_number



    def to_bytes(self,security_context: Optional[SecurityContext] = None) -> bytes:
        out = bytearray()
        out.append(self.command)
        out.append(GetRequestType.NEXT)
        out.append(Constant.INVOKED_ID)
        out.extend(self.block_number.to_bytes(4, "big"))
        if security_context is not None:
            return self.cipher(security_context, out)
        return out
