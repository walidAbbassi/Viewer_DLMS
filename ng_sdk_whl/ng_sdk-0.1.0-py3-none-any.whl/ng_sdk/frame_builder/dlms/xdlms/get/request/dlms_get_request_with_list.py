from typing import List, Optional

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command, GetRequestType
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.get.request.dlms_get_request_normal import DLMSGetRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.get_dlms_cipher import GetDlmsCipher
from ng_sdk.security.security_constant import DlmsCipheringType
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.bytes_util import obis_code_to_bytes, encode_length
from ng_sdk.util.tag_length_value import TagLengthValue


class DLMSGetRequestWithList(AbstractFrameRequest,GetDlmsCipher):
    def __init__(self, cosem_attribute_descriptor_list : List[DLMSGetRequestNormal]):
        super().__init__(bytes())
        self.command = Command.GET_REQUEST
        self.cosem_attribute_descriptor_list =cosem_attribute_descriptor_list

    def to_bytes(self,security_context: Optional[SecurityContext] = None) -> bytes:
        out = bytearray()
        out.append(self.command)
        out.append(GetRequestType.WITH_LIST)
        out.append(Constant.INVOKED_ID)
        out.extend(bytes([len(self.cosem_attribute_descriptor_list)]))
        for cosem_object in self.cosem_attribute_descriptor_list:
            out.extend(cosem_object.class_id.to_bytes(2, "big"))
            out.extend(obis_code_to_bytes(cosem_object.obis_code))
            out.extend(bytes([cosem_object.attribute]))
            if not cosem_object.selective_access:
                out.append(0x00)
            else:
                out.append(0x01)
                out.extend(cosem_object.selective_access.to_bytes())
        if security_context is not None:
            return self.cipher(security_context, out)
        return out
