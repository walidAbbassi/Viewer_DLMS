from typing import List

from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.xdlms.data_type.dlms_parser import DlmsDataParser
from ng_sdk.frame_builder.dlms.xdlms.get_data_result import GetDataResult





class DLMSGetResponseWithList(AbstractFrameResponse):
    invoked_id : int
    result : List[GetDataResult] = []

    def __init__(self, frame:bytes):
        super().__init__(bytearray(frame))
        frame = bytearray(frame)
        self.invoked_id = frame.pop(0)
        result_length = int(frame.pop(0))

        parser = DlmsDataParser()
        self.result = parser.parse(frame, True)
        if result_length != len(self.result):
            raise Exception



