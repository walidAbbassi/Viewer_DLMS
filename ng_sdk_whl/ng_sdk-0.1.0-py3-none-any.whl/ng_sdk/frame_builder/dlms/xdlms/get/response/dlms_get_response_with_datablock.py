from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.xdlms.datablock_g import DataBlockG


class DLMSGetResponseWithDatablock(AbstractFrameResponse):
    invoked_id : int
    result: DataBlockG
    def __init__(self, frame:bytes):
        super().__init__(bytearray(frame))
        self.invoked_id = self.frame.pop(0)
        self.result = DataBlockG(self.frame)

    def is_success(self):
        return self.result.is_success()



