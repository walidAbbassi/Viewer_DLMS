from ng_sdk.frame_builder.abstract_data_type import AbstractDataType
from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.dlms_enums import DataAccessResult
from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType
from ng_sdk.frame_builder.dlms.xdlms.data_type.dlms_parser import DlmsDataParser


class DLMSGetResponseNormal(AbstractFrameResponse):
    data_access_result : DataAccessResult = DataAccessResult.SUCCESS
    invoked_id : int
    data: AbstractDlmsType
    __parser: DlmsDataParser = DlmsDataParser()
    def __init__(self, frame:bytes):
        super().__init__(bytearray(frame))
        frame = bytearray(frame)
        self.invoked_id = frame.pop(0)
        encoded_response_status = frame.pop(0)
        if encoded_response_status != DataAccessResult.SUCCESS:
            self.data_access_result = DataAccessResult.from_value(frame.pop(0))
        else:
            self.data = self.__parser.parse(frame)[0]

    def is_success(self):
        return self.data_access_result == DataAccessResult.SUCCESS

