from ng_sdk.frame_builder.dlms.dlms_enums import DataAccessResult
from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType


class GetDataResult:
    data : AbstractDlmsType
    data_access_result : DataAccessResult = DataAccessResult.SUCCESS

    def __init__(self, data:AbstractDlmsType,data_access_result: DataAccessResult):
        self.data_access_result = data_access_result
        self.data = data

