from typing import ClassVar

from ng_sdk.security.security_constant import DlmsCipheringType
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.bytes_util import encode_length
from ng_sdk.util.tag_length_value import TagLengthValue


class BaseDlmsCipher:

    GLOBAL_CIPHERING: ClassVar[int]  = None
    DEDICATED_CIPHERING: ClassVar[int]  = None
    GENERAL_CIPHERING: ClassVar[int]     = None

    def cipher(self,security_context:SecurityContext,data:bytes)->bytes:

        if security_context.configuration.security.ciphering_type == DlmsCipheringType.GLOBAL_CIPHERING:
            return TagLengthValue.to_tlv(self.GLOBAL_CIPHERING, security_context.cipher(data))
        elif security_context.configuration.security.ciphering_type == DlmsCipheringType.DEDICATED_CIPHERING:
            return TagLengthValue.to_tlv(self.DEDICATED_CIPHERING, security_context.cipher(data))
        elif security_context.configuration.security.ciphering_type == DlmsCipheringType.GENERAL_GLOBAL_CIPHERING or security_context.configuration.security == DlmsCipheringType.GENERAL_DEDICATED_CIPHERING:
            ciphered_data = security_context.cipher(data)
            system_title = security_context.get_system_title()
            return bytes([self.GENERAL_CIPHERING])+encode_length(len(system_title))+system_title + encode_length(len(ciphered_data)) + ciphered_data
        return data