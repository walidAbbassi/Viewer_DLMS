from ng_sdk.frame_builder.dlms.dlms_enums import ActionResult
from ng_sdk.frame_builder.dlms.xdlms.get_data_result import GetDataResult


class ActionResponseWithOptionalData:
    result : ActionResult
    return_parameter : GetDataResult

    def __init__(self, result : ActionResult,return_parameter : GetDataResult = None):
        self.result = result
        self.return_parameter = return_parameter