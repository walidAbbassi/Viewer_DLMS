from ng_sdk.frame_builder.dlms.xdlms.base_dlms_cipher import BaseDlmsCipher


class SetDlmsCipher(BaseDlmsCipher):
    GLOBAL_CIPHERING = 0xC9
    DEDICATED_CIPHERING = 0xD1
    GENERAL_CIPHERING = 0xDB