from ng_sdk.frame_builder.dlms.xdlms.base_dlms_cipher import BaseDlmsCipher


class ActionDlmsCipher(BaseDlmsCipher):
    GLOBAL_CIPHERING = 0xCB
    DEDICATED_CIPHERING = 0xD3
    GENERAL_CIPHERING = 0xDB