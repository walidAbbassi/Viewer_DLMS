from typing import List, Optional

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command, ActionRequestType
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_normal import DLMSActionRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.action_dlms_cipher import ActionDlmsCipher
from ng_sdk.security.security_constant import DlmsCipheringType
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.bytes_util import obis_code_to_bytes
from ng_sdk.util.tag_length_value import TagLengthValue


class DLMSActionRequestWithList(AbstractFrameRequest,ActionDlmsCipher):
    def __init__(self, cosem_method_descriptor_list : List[DLMSActionRequestNormal]):
        super().__init__(bytes())
        self.command = Command.ACTION_REQUEST
        self.cosem_method_descriptor_list = cosem_method_descriptor_list



    def to_bytes(self,security_context: Optional[SecurityContext] = None) -> bytes:
        out = bytearray()
        descriptors = bytearray()
        values = bytearray()
        out.append(self.command)
        out.append(ActionRequestType.WITH_LIST)
        out.append(Constant.INVOKED_ID)
        for cosem_object in self.cosem_method_descriptor_list:
            descriptors.extend(cosem_object.class_id.to_bytes(2, "big"))
            descriptors.extend(obis_code_to_bytes(cosem_object.obis_code))
            descriptors.extend(bytes([cosem_object.method]))
            if not cosem_object.payload or len(cosem_object.payload) == 0:
                values.append(0x00)
            else:
                values.extend(cosem_object.payload)
        self.payload = values
        length = len(self.cosem_method_descriptor_list)
        out.extend(length.to_bytes( 1 if  length<255 else 2, "big"))
        out.extend(bytes(descriptors))
        out.extend(length.to_bytes(1 if  length<255 else 2, "big"))
        out.extend(bytes(values))
        if security_context is not None:
            return self.cipher(security_context, out)
        return out
