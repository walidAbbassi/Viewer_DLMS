from typing import Optional

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command, ActionRequestType
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.action_dlms_cipher import ActionDlmsCipher
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.tag_length_value import TagLengthValue


class DLMSActionRequestNextPblock(AbstractFrameRequest,ActionDlmsCipher):
    def __init__(self, block_number :int):
        super().__init__(block_number.to_bytes(4, "big"))
        self.command = Command.ACTION_REQUEST



    def to_bytes(self,security_context: Optional[SecurityContext] = None) -> bytes:
        out = bytearray()
        out.append(self.command)
        out.append(ActionRequestType.NEXT_PBLOCK)
        out.append(Constant.INVOKED_ID)
        out.extend(self.payload)
        if security_context is not None:
            return self.cipher(security_context, out)
        return out

