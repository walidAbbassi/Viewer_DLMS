import string
from typing import Optional

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command, ActionRequestType
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.action_dlms_cipher import ActionDlmsCipher
from ng_sdk.frame_builder.dlms.xdlms.datablock_sa import DataBlockSA
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.bytes_util import obis_code_to_bytes
from ng_sdk.util.tag_length_value import TagLengthValue


class DLMSActionRequestWithFirstPblock(AbstractFrameRequest,ActionDlmsCipher):
    def __init__(self, class_id :int,obis_code:str, method:int, pblock:DataBlockSA):
        super().__init__(pblock.to_bytes())
        self.command = Command.ACTION_REQUEST
        self.class_id = class_id
        self.obis_code = obis_code
        self.method = method


    def to_bytes(self,security_context: Optional[SecurityContext] = None) -> bytes:
        out = bytearray()
        out.append(self.command)
        out.append(ActionRequestType.WITH_FIRST_PBLOCK)
        out.append(Constant.INVOKED_ID)
        out.extend(self.class_id.to_bytes(2, "big"))
        out.extend(obis_code_to_bytes(self.obis_code))
        out.extend(bytes([self.method]))
        out.extend(self.payload)
        if security_context is not None:
            return self.cipher(security_context, out)
        return out
