from typing import List, Optional

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command, ActionRequestType
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_normal import DLMSActionRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.action_dlms_cipher import ActionDlmsCipher
from ng_sdk.frame_builder.dlms.xdlms.datablock_sa import DataBlockSA
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.bytes_util import obis_code_to_bytes
from ng_sdk.util.tag_length_value import TagLengthValue


class DLMSActionRequestWithListAndFirstPblock(AbstractFrameRequest,ActionDlmsCipher):
    def __init__(self, cosem_method_descriptor_list : List[DLMSActionRequestNormal], pblock:DataBlockSA):
        super().__init__(pblock.to_bytes())
        self.command = Command.ACTION_REQUEST
        self.cosem_method_descriptor_list = cosem_method_descriptor_list


    def to_bytes(self,security_context: Optional[SecurityContext] = None) -> bytes:
        out = bytearray()
        out.append(self.command)
        out.append(ActionRequestType.WITH_LIST_AND_FIRST_PBLOCK)
        out.append(Constant.INVOKED_ID)
        length = len(self.cosem_method_descriptor_list)
        out.extend(length.to_bytes(1, "big"))
        for cosem_object in self.cosem_method_descriptor_list:
            out.extend(cosem_object.class_id.to_bytes(2, "big"))
            out.extend(obis_code_to_bytes(cosem_object.obis_code))
            out.extend(bytes([cosem_object.method]))
        out.extend(self.payload)
        if security_context is not None:
            return self.cipher(security_context, out)
        return out
