from typing import Optional

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.dlms.dlms_enums import Command, ActionRequestType
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.dlms.xdlms.action_dlms_cipher import ActionDlmsCipher
from ng_sdk.frame_builder.dlms.xdlms.datablock_sa import DataBlockSA
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.tag_length_value import TagLengthValue


class DLMSActionRequestWithPblock(AbstractFrameRequest,ActionDlmsCipher):
    def __init__(self, pblock :DataBlockSA):
        super().__init__(pblock.to_bytes())
        self.command = Command.ACTION_REQUEST



    def to_bytes(self,security_context: Optional[SecurityContext] = None) -> bytes:
        out = bytearray()
        out.append(self.command)
        out.append(ActionRequestType.WITH_PBLOCK)
        out.append(Constant.INVOKED_ID)
        out.extend(self.payload)
        if security_context is not None:
            return self.cipher(security_context, out)
        return out
