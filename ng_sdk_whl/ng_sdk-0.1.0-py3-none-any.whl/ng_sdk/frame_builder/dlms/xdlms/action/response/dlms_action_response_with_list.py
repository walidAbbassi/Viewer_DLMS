from typing import List

from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.dlms_enums import ActionResult, Command, ActionResponseType
from ng_sdk.frame_builder.dlms.xdlms.action_response_with_optional_data import ActionResponseWithOptionalData
from ng_sdk.frame_builder.dlms.xdlms.data_type.dlms_parser import DlmsDataParser
from ng_sdk.util.bytes_util import bytearray_pop_range


class DLMSActionResponseWithList(AbstractFrameResponse):
    invoked_id : int
    list_of_responses : List[ActionResponseWithOptionalData] = []
    is_success = True

    #C1 01 00 00
    def __init__(self, frame:bytes):
        super().__init__(bytearray(frame))
        received_frame = bytearray(frame)
        parser = DlmsDataParser()
        self.list_of_responses = []
        self.invoked_id = received_frame.pop(0)
        quantity = received_frame.pop(0)

        def _parse_optional_parameter():
            try:
                return parser.parse(received_frame, True, 1)[0]
            except Exception:
                return parser.parse(received_frame, False, 1)[0]

        for i in range(0,quantity):
            if parser.pointer >= 0:
                bytearray_pop_range(received_frame, 0, parser.pointer)
            return_parameter = None
            result = ActionResult.from_value(received_frame.pop(0))
            if result == ActionResult.SUCCESS:
                with_optional_parameter = received_frame.pop(0)
                if with_optional_parameter:
                    return_parameter = _parse_optional_parameter()
            else:
                self.is_success = False
                with_optional_parameter = received_frame.pop(0)
                if with_optional_parameter:
                    return_parameter = _parse_optional_parameter()
            self.list_of_responses.append(ActionResponseWithOptionalData(result,return_parameter))
    def to_bytes(self) -> bytes:
        return bytes([Command.ACTION_RESPONSE, ActionResponseType.WITH_LIST]) + self.frame
    def is_success(self) ->bool:
        return self.is_success




