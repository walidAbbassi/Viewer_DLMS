from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.util.bytes_util import bytearray_pop_range


class DLMSActionResponseNextPblock(AbstractFrameResponse):
    invoked_id : int
    block_number : int

    def __init__(self, frame:bytes):
        super().__init__(bytearray(frame))
        self.invoked_id = self.frame.pop(0)
        self.block_number = int.from_bytes(bytearray_pop_range(self.frame, 0, 4), 'big')

