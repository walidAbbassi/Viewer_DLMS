from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.dlms_enums import ActionResult, Command, ActionResponseType
from ng_sdk.frame_builder.dlms.xdlms.data_type.dlms_parser import DlmsDataParser
from ng_sdk.frame_builder.dlms.xdlms.get_data_result import GetDataResult


class DLMSActionResponseNormal(AbstractFrameResponse):
    invoked_id : int
    result: ActionResult
    return_parameter: GetDataResult
    __parser: DlmsDataParser = DlmsDataParser()
    def __init__(self, frame:bytes):
        super().__init__(bytearray(frame))
        received_frame = bytearray(frame)
        self.invoked_id = received_frame.pop(0)
        self.result =ActionResult.from_value(received_frame.pop(0))
        if self.result == ActionResult.SUCCESS:
            with_optional_parameter = received_frame.pop(0)
            if with_optional_parameter:
                self.return_parameter  = self.__parser.parse(received_frame,True)[0]
        else:
            with_optional_parameter = received_frame.pop(0)
            if with_optional_parameter:
                self.return_parameter = self.__parser.parse(received_frame, True)[0]
    def to_bytes(self) -> bytes:
        return bytes([Command.ACTION_RESPONSE, ActionResponseType.NORMAL]) + self.frame
    def is_success(self) ->bool:
        return self.result == ActionResult.SUCCESS