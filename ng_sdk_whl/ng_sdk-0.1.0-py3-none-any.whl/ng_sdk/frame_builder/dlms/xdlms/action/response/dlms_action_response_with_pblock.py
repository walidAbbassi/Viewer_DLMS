from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.xdlms.datablock_sa import DataBlockSA


class DLMSActionResponseWithPblock(AbstractFrameResponse):
    invoked_id : int
    pblock : DataBlockSA
    def __init__(self, frame:bytes):
        super().__init__(bytearray(frame))
        self.invoked_id = self.frame.pop(0)
        self.pblock = DataBlockSA.from_bytes(self.frame)


