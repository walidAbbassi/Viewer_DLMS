from abc import ABC, abstractmethod
from typing import Optional

from ng_sdk.security.security_context import SecurityContext


class AbstractFrameRequest(ABC):
    def __init__(self,payload:bytes):
        self.payload = payload

    @abstractmethod
    def to_bytes(self,security_context: Optional[SecurityContext] = None) -> bytes:
        raise NotImplementedError()
