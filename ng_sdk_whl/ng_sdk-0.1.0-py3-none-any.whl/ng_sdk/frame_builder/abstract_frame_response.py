from abc import ABC

class AbstractFrameResponse(ABC):
    def __init__(self,frame:bytearray):
        self.frame = frame

    def to_xml(self):
        raise NotImplemented

    def is_success(self)->bool:
        raise NotImplemented
