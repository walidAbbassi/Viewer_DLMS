import abc
from typing import Any


class AbstractDataType(abc.ABC):
    @classmethod
    @abc.abstractmethod
    def from_bytes(cls, source_bytes: bytes):
        pass

    @abc.abstractmethod
    def to_python(self) -> Any:
        pass

    @abc.abstractmethod
    def to_bytes(self) -> bytes:
        pass