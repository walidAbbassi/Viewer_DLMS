from abc import ABC, abstractmethod
from typing import List, Optional

from ng_sdk.configuration.config_manager import ConfigModuleProxy
from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.meter_request import MeterRequest
from ng_sdk.frame_builder.meter_response import MeterResponse
from ng_sdk.security.security_context import SecurityContext


class AbstractFrameBuilder(ABC):

    security_context: SecurityContext = None

    def __init__(self,configuration:ConfigModuleProxy,security_context:Optional[SecurityContext]=None):

        self.configuration = configuration
        self.security_context = security_context

    @abstractmethod
    def build(self, requests: List[AbstractFrameRequest], with_list: bool) -> List[MeterRequest]:
        pass

    @abstractmethod
    def parse(self,meter_response:MeterResponse) -> AbstractFrameResponse:
        pass
