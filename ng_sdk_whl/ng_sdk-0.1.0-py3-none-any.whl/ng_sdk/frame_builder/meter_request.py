from typing import List

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest


class MeterRequest:
    def __init__(self,frames:List[bytes],request:AbstractFrameRequest):
        self.frames = frames
        self.request = request