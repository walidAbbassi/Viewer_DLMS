import hashlib

from ng_sdk.security.abstracts.abstract_authenticator import AbstractAuthenticator  # Assuming this exists


class Sha256Authenticator(AbstractAuthenticator):


    def authenticate(self, data: bytes) -> bytes:

        result = hashlib.sha256(data).digest()
        return result

    def is_authenticated(self, data: bytes, data_to_verify: bytes) -> bool:
            return self.authenticate(data) == data_to_verify
