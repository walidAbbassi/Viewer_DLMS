import hashlib
from ng_sdk.security.abstracts.abstract_authenticator import AbstractAuthenticator


class Md5Authenticator(AbstractAuthenticator):


    def authenticate(self, data: bytes) -> bytes:
        return hashlib.md5(data).digest()

    def is_authenticated(self, data: bytes, data_to_verify: bytes) -> bool:
            return self.authenticate(data) == data_to_verify
