import base64

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec

from ng_sdk.configuration.config_manager import ConfigManager
from ng_sdk.security.abstracts.abstract_authenticator import AbstractAuthenticator


class EcdsaAuthenticator(AbstractAuthenticator):
    def __init__(self,configuration: ConfigManager):
        super().__init__(configuration)
        self._private_key = None
        self._public_key = None
        self._hash = None



    _PRIV_LEN = {ec.SECP256R1().name: 32, ec.SECP384R1().name: 48, ec.SECP521R1().name: 66}


    def authenticate(self, data: bytes) -> bytes:
        self.set_private_key(self.configuration.security.certificate.client_private_signed_key)
        sig_der = self._private_key.sign(data, ec.ECDSA(self._hash))
        return self._encode_sig(sig_der, "raw")
    def is_authenticated(self, data: bytes, data_to_verify: bytes) -> bool:
        self.set_public_key(self.configuration.security.certificate.meter_public_signed_key)
        try:
            sig_der = self._decode_sig(data_to_verify, "raw")
            self._public_key.verify(sig_der, data, ec.ECDSA(self._hash))
            return True
        except InvalidSignature:
            return False


    def set_private_key(self, private_key: bytes):
        curve = self._curve_from_bytes(private_key)
        # set hash algo
        if curve.name == "secp256r1":
            self._hash = hashes.SHA256()
        elif curve.name == "secp384r1":
            self._hash = hashes.SHA384()
        elif curve.name == "secp521r1":
            self._hash = hashes.SHA512()

        need = self._PRIV_LEN[curve.name]
        if len(private_key) > need:
            raise ValueError(f"Private scalar is too long for {curve.name} ({len(private_key)}>{need}).")
        if len(private_key) < need:
            private_key = private_key.rjust(need, b"\x00")
        d = int.from_bytes(private_key, "big")
        self._private_key = ec.derive_private_key(d, curve)

    def set_public_key(self, public_key: bytes):
        curve = self._curve_from_bytes(public_key,False)
        self._public_key = ec.EllipticCurvePublicKey.from_encoded_point(curve, public_key)


    @staticmethod
    def _curve_from_bytes(key_b: bytes | None,is_private=True):
        if  is_private:
            by = len(key_b)
            if by == 32: return ec.SECP256R1()
            if by == 48: return ec.SECP384R1()
            if by == 66: return ec.SECP521R1()

        else :
            first = key_b[0]
            by = len(key_b)
            if first == 0x04:
                if by == 65: return ec.SECP256R1()
                if by == 97: return ec.SECP384R1()
                if by == 133: return ec.SECP521R1()
            if first in (0x02, 0x03):
                if by == 33: return ec.SECP256R1()
                if by == 49: return ec.SECP384R1()
                if by == 67: return ec.SECP521R1()
        raise ValueError("Unable to infer curve from key lengths; specify curve explicitly (e.g., 'secp256r1').")

    @staticmethod
    def _encode_sig(sig_der: bytes, encoding: str) -> bytes:
        if encoding == "der":
            return sig_der
        if encoding == "hex":
            return sig_der.hex().encode()
        if encoding == "b64":
            return base64.urlsafe_b64encode(sig_der).rstrip(b"=")
        if encoding == "raw":
            from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
            r, s = decode_dss_signature(sig_der)
            byte_len = max((r.bit_length() + 7) // 8, (s.bit_length() + 7) // 8)
            return r.to_bytes(byte_len, "big") + s.to_bytes(byte_len, "big")
        raise ValueError("encoding must be one of: der, raw, hex, b64")

    @staticmethod
    def _decode_sig(encoded: bytes, encoding: str) -> bytes:
        if encoding == "der":
            return encoded
        if encoding == "hex":
            return bytes.fromhex(encoded.decode())
        if encoding == "b64":
            pad = b"=" * ((4 - len(encoded) % 4) % 4)
            return base64.urlsafe_b64decode(encoded + pad)
        if encoding == "raw":
            from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature
            raw = encoded
            if len(raw) % 2 != 0:
                raise ValueError("raw signature length must be even (r||s)")
            half = len(raw) // 2
            r = int.from_bytes(raw[:half], "big")
            s = int.from_bytes(raw[half:], "big")
            return encode_dss_signature(r, s)
        raise ValueError("encoding must be one of: der, raw, hex, b64")
