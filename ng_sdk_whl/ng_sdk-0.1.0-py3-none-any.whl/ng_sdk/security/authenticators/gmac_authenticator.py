from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from ng_sdk.configuration.config_manager import ConfigModuleProxy
from ng_sdk.constant.logger.constant import LoggingConstants
from ng_sdk.logger.logger import get_logger
from ng_sdk.security.abstracts.abstract_authenticator import AbstractAuthenticator

logger = get_logger()


class GmacAuthenticator(AbstractAuthenticator):
    iv: bytes

    def __init__(self, configuration=None, **kwargs):
        # keep parent behavior (your AbstractAuthenticator likely stores config/keys)
        super().__init__(configuration)
        self._mod = {LoggingConstants.MODULES_NAME: "GmacAuthenticator"}  # module tag for logs

    def authenticate(self, data: bytes) -> bytes:
        """
        Perform AES-GMAC authentication (GCM with AAD only).
        :param data: AAD (SC || AK || StoC)
        :return: GMAC tag (12 bytes)
        """
        logger.trace(f"GMAC.authenticate: start AAD_len={len(data) if data is not None else 0}", **self._mod)

        if self.iv is None:
            logger.error(
                "GMAC.authenticate: IV not present (ConfigModuleProxy).", **self._mod)
            raise ValueError("iv not present")

        encryptor = Cipher(
            algorithms.AES(self.configuration.security.key.encryption_key),
            modes.GCM(self.iv),
            backend=default_backend()
        ).encryptor()

        encryptor.authenticate_additional_data(data)
        encryptor.finalize()
        tag = encryptor.tag[:12]  # DLMS uses only 12-byte tag

        logger.trace(f"GMAC.authenticate: tag={tag.hex().upper()}", **self._mod)
        return tag

    def is_authenticated(self, data: bytes, data_to_verify: bytes, **kwargs) -> bool:
        logger.trace(
            f"GMAC.is_authenticated: AAD_len={len(data) if data is not None else 0} "
            f"expected_len={len(data_to_verify) if data_to_verify is not None else 0}", **self._mod)

        if isinstance(self.iv, ConfigModuleProxy):
            logger.error(
                "GMAC.is_authenticated: IV not present (ConfigModuleProxy).", **self._mod)
            raise ValueError("iv not present")

        ok = (self.authenticate(data) == data_to_verify)
        logger.trace(
            "INFO" if ok else "WARNING",
            f"GMAC.is_authenticated: match={ok}", **self._mod)
        return ok
