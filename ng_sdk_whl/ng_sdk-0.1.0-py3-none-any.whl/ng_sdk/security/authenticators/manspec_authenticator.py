

from ng_sdk.security.abstracts.abstract_authenticator import AbstractAuthenticator


class ManSpecAuthenticator(AbstractAuthenticator):
    def authenticate(self, data: bytes) -> bytes:
        raise NotImplementedError
    def is_authenticated(self, data: bytes, data_to_verify: bytes) -> bool:
            raise NotImplementedError
