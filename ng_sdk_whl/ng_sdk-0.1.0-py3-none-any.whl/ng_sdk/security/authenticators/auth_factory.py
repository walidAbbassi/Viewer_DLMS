import threading
from typing import Dict, Type

from ng_sdk.configuration.config_manager import ConfigModuleProxy
from ng_sdk.security.abstracts.abstract_authenticator import AbstractAuthenticator
from ng_sdk.session.hls_mechanism import HlsMechanism

_AUTH_REGISTRY: Dict[str, Type[AbstractAuthenticator]] = {}
def register_authenticator(name: str):
    def _wrap(cls: Type[AbstractAuthenticator]):
        _AUTH_REGISTRY[name] = cls
        return cls

    return _wrap
class AuthFactory:
    _cache_lock = threading.Lock()
    _instance_cache: Dict[str, AbstractAuthenticator] = {}



    @classmethod
    def from_config(cls, cfg: ConfigModuleProxy) -> AbstractAuthenticator:
        # If creation is cheap or authenticators hold per-request state,
        # remove caching — or key cache differently.
        security_level = cfg.security.security_level
        hls_mechanism = HlsMechanism[security_level.name]

        with cls._cache_lock:
            inst = cls._instance_cache.get(hls_mechanism)
            if inst:
                return inst

            try:
                ctor = _AUTH_REGISTRY[hls_mechanism]
            except KeyError:
                raise ValueError(f"Unknown authenticator type: {cfg.security.security_level!r}")

            inst = ctor(cfg)
            cls._instance_cache[hls_mechanism] = inst
            return inst