from ng_sdk.configuration.config_manager import ConfigModuleProxy
from ng_sdk.error.security_exception import SecurityError, SecurityException
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.security.authenticators.auth_factory import register_authenticator, AuthFactory
from ng_sdk.security.authenticators.ecdsa_authenticator import EcdsaAuthenticator
from ng_sdk.security.authenticators.gmac_authenticator import GmacAuthenticator
from ng_sdk.security.authenticators.md5_authenticator import Md5Authenticator
from ng_sdk.security.authenticators.sha1_authenticator import Sha1Authenticator
from ng_sdk.security.authenticators.sha256_authenticator import Sha256Authenticator
from ng_sdk.security.encryptors.aes_gcm_encryptor import AesGcmEncryptor
from ng_sdk.security.security_constant import DlmsSecurityPolicy
from ng_sdk.session.hls_mechanism import HlsMechanism
from ng_sdk.util.bytes_util import to_bytes_from_hexish

logger = get_logger()


class SecurityContext:
    def __init__(self, configuration: ConfigModuleProxy):
        self._mod = {LoggingConstants.MODULES_NAME: "SecurityContext"}
        self.encryptor = AesGcmEncryptor()
        self.configuration = configuration
        register_authenticator(HlsMechanism.HIGH_GMAC)(GmacAuthenticator)
        register_authenticator(HlsMechanism.HIGH_ECDSA)(EcdsaAuthenticator)
        register_authenticator(HlsMechanism.HIGH_SHA256)(Sha256Authenticator)
        register_authenticator(HlsMechanism.HIGH_MD5)(Md5Authenticator)
        register_authenticator(HlsMechanism.HIGH_SHA1)(Sha1Authenticator)
        # To do
        self.signer = None
        self.key_wrapper = None
        self.key_agreement = None
        self.compressor = None
        self.data_protection_encryptor = None

    def cipher(self, data: bytes) -> bytes:
        if self.encryptor is None:
            return data
        security_policy = self.configuration.security.security_policy
        is_authenticated = security_policy == DlmsSecurityPolicy.A or security_policy == DlmsSecurityPolicy.AE
        is_encrypted = security_policy == DlmsSecurityPolicy.E or security_policy == DlmsSecurityPolicy.AE
        iv = bytearray()
        frame_counter = self.get_frame_counter()
        system_title = self.get_system_title()
        iv.extend(system_title)
        iv.extend(frame_counter)
        encryption_key = self.get_encryption_key()
        authentication_key = self.get_authentication_key()
        security_suite = getattr(self.configuration.security, "security_suite", 0)
        security_control = (security_policy + security_suite).to_bytes()
        authentication = bytearray()
        authentication.extend(security_control)
        authentication.extend(authentication_key)
        sh = bytearray()
        sh.extend(security_control)
        sh.extend(frame_counter)
        ciphered_apdu = bytearray()
        ciphered_data = self.encryptor.cipher(data, iv, authentication, encryption_key, is_authenticated, is_encrypted)
        ciphered_apdu.extend(sh)
        ciphered_apdu.extend(ciphered_data)
        logger.info("CIPHERING:", **self._mod)
        logger.info(
            f" SC = 0x{security_control.hex().upper()} | FC=0x{frame_counter.hex().upper()} | SYSTEM TITLE=0x{system_title.hex().upper()}",
            **self._mod)
        logger.info(f" EK=0x{encryption_key.hex().upper()} | AK=0x{authentication_key.hex().upper()}", **self._mod)
        logger.info(f" PLAIN  = 0x{data.hex().upper()}", **self._mod)
        logger.info(" -----------", **self._mod)
        logger.info(f" CIPHER = 0x{ciphered_data[:-12].hex().upper()}", **self._mod)
        logger.info(f" TAG = 0x{ciphered_data[-12:].hex().upper()}", **self._mod)

        self.inc_frame_counter()
        return ciphered_apdu

    def decipher(self, ciphered_data: bytes) -> bytes:
        if self.encryptor is None:
            return ciphered_data

        # remove sh from data 5 bytes
        sh = bytearray(ciphered_data[:5])
        data = ciphered_data[5:]
        security_control = sh.pop(0)
        security_policy = DlmsSecurityPolicy(security_control & 0xF0)
        is_authenticated = security_policy == DlmsSecurityPolicy.A or security_policy == DlmsSecurityPolicy.AE
        is_encrypted = security_policy == DlmsSecurityPolicy.E or security_policy == DlmsSecurityPolicy.AE
        iv = bytearray()
        server_system_title = self.get_server_system_title()
        iv.extend(server_system_title)
        iv.extend(sh)
        encryption_key = self.get_encryption_key()
        authentication_key = self.get_authentication_key()
        authentication = bytearray()
        authentication.extend(security_control.to_bytes())
        authentication.extend(authentication_key)
        deciphered_data = self.encryptor.decipher(data, iv, authentication, encryption_key, is_authenticated,
                                                  is_encrypted)
        logger.info("DECIPHERING", **self._mod)
        logger.info(
            f" SC={hex(security_control)} | FC=0x{sh.hex().upper()} | SERVER SYSTEM TITLE=0x{server_system_title.hex().upper()}",
            **self._mod)
        logger.info(f" EK=0x{encryption_key.hex().upper()} | AK=0x{authentication_key.hex().upper()}", **self._mod)
        logger.info(f" INPUT  = 0x{data.hex().upper()}", **self._mod)
        logger.info(" -----------", **self._mod)
        logger.info(f" OUTPUT = 0x{deciphered_data.hex().upper()}", **self._mod)
        return deciphered_data

    def cipher_data(self, data: bytes, iv: bytes, auth_key: bytes, encryption_key: bytes) -> bytes:
        return self.data_protection_encryptor.cipher(data, iv, auth_key, encryption_key)

    def decipher_data(self, ciphered_data: bytes, iv: bytes, auth_key: bytes, encryption_key: bytes) -> bytes:
        return self.data_protection_encryptor.decipher(ciphered_data, iv, auth_key, encryption_key)

    def wrap_key(self, key: bytes, iv: bytes, auth_key: bytes, encryption_key: bytes) -> bytes:
        return self.key_wrapper.cipher(key, iv, auth_key, encryption_key)

    def unwrap_key(self, wrapped_key: bytes, iv: bytes, auth_key: bytes, encryption_key: bytes) -> bytes:
        return self.key_wrapper.decipher(wrapped_key, iv, auth_key, encryption_key)

    def computation(self, **kwargs):
        return self.key_agreement.computation(**kwargs)

    def derive_secret_keying_material(self, **kwargs):
        return self.key_agreement.derive_secret_keying_material(**kwargs)

    def is_authenticated(self, data: bytes, data_to_verify: bytes) -> bool:
        authenticator = AuthFactory.from_config(self.configuration)
        if isinstance(authenticator, GmacAuthenticator):
            iv = bytearray()
            iv.extend(self.get_server_system_title())
            iv.extend(data_to_verify[1:5])
            data_to_verify = data_to_verify[5:]
            authenticator.iv = iv
        return authenticator.is_authenticated(data, data_to_verify)

    def authenticate(self, data):
        authenticator = AuthFactory.from_config(self.configuration)
        authentication_data = bytearray()
        config = {}
        if isinstance(authenticator, GmacAuthenticator):
            # SC II IC II GMAC(SC || AK || StoC)
            ic = self.get_frame_counter()
            if ic is None or not isinstance(ic, (bytes, bytearray, str)):
                raise SecurityException(SecurityError.INVOCATION_COUNTER_INCORRECT)
            ic = to_bytes_from_hexish(ic)
            st = self.get_system_title()
            security_suite = getattr(self.configuration.security, "security_suite", 0)
            sc = DlmsSecurityPolicy.A + security_suite
            iv = bytearray()
            iv.extend(st)
            iv.extend(ic)
            authenticator.iv = iv
            authentication_data.extend(sc.to_bytes())
            authentication_data.extend(ic)
        authentication_data.extend(authenticator.authenticate(data))
        return authentication_data

    def compress(self, data, **kwargs):
        return self.compressor.compress(data)

    def decompress(self, data, **kwargs):
        return self.compressor.decompress(data)

    def get_frame_counter(self) -> bytes:
        return self.configuration.security.frame_counter.to_bytes(4, byteorder='big')

    def get_system_title(self) -> bytes:
        return self.configuration.security.system_title

    def get_server_system_title(self) -> bytes:
        return self.configuration.security.server_system_title

    def set_server_system_title(self, ap_title):
        self.configuration.security.server_system_title = ap_title

    def get_authentication_key(self) -> bytes:
        return self.configuration.security.key.authentication_key

    def get_encryption_key(self) -> bytes:
        if getattr(self.configuration.session.initiate_request, 'use_dedicated_key', False):
            dedicated_key = self.configuration.security.key.dedicated_key
            if not isinstance(dedicated_key, bytes):
                raise SecurityException(SecurityError.DEDICATED_KEY_NOT_CONFIGURED)
            return dedicated_key
        return self.configuration.security.key.encryption_key

    def inc_frame_counter(self):
        self.configuration.security.frame_counter = self.configuration.security.frame_counter + 1
