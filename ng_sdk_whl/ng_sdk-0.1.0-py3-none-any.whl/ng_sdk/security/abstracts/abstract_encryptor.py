from abc import ABC, abstractmethod


class AbstractEncryptor(ABC):
    @abstractmethod
    def cipher(self, data: bytes, iv: bytes, authentication: bytes, encryption_key: bytes, is_authenticated: bool = True, is_encrypted: bool = True) -> bytes:
        raise NotImplementedError

    @abstractmethod
    def decipher(self, ciphered_data: bytes, iv: bytes, authentication: bytes, encryption_key: bytes, is_authenticated: bool = True, is_encrypted: bool = True) -> bytes:
        raise NotImplementedError
