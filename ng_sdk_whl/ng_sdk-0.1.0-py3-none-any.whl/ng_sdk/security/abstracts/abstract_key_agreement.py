from abc import ABC, abstractmethod
from typing import Dict


class AbstractKeyAgreement(ABC):
    def __init__(self, domain_parameter, static_data, ephemeral_data):
        self.domain_parameter = domain_parameter
        self.static_data = static_data
        self.ephemeral_data = ephemeral_data

    @abstractmethod
    def computation(self, **kwargs) -> Dict[str, bytes]:
        raise NotImplementedError

    @abstractmethod
    def derive_secret_keying_material(self, **kwargs) -> Dict[str, bytes]:
        raise NotImplementedError
