from abc import ABC, abstractmethod


class AbstractCompressor(ABC):
    @abstractmethod
    def compress(self, data: bytes,**kwargs) -> bytes:
        raise NotImplementedError

    @abstractmethod
    def decompress(self, data: bytes,**kwargs) -> bytes:
        raise NotImplementedError
