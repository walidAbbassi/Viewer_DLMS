#!/usr/bin/env python
# -*- coding: utf-8 -*-
# **!@#=======================================================================
# **!@# File
# **!@#=======================================================================
# **!@# /Nom            : abstract_ecdsa_security.py
# **!@# /Description    : --
# **!@# /Auteur         :
# **!@# /Date           :
# **!@# /Update         :
# **!@# /Entree         : --
# **!@#=======================================================================


from abc import ABC, abstractmethod


class AbstractSigner(ABC):

    @abstractmethod
    def sign(self, data: bytes,**kwargs) -> bytes:
        raise NotImplementedError

    @abstractmethod
    def verify(self, data: bytes,**kwargs) -> bool:
        raise NotImplementedError
