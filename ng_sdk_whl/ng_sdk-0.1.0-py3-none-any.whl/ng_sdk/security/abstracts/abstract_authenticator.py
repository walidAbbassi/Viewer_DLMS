from abc import ABC, abstractmethod

from ng_sdk.configuration.config_manager import ConfigManager, ConfigModuleProxy


class AbstractAuthenticator(ABC):
    def __init__(self, configuration: ConfigModuleProxy):
        self.configuration = configuration
    @abstractmethod
    def authenticate(self, data: bytes) -> bytes:
        raise NotImplementedError

    @abstractmethod
    def is_authenticated(self, data: bytes,data_to_verify: bytes) -> bool:
        raise NotImplementedError
