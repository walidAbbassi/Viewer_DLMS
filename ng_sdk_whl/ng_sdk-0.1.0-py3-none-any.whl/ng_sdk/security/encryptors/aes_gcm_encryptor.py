from typing import Tuple

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

from ng_sdk.security.abstracts.abstract_encryptor import AbstractEncryptor
from ng_sdk.security.security_constant import DlmsAES


class AesGcmEncryptor(AbstractEncryptor):

    def cipher(self, data: bytes, iv: bytes, authentication: bytes, encryption_key: bytes, is_authenticated: bool = True, is_encrypted: bool = True) -> bytes:
        encryptor = Cipher(algorithms.AES(key=encryption_key),
                           modes.GCM(initialization_vector=iv, tag=None, min_tag_length=12),
                           backend=default_backend()).encryptor()
        if is_authenticated and is_encrypted and authentication:
            encryptor.authenticate_additional_data(authentication)
            # Perform encryption
            cipher_frame_binary = encryptor.update(data)
            # finalize encryption before getting the tag
            encryptor.finalize()
            authentication_tag_binary = encryptor.tag[:12] if len(encryptor.tag) >= 12 else encryptor.tag  # DLMS_GCM : Truncate mac_len = 12
            return cipher_frame_binary + authentication_tag_binary
        elif not is_authenticated and is_encrypted:
            # Perform encryption
            cipher_frame_binary = encryptor.update(data)
            # finalize encryption
            encryptor.finalize()
            return cipher_frame_binary
        elif is_authenticated and not is_encrypted and authentication:
            # Add AAD : Combined additional_authenticated_data + plain_frame
            encryptor.authenticate_additional_data(authentication + data)
            # finalize encryption before getting the tag
            encryptor.finalize()
            authentication_tag_binary = encryptor.tag[:12] if len(encryptor.tag) >= 12 else encryptor.tag  # DLMS_GCM : Truncate mac_len = 12
            return data + authentication_tag_binary
        else:
            return data

    def decipher(self, ciphered_data: bytes, iv: bytes, authentication: bytes, encryption_key: bytes, is_authenticated: bool = True, is_encrypted: bool = True) -> bytes:
        if is_authenticated and is_encrypted and authentication:
            ciphered_bytes, authentication_tag_bytes = self.__cipher_key_split(ciphered_data)
            decryptor = Cipher(algorithms.AES(encryption_key), modes.GCM(initialization_vector=iv, tag=bytes(authentication_tag_bytes), min_tag_length=12), backend=default_backend()).decryptor()
            decryptor.authenticate_additional_data(authentication)
            plain_frame_bytes = decryptor.update(bytes(ciphered_bytes))
            decryptor.finalize()
            return plain_frame_bytes
            # only encryption :  not authenticated and not encrypted (E)
        elif not is_authenticated and is_encrypted:
            decryptor = Cipher(algorithms.AES(encryption_key), modes.CTR(iv), backend=default_backend()).decryptor()
            plain_frame_bytes = decryptor.update(ciphered_data)
            decryptor.finalize()
            return plain_frame_bytes
        return ciphered_data

    @staticmethod
    def __cipher_key_split(data: bytes) -> Tuple[bytes, bytes]:
        """
        Split the message ciphered key so part of it is used for encrypt/decrypt message and other part for authentication tag.
        :param data: message ciphered key (bytes)
        :return: cipher_data, authentication_tag (bytes)
        """
        # data:variable static
        if len(data) <= DlmsAES.AES_AUTHENTICATED_TAG_OCTET_SIZE:
            raise Exception('message ciphered key length incorrect')
        cipher_data = data[:-DlmsAES.AES_AUTHENTICATED_TAG_OCTET_SIZE]
        authentication_tag = data[-DlmsAES.AES_AUTHENTICATED_TAG_OCTET_SIZE:]
        return cipher_data, authentication_tag
