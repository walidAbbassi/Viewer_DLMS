# StaticUnifiedModelC0e2s.py
from typing import Dict

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.concatkdf import ConcatKDFHash

from ng_sdk.security.abstracts.abstract_key_agreement import AbstractKeyAgreement


class StaticUnified0e2sAgreement(AbstractKeyAgreement):
    def __init__(self, domain_parameter, static_data, ephemeral_data):
        super().__init__(domain_parameter, static_data, ephemeral_data)

    def computation(self, **kwargs) -> Dict[str, bytes]:
        priv_key = self.static_data["static_private_key"]
        peer_pub_key = self.static_data["peer_static_public_key"]
        # Perform ECDH key agreement
        shared_secret = priv_key.exchange(ec.ECDH(), peer_pub_key)
        return {"Z": shared_secret}

    def derive_secret_keying_material(self, **kwargs) -> Dict[str, bytes]:
        # Prepare OtherInfo
        other_info =kwargs["other_info"]


        # Derive keys using ConcatKDF with SHA-256
        kdf = ConcatKDFHash(
            algorithm=hashes.SHA256(),
            length=32,
            otherinfo=other_info,
            backend=default_backend(),
        )

        key = kdf.derive(kwargs["z"])

        return {

            "KDF": key,
            "EK": key[:16],
        }

