from __future__ import annotations

from typing import Dict

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.concatkdf import ConcatKDFHash

from ng_sdk.security.abstracts.abstract_key_agreement import AbstractKeyAgreement


class OnePassDiffieHellman1e1s(AbstractKeyAgreement):
    """
    DLMS/COSEM C(1e,1s) One-pass Diffie–Hellman (ECC-CDH).
    """

    def __init__(self, domain_parameter=None, static_data=None, ephemeral_data=None):
        super().__init__(domain_parameter or {}, static_data or {}, ephemeral_data or {})

    def computation(self, **kwargs) -> Dict[str, bytes]:
        # ECDH: Z = d_e * Q_s
        z = self.ephemeral_data["epri_local"].exchange(
            ec.ECDH(), self.static_data["ka_pub_peer"]
        )
        return {"Z": z}

    def derive_secret_keying_material(self, **kwargs) -> Dict[str, bytes]:
        z = self.computation()["Z"]
        alg_id: bytes = kwargs["algorithm"]
        sys_title_u: bytes = kwargs["sys_title_u"]
        sys_title_v: bytes = kwargs["sys_title_v"]
        key_bits: int = kwargs.get("key_bits", 128)

        other_info = alg_id + sys_title_u + sys_title_v

        kdf = ConcatKDFHash(
            algorithm=hashes.SHA256(),
            length=key_bits // 8,
            otherinfo=other_info,
            backend=default_backend()
        )
        guek = kdf.derive(z)

        return {
            "z": z,
            "kdf": guek,
            "ek": guek[:16]
        }