from __future__ import annotations

import math
import struct
from typing import Dict, Union

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.ec import (
    EllipticCurvePrivateKey, EllipticCurvePublicKey,
)
from cryptography.hazmat.primitives.serialization import (
    load_pem_public_key, load_der_public_key,
    load_pem_private_key, load_der_private_key,
)

from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.security.abstracts.abstract_key_agreement import AbstractKeyAgreement


class EphemeralUnifiedModelC2e0s(AbstractKeyAgreement):
    """
    DLMS/COSEM Ephemeral Unified Model C (2e,0s, ECC-CDH)

    OtherInfo (for C(2e,0s)):
        OtherInfo = AlgorithmID || ID_U || ID_V
      *To match DLMS table vectors*, AlgorithmID is encoded as DER TLV for OID:
        AlgorithmID = 0x06 0x07 || <7-byte OID value from Table 26>
    """

    def __init__(self, domain_parameter=None, static_data=None, ephemeral_data=None):
        super().__init__(domain_parameter or {}, static_data or {}, ephemeral_data or {})

    # ---------------- helpers ----------------
    @staticmethod
    def _hash_for_keybits(key_bits: int) -> hashes.HashAlgorithm:
        if key_bits == 128:
            return hashes.SHA256()
        if key_bits == 256:
            return hashes.SHA384()
        raise ValueError("key_bits must be 128 or 256.")

    @staticmethod
    def _kdf_concat(z: bytes, key_len_bits: int, other_info: bytes, hash_alg: hashes.HashAlgorithm) -> bytes:
        """SP800-56A Concatenation KDF: H(counter||Z||OtherInfo) repeated, truncated."""
        hlen = hash_alg.digest_size
        reps = math.ceil(((key_len_bits + 7) // 8) / hlen)
        out = b""
        for i in range(1, reps + 1):
            h = hashes.Hash(hash_alg)
            h.update(struct.pack(">I", i))
            h.update(z)
            h.update(other_info)
            out += h.finalize()
        return out[: key_len_bits // 8]

    @staticmethod
    def _load_pub_key(curve: ec.EllipticCurve, data: Union[EllipticCurvePublicKey, bytes]) -> EllipticCurvePublicKey:
        if isinstance(data, EllipticCurvePublicKey):
            return data
        try:
            return load_pem_public_key(data)
        except Exception:
            try:
                return load_der_public_key(data)
            except Exception:
                return EllipticCurvePublicKey.from_encoded_point(curve, data)

    @staticmethod
    def _load_priv_key(curve: ec.EllipticCurve, data: Union[EllipticCurvePrivateKey, bytes]) -> EllipticCurvePrivateKey:
        if isinstance(data, EllipticCurvePrivateKey):
            return data
        try:
            return load_pem_private_key(data, password=None)
        except Exception:
            try:
                return load_der_private_key(data, password=None)
            except Exception:
                d_int = int.from_bytes(data, "big")
                return ec.derive_private_key(d_int, curve)

    @staticmethod
    def _verify_ecdsa(pub: EllipticCurvePublicKey, message: bytes, signature_der: bytes, hash_alg: hashes.HashAlgorithm):
        try:
            pub.verify(signature_der, message, ec.ECDSA(hash_alg))
        except InvalidSignature as e:
            raise ValueError("ECDSA signature verification failed") from e

    # ---------------- AbstractKeyAgreement API ----------------
    def computation(self, **kwargs) -> Dict[str, bytes]:
        """
        Compute ECDH shared secret Z.
        If verify_signature=True, verify peer's signature over epub (or given message).
        """
        curve: ec.EllipticCurve = self.domain_parameter.get("curve", ec.SECP256R1())
        epri_local = self._load_priv_key(curve, self.ephemeral_data["epri_local"])
        epub_peer = self._load_pub_key(curve, self.ephemeral_data["epub_peer"])

        if kwargs.get("verify_signature", True):
            sig_hash = kwargs.get("sig_hash", hashes.SHA256())
            sign_pub_peer = self._load_pub_key(curve, self.static_data["sign_pub_peer"])
            msg = self.ephemeral_data.get("peer_sig_message", None) or self.ephemeral_data["epub_peer"]
            self._verify_ecdsa(sign_pub_peer, msg, self.ephemeral_data["peer_signature"], sig_hash)

        z = epri_local.exchange(ec.ECDH(), epub_peer)
        return {"Z": z}

    def derive_secret_keying_material(self, **kwargs) -> Dict[str, bytes]:
        """
        Build OtherInfo and run the NIST Concat KDF.

        Kwargs:
          transaction_id : bytes(8)  # U's system title (Sys-TC or Sys-TS)
          algorithm      : bytes|str # 7-byte OID value or 'AES-GCM'/'AES-WRAP'
          key_bits       : int       # 128 (Suite 1) or 256 (Suite 2)
          kdf_len_bits   : int       # total KDF output bits (default = 2*key_bits per DLMS vectors)
          z              : bytes     # optional precomputed Z
          use_der_oid_tlv: bool      # default True: include DER OID TLV (06 07) in OtherInfo
        """
        transaction_id: bytes = kwargs["transaction_id"]
        key_bits: int = kwargs["key_bits"]
        algorithm: Union[bytes, str] = kwargs["algorithm"]
        kdf_len_bits: int = kwargs.get("kdf_len_bits", 2 * key_bits)
        use_der_oid_tlv: bool = kwargs.get("use_der_oid_tlv", True)

        # Resolve 7-byte OID value
        if isinstance(algorithm, (bytes, bytearray)):
            alg_id = bytes(algorithm)
            if len(alg_id) != 7:
                raise ValueError("AlgorithmID must be exactly 7 bytes (OID value).")
        else:
            algo = str(algorithm).upper()
            table = kwargs.get("algorithm_table")
            if table:
                try:
                    alg_id = table[(algo, key_bits)]
                except KeyError:
                    raise ValueError("algorithm_table missing entry for (algo, key_bits)")
            else:
                if algo == "AES-GCM":
                    alg_id = Constant.AES_GCM_256_ALG_ID if key_bits == 256 else Constant.AES_GCM_128_ALG_ID
                elif algo == "AES-WRAP":
                    alg_id = Constant.AES_WRAP_256_ALG_ID if key_bits == 256 else Constant.AES_WRAP_128_ALG_ID
                else:
                    raise ValueError("algorithm must be 7-byte OID value or 'AES-GCM'/'AES-WRAP'")

        # Determine U and V from transaction_id
        sys_tc: bytes = self.static_data["sys_tc"]
        sys_ts: bytes = self.static_data["sys_ts"]
        if transaction_id == sys_tc:
            id_u, id_v = sys_tc, sys_ts
        elif transaction_id == sys_ts:
            id_u, id_v = sys_ts, sys_tc
        else:
            raise ValueError("transaction_id must equal sys_tc or sys_ts (8 bytes).")
        if len(id_u) != 8 or len(id_v) != 8:
            raise ValueError("System titles must be 8 bytes each.")

        # Build AlgorithmID field (DER OID TLV if requested) to match DLMS test vectors
        alg_field = (b"\x06\x07" + alg_id) if use_der_oid_tlv else alg_id
        other_info = alg_field + id_u + id_v

        # Z
        z = kwargs.get("z", None)
        if z is None:
            z = self.computation(**kwargs).get("Z")


        # KDF
        hash_alg = EphemeralUnifiedModelC2e0s._hash_for_keybits(key_bits)
        kdf_full = EphemeralUnifiedModelC2e0s._kdf_concat(z, kdf_len_bits, other_info, hash_alg)

        # DLMS parsing rule: GUEK = left-most key_bits/8 bytes from KDF
        guek = kdf_full[: key_bits // 8]

        return {
            "AlgorithmID": alg_id,  # 7-byte OID value (for logging)
            "OtherInfo": other_info,  # actually used bytes (TLV + IDs)
            "KDF": kdf_full,
            "GUEK": guek,
            "Z": z,
        }