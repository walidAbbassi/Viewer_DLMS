# **!@#=========================================================================
# **!@#                                 DEFINITION Meta Class CONSTANTS
# **!@#=========================================================================
from enum import IntEnum


class MetaClassConstants(type):
    def __getattr__(cls, key):
        return cls[key]

    def __setattr__(cls, key, value):
        print("Forbidden Change Constant: " + str(key) + " with value = " + str(value), 'DLMS_CONSTANTS')
        raise TypeError

    def get_all_attributes(cls):
        """
        get dictionary containing all attributes of the current class.
        :return: dictionary of class attributes.
        """
        return {key: value for key, value in vars(cls).items() if not key.startswith('__')}

    def check_attribute_exist(cls, tag_str):
        """
        get dictionary containing all attributes of the current class.
        :param tag_str: ciphered DLMS message (string)
        :return: check result (Boolean)
        """
        if tag_str.upper() in cls.get_all_attributes().values():
            return True
        return False


# **!@#=========================================================================
# **!@#                                 DEFINITION Class CONSTANTS
# **!@#=========================================================================

class DlmsClientObjectConstants(object):
    __metaclass__ = MetaClassConstants

    def __getattr__(self, name):
        return self[name]

    def __setattr__(self, name, value):
        print("Forbidden Change Constant: " + str(self[name]) + " with value = " + str(self[value]), 'DLMS_CONSTANTS')
        raise TypeError


# **!@#=========================================================================
# **!@#                           DEFINITION CONSTANTS AES
# **!@#=========================================================================

class DlmsAES(IntEnum):
    AES_GCM_128 = 0                                 # AES_GCM_128 (security 0)
    AES_GCM_128_SHA_256 = 1                         # ECDH_ECDSA_AES_GCM_128_SHA_256 (security 1)
    AES_GCM_256_SHA_384 = 2                         # ECDHE_CDSA_AES_GCM_256_SHA_384 (security 2)
    AES_INITIAL_VECTOR_OCTET_SIZE = 12              # initialization vector IV (12 octets) : len(EK) = 96
    AES_KEY_128_OCTET_SIZE = 16                     # Security Suite 0 and 1, 128 bits (16 octets): len(EK) = 128
    AES_KEY_256_OCTET_SIZE = 32                     # Security Suite 2, 256 bits (32 octets): len(EK) = 256
    AES_AUTHENTICATED_TAG_OCTET_SIZE = 12           # Additional Authenticated Data (AAD)

class DlmsTypeAES(IntEnum):
    AES_128 = 0                                     # AES_128
    AES_256 = 1                                     # AES_256

class DlmsSecurityPolicy(IntEnum):
    A = 0x10                       # Security Suite 0
    E = 0x20
    AE = 0x30
    NoSecurity = 0x00

class DlmsEcdsaHash(IntEnum):
    HASHLIB_SHA192 = 192
    HASHLIB_SHA224 = 224
    HASHLIB_SHA256 = 256
    HASHLIB_SHA384 = 384
    HASHLIB_SHA512 = 512

class DlmsEcdsaKeySize(IntEnum):
    hashlib_sha192 = 48
    hashlib_sha224 = 56
    hashlib_sha256 = 64
    hashlib_sha384 = 96
    hashlib_sha512 = 132

class DlmsSecurityLevel(IntEnum):
        LOWEST = 0
        LOW = 1  # LLS
        HIGH_MD5 = 3  # HLS 3
        HIGH_SHA1 = 4  # HLS 4
        HIGH_GMAC = 5  # HLS 5
        HIGH_SHA_256 = 6  # HLS 6
        HIGH_ECDSA = 7  # HLS 7

class DlmsCipheringType(IntEnum):
    GLOBAL_CIPHERING = 0
    GENERAL_GLOBAL_CIPHERING = 1
    DEDICATED_CIPHERING = 2
    GENERAL_DEDICATED_CIPHERING = 3
    GENERAL_CIPHERING = 4
    GENERAL_SIGNING = 5
    NO_CIPHERING = 9