from ng_sdk.constant.logger.constant import LoggingConstants
from ng_sdk.logger.logger import get_logger
from ng_sdk.transport.abstract_transport import AbstractTransport

logger = get_logger()

class TCPUDPTransport(AbstractTransport):
    _mod = {LoggingConstants.MODULES_NAME: "TCPUDPTransport"}  # module tag for logs
    def __init__(self, configuration):
        super().__init__()
        self.configuration = configuration
    def wrap(self, data: bytes, **kwargs) -> bytes:
        version = 0x0001
        # Read IDs from config (must exist in json)
        device_id = int(kwargs["device_id"] if "device_id" in kwargs else self.configuration.communication.tcp.device_id)
        assoc_id = int(kwargs["association_id"] if "association_id" in kwargs else self.configuration.communication.tcp.association_id)

        # DC → BN direction (client → meter)
        # SDK always acts as DC
        source_port = assoc_id
        dest_port = device_id

        length = len(data)

        header = (
                version.to_bytes(2, "big") +
                source_port.to_bytes(2, "big") +
                dest_port.to_bytes(2, "big") +
                length.to_bytes(2, "big")
        )

        return header + data

    def unwrap(self, data: bytes, **kwargs) -> bytes:
        logger.info(f"Data to unwrap: {data.hex().upper()}", **self._mod)
        version = int.from_bytes(data[0:2], "big")
        if version != 1:
            logger.warning(f"Unexpected DLMS/TCP version: {version}", **self._mod)

        self.source_port = int.from_bytes(data[2:4], "big")
        self.dest_port = int.from_bytes(data[4:6], "big")
        apdu_length = int.from_bytes(data[6:8], "big")
        apdu = data[8:8 + apdu_length]

        return apdu

    @staticmethod
    def is_complete(frame: bytes) -> bool:
        if len(frame) < 8:
            return False
        frame_length = int.from_bytes(frame[6:8])
        logger.info(f"Frame length: {frame_length}, received: {len(frame) - 8}", **TCPUDPTransport._mod)
        return len(frame) - 8 >= frame_length