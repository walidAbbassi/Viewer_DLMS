# add at the top of the file
from ng_sdk.logger.logger import LoggingConstants, get_logger

logger = get_logger()


class HdlcAddress:
    VALID_LENGTHS = (1, 2, 4)  # Define valid lengths as a constant
    _mod = {LoggingConstants.MODULES_NAME: "HDLC"}

    @staticmethod
    def encode_hdlc_address(*args) -> bytes:
        """
        Encodes an HDLC address based on the provided arguments.
        """
        if len(args) == 3:
            # Case: lower_address, upper_address, address_length
            lower_address, upper_address, address_length = args
            HdlcAddress.__validate_length(address_length)
            full_address = (upper_address << (7 * (address_length - (address_length // 2)))) | lower_address
        elif len(args) == 2:
            # Case: full_address, address_length
            full_address, address_length = args
            HdlcAddress.__validate_length(address_length)
            lower_address, upper_address = HdlcAddress.__split_lower_upper(full_address, address_length)
            full_address = (upper_address << (7 * (address_length - (address_length // 2)))) | lower_address
        else:
            logger.error(
                "encode_hdlc_address: wrong arity "
                "(expected (lower, upper, len) or (full, len))",
                **HdlcAddress._mod)
            raise TypeError("Expected call: (lower_address, upper_address, length) or (full_address, length)")

        encoded_parts = []
        for i in reversed(range(address_length)):
            part = (full_address >> (7 * i)) & 0x7F  # Extract 7 bits
            if i == 0:
                part = (part << 1) | 1  # Last byte: add the end bit
            else:
                part = (part << 1)  # Other bytes: add a continuation bit
            encoded_parts.append(part)

        out = bytes(encoded_parts)
        logger.trace(
            f"encode_hdlc_address -> full=0x{full_address:X} bytes={out.hex().upper()}",
            **HdlcAddress._mod)
        return out

    @staticmethod
    def decode_hdlc_address(encoded_data: bytes) -> tuple[tuple[str, str], int]:
        """
        Decodes an HDLC address encoded as bytes.
        """
        logger.trace(
            f"decode_hdlc_address in={encoded_data.hex().upper()}",
            **HdlcAddress._mod)

        full_address = 0
        for index, byte in enumerate(encoded_data):
            full_address = (full_address << 7) | (byte >> 1)
            if byte & 0x01:  # end bit
                if index + 1 == 1:
                    lower_address = full_address & 0x7F
                    upper_address = 0
                elif index + 1 == 2:
                    upper_address = full_address >> 7
                    lower_address = full_address & 0x7F
                elif index + 1 == 4:
                    lower_address = full_address & 0x3FFF
                    upper_address = (full_address >> 14) & 0x3FFF
                else:
                    logger.error(
                        f"decode_hdlc_address: unsupported length {index + 1}",
                        **HdlcAddress._mod)
                    raise ValueError("Unsupported HDLC address length")

                res = ((hex(lower_address), hex(upper_address)), index + 1)
                logger.trace(
                    f"decode_hdlc_address -> lower={hex(lower_address)} "
                    f"upper={hex(upper_address)} len={index + 1}",
                    **HdlcAddress._mod)
                return res

        logger.error("decode_hdlc_address: incomplete address", **HdlcAddress._mod)
        raise ValueError("Incomplete HDLC address")

    @staticmethod
    def __validate_length(address_length: int):
        """
        Validates that the length is 1, 2, or 4 bytes.
        """
        if address_length not in HdlcAddress.VALID_LENGTHS:
            logger.error(
                f"__validate_length: invalid length {address_length}",
                **HdlcAddress._mod)
            raise ValueError(f"The address length must be one of {HdlcAddress.VALID_LENGTHS}")
        logger.trace(
            f"__validate_length: length={address_length} OK",
            **HdlcAddress._mod)

    @staticmethod
    def __split_lower_upper(full_address: int, address_length: int) -> tuple[int, int]:
        """
        Splits a full address into lower_address and upper_address based on the HDLC length.
        """
        if address_length == 1:
            lower, upper = full_address & 0xFF, 0
        elif address_length == 2:
            lower, upper = full_address & 0xFF, (full_address >> 8)
        elif address_length == 4:
            lower, upper = full_address & 0xFFFF, (full_address >> 16)
        else:
            logger.error(
                f"__split_lower_upper: unsupported length {address_length}",
                **HdlcAddress._mod)
            raise ValueError("Unsupported HDLC address length")

        logger.trace(
            f"__split_lower_upper full=0x{full_address:X} len={address_length} "
            f"-> lower=0x{lower:X} upper=0x{upper:X}",
            **HdlcAddress._mod)
        return lower, upper
