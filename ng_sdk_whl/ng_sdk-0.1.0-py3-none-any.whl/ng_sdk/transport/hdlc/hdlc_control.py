from enum import Enum, auto
from typing import Optional

import attr

from ng_sdk.constant.hdlc.constant import *


# Enum to represent the different HDLC frame types
class FrameType(Enum):
    I = auto()  # Information frame
    RR = auto()  # Receive Ready frame
    RNR = auto()  # Receive Not Ready frame
    SNRM = auto()  # Set Normal Response Mode frame
    DISC = auto()  # Disconnect frame
    UA = auto()  # Unnumbered Acknowledgment frame
    DM = auto()  # Disconnected Mode frame
    FRMR = auto()  # Frame Reject frame
    UI = auto()  # Unnumbered Information frame


@attr.s
class HDLCControl:
    # Type of the HDLC frame
    frame_type: FrameType = attr.ib()
    # Send sequence number (0-7)
    ns: Optional[int] = attr.ib(default=None)
    # Receive sequence number (0-7)
    nr: Optional[int] = attr.ib(default=None)
    # Poll/Final bit (0 or 1)
    pf: int = attr.ib(default=1)

    with_suffix: bool = attr.ib(default=True)

    # Validation for the `ns` field
    @ns.validator
    def validate_ns(self, attribute, value):
        if value is not None and not (0 <= value <= 7):
            raise ValueError("`ns` must be between 0 and 7.")

    # Validation for the `nr` field
    @nr.validator
    def validate_nr(self, attribute, value):
        if value is not None and not (0 <= value <= 7):
            raise ValueError("`nr` must be between 0 and 7.")

    # Validation for the `pf` field
    @pf.validator
    def validate_pf(self, attribute, value):
        if not (0 <= value <= 1):
            raise ValueError("`pf` must be 0 or 1.")

    def encode(self) -> bytes:
        """
        Encodes the HDLC control field into a single byte.
        """
        control = 0
        # Encoding logic for each frame type
        if self.frame_type == FrameType.I:
            # I-frame: ns (3 bits), pf (1 bit), nr (3 bits)
            control = ((self.ns & 0x07) << 1) | 0x00  # LSB = 0 for I-frame
            control |= (self.pf & 0x01) << 4
            control |= (self.nr & 0x07) << 5

        elif self.frame_type == FrameType.RR:
            # RR-frame: 0x01, pf (1 bit), nr (3 bits)
            control = 0x01 | (self.pf & 0x01) << 4 | (self.nr & 0x07) << 5

        elif self.frame_type == FrameType.RNR:
            # RNR-frame: 0x05, pf (1 bit), nr (3 bits)
            control = 0x05 | (self.pf & 0x01) << 4 | (self.nr & 0x07) << 5

        elif self.frame_type == FrameType.SNRM:
            # SNRM-frame: 0x83, pf (1 bit)
            control = FRAME_TYPE_SNRM | ((self.pf & 0x01) << 4)

        elif self.frame_type == FrameType.DISC:
            # DISC-frame: 0x43, pf (1 bit)
            control = FRAME_TYPE_DISC | ((self.pf & 0x01) << 4)

        elif self.frame_type == FrameType.UA:
            # UA-frame: 0x63, pf (1 bit)
            control = FRAME_TYPE_UA | ((self.pf & 0x01) << 4)

        elif self.frame_type == FrameType.DM:
            # DM-frame: 0x0F, pf (1 bit)
            control = FRAME_TYPE_DM | ((self.pf & 0x01) << 4)

        elif self.frame_type == FrameType.FRMR:
            # FRMR-frame: 0x87, pf (1 bit)
            control = FRAME_TYPE_FRMR | ((self.pf & 0x01) << 4)

        elif self.frame_type == FrameType.UI:
            # UI-frame: 0x03, pf (1 bit)
            control = FRAME_TYPE_UI | ((self.pf & 0x01) << 4)

        return bytes([control])

    @staticmethod
    def decode(control: int) -> 'HDLCControl':
        """
        Decodes a single byte into an HDLCControl object.
        """
        # Extract the Poll/Final bit
        pf = (control >> 4) & 0x01

        # Decoding logic for each frame type
        if (control & 0x01) == 0:  # I-frame
            ns = (control >> 1) & 0x07
            nr = (control >> 5) & 0x07
            return HDLCControl(FrameType.I, ns=ns, nr=nr, pf=pf)

        elif (control & 0x0F) == 0x01:
            nr = (control >> 5) & 0x07
            return HDLCControl(FrameType.RR, nr=nr, pf=pf)

        elif (control & 0x0F) == 0x05:
            nr = (control >> 5) & 0x07
            return HDLCControl(FrameType.RNR, nr=nr, pf=pf)

        elif (control & 0xEF) == FRAME_TYPE_SNRM:
            return HDLCControl(FrameType.SNRM, pf=pf)

        elif (control & 0xEF) == FRAME_TYPE_DISC:
            return HDLCControl(FrameType.DISC, pf=pf)

        elif (control & 0xEF) == FRAME_TYPE_UA:
            return HDLCControl(FrameType.UA, pf=pf)

        elif (control & 0xEF) == FRAME_TYPE_DM:
            return HDLCControl(FrameType.DM, pf=pf)

        elif (control & 0xEF) == FRAME_TYPE_FRMR:
            return HDLCControl(FrameType.FRMR, pf=pf)

        elif (control & 0xEF) == FRAME_TYPE_UI:
            return HDLCControl(FrameType.UI, pf=pf)

        # Raise an exception if the control field is unknown
        raise ValueError("Unknown HDLC control field: 0x{:02X}".format(control))
