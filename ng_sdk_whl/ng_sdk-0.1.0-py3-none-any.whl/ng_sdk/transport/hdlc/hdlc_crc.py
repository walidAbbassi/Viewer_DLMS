import binascii


class HDLCCrc:
    """
    Class to calculate the CRC for HDLC frames.
    """

    @staticmethod
    def reverse_bits(byte):
        return int('{:08b}'.format(byte)[::-1], 2)

    @staticmethod
    def crc16_ccitt(data: bytes, crc: int = 0xFFFF) -> int:
        reversed_data = bytes(HDLCCrc.reverse_bits(b) for b in data)
        crc_val = binascii.crc_hqx(reversed_data, crc)
        # Inverser les bits de chaque octet du CRC
        crc_bytes = crc_val.to_bytes(2, 'big')
        reversed_crc_bytes = bytes(HDLCCrc.reverse_bits(b) for b in crc_bytes)
        reversed_crc = int.from_bytes(reversed_crc_bytes, 'big')
        return reversed_crc ^ 0xFFFF