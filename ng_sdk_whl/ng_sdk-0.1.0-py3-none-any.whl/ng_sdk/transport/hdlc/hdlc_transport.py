from ng_sdk.constant.hdlc.constant import *
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.transport.abstract_transport import AbstractTransport
from ng_sdk.transport.hdlc.hdlc_address import HdlcAddress
from ng_sdk.transport.hdlc.hdlc_control import HDLCControl, FrameType
from ng_sdk.transport.hdlc.hdlc_crc import HDLCCrc

logger = get_logger()


class HDLCTransport(AbstractTransport):
    def __init__(self, dest_addr: int = 1, dest_len: int = 2, src_addr: int = 2, src_len: int = 1,
                 control: HDLCControl = None,
                 segmentation: int = 0):
        """
        Initialize the HDLCTransport class with default or provided parameters.
        """
        super().__init__()
        self._mod = {LoggingConstants.MODULES_NAME: "HDLCTransport"}  # module tag for logs
        self._dest_addr = dest_addr
        self._dest_len = dest_len
        self._src_addr = src_addr
        self._src_len = src_len
        self._control = control
        self._segmentation = segmentation
        logger.debug(f"{self}", **self._mod)

    # Properties for encapsulation of private attributes
    @property
    def dest_addr(self):
        """Get or set the destination address."""
        return self._dest_addr

    @dest_addr.setter
    def dest_addr(self, value):
        self._dest_addr = value

    @property
    def dest_len(self):
        """Get or set the destination address length."""
        return self._dest_len

    @dest_len.setter
    def dest_len(self, value):
        self._dest_len = value

    @property
    def src_addr(self):
        """Get or set the source address."""
        return self._src_addr

    @src_addr.setter
    def src_addr(self, value):
        self._src_addr = value

    @property
    def src_len(self):
        """Get or set the source address length."""
        return self._src_len

    @src_len.setter
    def src_len(self, value):
        self._src_len = value

    @property
    def control(self):
        """Get or set the control field."""
        return self._control

    @control.setter
    def control(self, value):
        self._control = value

    @property
    def segmentation(self):
        """Get or set the segmentation field."""
        return self._segmentation

    @segmentation.setter
    def segmentation(self, value):
        self._segmentation = value

    def __str__(self):
        """
        Return a string representation of the HDLCTransport object.
        """
        return f"HDLC : Destination Address= {self.dest_addr}, Destination Length ={self.dest_len} bytes, Source Address={self.src_addr}, Source Length={self.src_len} bytes"

    def __build_frame_format_field(self, frame_length: int) -> bytes:
        """
        Build the frame format field based on the frame length and segmentation.
        """
        value = (0b1010 << 12) | (self.segmentation << 11) | frame_length
        return value.to_bytes(FRAME_FORMAT_LENGTH, 'big')

    def __extract_segmentation(self, frame_format: int) -> int:
        # isolate bit 11, then shift it to LSB
        return (frame_format & SEG_MASK) >> 11

    def wrap(self, data: bytes, **kwargs) -> bytes:
        """
        Wrap the given data into an HDLC frame.
        """
        # Encode destination and source addresses
        dest = HdlcAddress.encode_hdlc_address(self.dest_addr, self.dest_len)
        src = HdlcAddress.encode_hdlc_address(self.src_addr, self.src_len)
        # Calculate the total frame length
        data = (bytes.fromhex(
            DATA_CLIENT_PREFIX) if self.control.frame_type == FrameType.I and self.control.with_suffix and data != b'' else b'') + data
        frame_length = self.__calculate_frame_length(dest, src, data)
        # Build the frame format field
        frame_format = self.__build_frame_format_field(frame_length)

        # Construct the header and calculate the Header Check Sequence (HCS)
        header = dest + src + self.control.encode()
        hcs = HDLCCrc.crc16_ccitt(frame_format + header).to_bytes(HCS_LENGTH, 'big')

        # Construct the full frame without the Frame Check Sequence (FCS)
        frame_no_fcs = frame_format + header + hcs + data
        if data != b'':
            # Calculate the Frame Check Sequence (FCS)
            fcs = HDLCCrc.crc16_ccitt(frame_no_fcs).to_bytes(FCS_LENGTH, 'big')
        else:
            fcs = b''

        # Return the complete HDLC frame with flags
        return bytes([HDLC_FLAG]) + frame_no_fcs + fcs + bytes([HDLC_FLAG])

    @staticmethod
    def __calculate_frame_length(dest: bytes, src: bytes, data: bytes) -> int:
        """
        Calculate the total frame length based on its components.
        """
        return FRAME_FORMAT_LENGTH + len(dest) + len(src) + CONTROL_LENGTH + HCS_LENGTH + len(data) + (
            FCS_LENGTH if len(data) > 0 else 0)

    def unwrap(self, data: bytes, **kwargs) -> bytes:
        """
        Unwrap the given HDLC frame and extract the information field.
        """
        # Validate the presence of HDLC flags
        if data[0] != HDLC_FLAG or data[-1] != HDLC_FLAG:
            raise ValueError("Invalid HDLC frame: missing flags")
        data = data[1:-1]  # Remove the flags

        # Extract and validate the frame format field
        frame_format = data[:FRAME_FORMAT_LENGTH]
        frame_length = self.__extract_frame_length(frame_format)
        self.segmentation = self.__extract_segmentation(int.from_bytes(frame_format, "big"))
        if len(data) != frame_length:
            raise ValueError("Incorrect frame length")

        # Decode destination and source addresses
        current_index = FRAME_FORMAT_LENGTH
        dest_addr, dest_length = HdlcAddress.decode_hdlc_address(data[current_index:])
        current_index += dest_length
        src_addr, src_length = HdlcAddress.decode_hdlc_address(data[current_index:])
        current_index += src_length

        # Extract and validate the control field
        self.control = HDLCControl.decode(data[current_index])
        current_index += CONTROL_LENGTH

        # Validate the Header Check Sequence (HCS)
        hcs = int.from_bytes(data[current_index:current_index + HCS_LENGTH], 'big')
        current_index += HCS_LENGTH
        if not self.__validate_crc(data[:current_index][:-HCS_LENGTH], hcs):
            raise ValueError("Invalid HCS")
        if data[current_index:-FCS_LENGTH].startswith(bytes.fromhex(DATA_SERVER_PREFIX)):
            current_index += len(DATA_SERVER_PREFIX) // 2
        # Extract the information field and validate the Frame Check Sequence (FCS)
        info = data[current_index:-FCS_LENGTH]
        fcs = int.from_bytes(data[-FCS_LENGTH:], 'big')
        if not self.__validate_crc(data[:-FCS_LENGTH], fcs):
            raise ValueError("Invalid FCS")

        return bytes(info)

    @staticmethod
    def hdlc_complete(frame: bytes) -> bool:

        if len(frame) < 3:
            return False
        frame_length = HDLCTransport.__extract_frame_length(frame[1:])
        return len(frame) - 2 >= frame_length

    @staticmethod
    def __extract_frame_length(frame_format: bytes) -> int:

        """
        Extract the frame length from the frame format field.
        """
        return (((frame_format[0] & 0x0F) << 8) | frame_format[1]) & 0x07FF

    @staticmethod
    def __validate_crc(data: bytes, expected_crc: int) -> bool:
        """
        Validate the CRC for the given data.
        """
        return HDLCCrc.crc16_ccitt(data) == expected_crc
