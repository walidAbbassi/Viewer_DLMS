from dataclasses import dataclass
from typing import Optional

from ng_sdk.constant.hdlc.constant import FORMAT_IDENTIFIER, GROUP_IDENTIFIER, \
    MAXIMUM_INFORMATION_FIELD_LENGTH_IDENTIFIER_TRANSMIT, MAXIMUM_INFORMATION_FIELD_LENGTH_IDENTIFIER_RECEIVE, \
    WINDOW_SIZE_IDENTIFIER_TRANSMIT, WINDOW_SIZE_IDENTIFIER_RECEIVE


@dataclass
class SnrmData:

    maximum_information_field_length_length_transmit: Optional[int]
    maximum_information_field_length_value_transmit: Optional[int]


    maximum_information_field_length_length_receive: Optional[int]
    maximum_information_field_length_value_receive: Optional[int]


    window_size_length_transmit: Optional[int]
    window_size_value_transmit: Optional[int]


    window_size_length_receive: Optional[int]
    window_size_value_receive: Optional[int]

    def to_bytes(self) -> bytes:
        data = bytearray()
        data.append(FORMAT_IDENTIFIER)
        data.append(GROUP_IDENTIFIER)
        length = self.maximum_information_field_length_length_transmit + self.maximum_information_field_length_length_receive + self.window_size_length_transmit + self.window_size_length_receive + 4 * 2
        data.append(length)

        data.append(MAXIMUM_INFORMATION_FIELD_LENGTH_IDENTIFIER_TRANSMIT)
        data.append(self.maximum_information_field_length_length_transmit)
        data.extend(self.maximum_information_field_length_value_transmit.to_bytes(
            self.maximum_information_field_length_length_transmit))

        data.append(MAXIMUM_INFORMATION_FIELD_LENGTH_IDENTIFIER_RECEIVE)
        data.append(self.maximum_information_field_length_length_receive)
        data.extend(self.maximum_information_field_length_value_receive.to_bytes(
            self.maximum_information_field_length_length_receive))

        data.append(WINDOW_SIZE_IDENTIFIER_TRANSMIT)
        data.append(self.window_size_length_transmit)
        data.extend(self.window_size_value_transmit.to_bytes(
            self.window_size_length_transmit))

        data.append(WINDOW_SIZE_IDENTIFIER_RECEIVE)
        data.append(self.window_size_length_receive)
        data.extend(self.window_size_value_receive.to_bytes(
            self.window_size_length_receive))


        return data

    @staticmethod
    def from_bytes(data: bytes) -> "SnrmData":

        format_identifier:int = data[0]
        if not format_identifier == FORMAT_IDENTIFIER:
            raise ValueError("Invalid format_identifier")

        group_identifier:int = data[1]
        if not group_identifier == GROUP_IDENTIFIER:
            raise ValueError("Invalid group_identifier")

        group_length:int = data[2]
        data = data[3:]
        if len(data) > group_length:
            data = data[:group_length]
        elif len(data) < group_length:
            raise ValueError("invalid group length")
        maximum_information_field_length_length_transmit = None
        maximum_information_field_length_value_transmit = None
        maximum_information_field_length_length_receive = None
        maximum_information_field_length_value_receive = None
        window_size_length_transmit = None
        window_size_value_transmit = None
        window_size_length_receive = None
        window_size_value_receive = None
        while len(data) > 0:
            identifier:int = data[0]
            length = data[1]
            value = int.from_bytes(data[2:2+length])
            data = data[2+length:]
            if identifier == MAXIMUM_INFORMATION_FIELD_LENGTH_IDENTIFIER_TRANSMIT:
                maximum_information_field_length_length_transmit = length
                maximum_information_field_length_value_transmit = value
            elif identifier == MAXIMUM_INFORMATION_FIELD_LENGTH_IDENTIFIER_RECEIVE:
                maximum_information_field_length_length_receive = length
                maximum_information_field_length_value_receive = value
            elif identifier == WINDOW_SIZE_IDENTIFIER_TRANSMIT:
                window_size_length_transmit = length
                window_size_value_transmit = value
            elif identifier == WINDOW_SIZE_IDENTIFIER_RECEIVE:
                window_size_length_receive = length
                window_size_value_receive = value

        return SnrmData(
                        maximum_information_field_length_length_transmit = maximum_information_field_length_length_transmit,
                        maximum_information_field_length_value_transmit=maximum_information_field_length_value_transmit,
                        maximum_information_field_length_length_receive = maximum_information_field_length_length_receive,
                        maximum_information_field_length_value_receive=maximum_information_field_length_value_receive,
                        window_size_length_transmit=window_size_length_transmit,
                        window_size_value_transmit=window_size_value_transmit,
                        window_size_length_receive=window_size_length_receive,
                        window_size_value_receive=window_size_value_receive
                        )

