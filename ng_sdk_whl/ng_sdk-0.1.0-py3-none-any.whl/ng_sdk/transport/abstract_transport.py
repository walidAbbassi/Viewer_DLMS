from abc import ABC, abstractmethod


class AbstractTransport(ABC):

    def __init__(self):
        self.source_port: int | None = None
        self.dest_port: int | None = None

    @abstractmethod
    def wrap(self, data: bytes, **kwargs) -> bytes:
        pass

    @abstractmethod
    def unwrap(self, data: bytes, **kwargs) -> bytes:
        pass
