from typing import Any

from attrs import define, field
from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest


@define
class ApplicationResponse:

    request: AbstractFrameRequest = field(default=None)
    value: Any = field(default=None)
    error: str = field(default=None)
    status_code: int = field(default=None)
