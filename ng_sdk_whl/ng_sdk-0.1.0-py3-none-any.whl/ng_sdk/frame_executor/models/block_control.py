


class BlockControl:
    def __init__(self,bc: int):
        self.window = 0
        self.streaming = False
        self.last_block = False

        if not 0 <= bc <= 0xFF:
            raise ValueError("Input must be a single unsigned byte (0–255).")

        # Bits 0–5 (mask 0b00111111 or 0x3F)
        self.window = bc & 0x3F

        # Bit 6 (shift right then mask)
        self.streaming = (bc >> 6) & 0x01 == 1

        # Bit 7
        self.last_block = (bc >> 7) & 0x01 == 1

    def to_bytes(self)->bytes:
        if not (0 <= self.window <= 0x3F):  # 6 bits only
            raise ValueError("window_advertise must be in range 0–63")

        b = self.window  # put bits 0–5

        if self.streaming:
            b |= (1 << 6)  # set bit 6

        if self.last_block:
            b |= (1 << 7)  # set bit 7

        return b.to_bytes(1, "big")
