from typing import Optional

from ng_sdk.frame_builder.dlms.xdlms.data_type.octet_string import OctetStringData
from ng_sdk.frame_executor.models.block_control import BlockControl


class GeneralBlockTransfer:
    TAG = 0xE0
    block_control : BlockControl
    block_number: int
    block_number_ack: int
    block_data: Optional[OctetStringData]
    def __init__(self, block_control: BlockControl,block_number: int,block_number_ack: int,block_data: Optional[OctetStringData]) -> None:
        self.block_control = block_control
        self.block_number = block_number
        self.block_number_ack = block_number_ack
        self.block_data = block_data

    @classmethod
    def from_bytes(cls, frame:bytes):
        if len(frame) < 5 or frame[0] != cls.TAG:
            raise ValueError("Input error")
        frame = frame[1:]
        block_control = BlockControl(frame[0])
        block_number = int.from_bytes(frame[1:3], byteorder="big")
        block_number_ack = int.from_bytes(frame[3:5], byteorder="big")
        if len(frame) > 5 :
            block_data = OctetStringData.from_bytes(frame[5:])
        else :
            block_data = None
        return GeneralBlockTransfer(block_control,block_number,block_number_ack,block_data)
    def to_bytes(self) -> bytes:
        frame = bytearray()
        frame.append(self.TAG)
        frame.extend(self.block_control.to_bytes())
        frame.extend(self.block_number.to_bytes(2, byteorder="big"))
        frame.extend(self.block_number_ack.to_bytes(2, byteorder="big"))
        if self.block_data:
            frame.extend(self.block_data.to_bytes()[1:])
        else:
            frame.extend([0])
        return frame

