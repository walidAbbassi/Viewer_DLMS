import threading
from typing import List, Optional, Callable

from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.configuration.config_manager import ConfigModuleProxy
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.constant.logger.constant import LoggingConstants
from ng_sdk.error.frame_executor_exception import FrameExecutorError, FrameExecutorException
from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.dlms_enums import DataAccessResult
from ng_sdk.frame_builder.dlms.dlms_frame_builder import DLMSFrameBuilder
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_next_pblock import DLMSActionRequestNextPblock
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_with_list import DLMSActionRequestWithList
from ng_sdk.frame_builder.dlms.xdlms.action.response.dlms_action_response_normal import DLMSActionResponseNormal
from ng_sdk.frame_builder.dlms.xdlms.action.response.dlms_action_response_with_list import DLMSActionResponseWithList
from ng_sdk.frame_builder.dlms.xdlms.action.response.dlms_action_response_with_pblock import \
    DLMSActionResponseWithPblock
from ng_sdk.frame_builder.dlms.xdlms.get.request.dlms_get_request_next import DLMSGetRequestNext
from ng_sdk.frame_builder.dlms.xdlms.get.request.dlms_get_request_normal import DLMSGetRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.get.request.dlms_get_request_with_list import DLMSGetRequestWithList
from ng_sdk.frame_builder.dlms.xdlms.get.response.dlms_get_response_normal import DLMSGetResponseNormal
from ng_sdk.frame_builder.dlms.xdlms.get.response.dlms_get_response_with_datablock import DLMSGetResponseWithDatablock
from ng_sdk.frame_builder.dlms.xdlms.get.response.dlms_get_response_with_list import DLMSGetResponseWithList
from ng_sdk.frame_builder.dlms.xdlms.set.response.dlms_set_response_normal import DLMSSetResponseNormal
from ng_sdk.frame_builder.dlms.xdlms.set.response.dlms_set_response_with_list import DLMSSetResponseWithList
from ng_sdk.frame_builder.meter_request import MeterRequest
from ng_sdk.frame_builder.meter_response import MeterResponse
from ng_sdk.frame_executor.abstract_frame_executor import AbstractFrameExecutor
from ng_sdk.frame_executor.models.application_response import ApplicationResponse
from ng_sdk.logger.logger import get_logger

logger = get_logger()


class DLMSExecutor(AbstractFrameExecutor):
    _mod = {LoggingConstants.MODULES_NAME: "DLMSExecutor"}

    def __init__(self, communication: AbstractCommunication, builder: DLMSFrameBuilder,
                 configuration: ConfigModuleProxy):
        logger.trace("DLMSExecutor.__init__", **self._mod)
        super().__init__(communication, builder, configuration)

        keep_connection = getattr(getattr(configuration, "communication", None), "keep_connection", None)
        self.keepalive_interval = getattr(keep_connection, "timeout", 0) or 0

        self._keepalive_lock = threading.Lock()
        self._keepalive_timer: Optional[threading.Timer] = None
        self._active_calls = 0
        self._closed = False
        self._keepalive_running = False

    def execute(self, frame_request: AbstractFrameRequest, 
                progress_callback: Optional[Callable[[int, int, bool], None]] = None,cancel_event: Optional[threading.Event] = None) -> AbstractFrameResponse:
        """
        Execute a frame request.
        
        Args:
            frame_request: The frame request to execute
            progress_callback: Optional callback function called during data block transfers.
                              Signature: callback(received_bytes: int, block_number: int, is_last_block: bool)
        
        Returns:
            The frame response
        """
        logger.info(f"Plain: {frame_request.to_bytes().hex().upper()}", **self._mod)
        meter_requests = self.builder.build([frame_request], False)
        logger.trace(f"execute: built {len(meter_requests)} meter request(s)", **self._mod)
        return self._execute_meter_request(meter_requests[0], progress_callback=progress_callback,cancel_event=cancel_event)

    def execute_list(self, frame_requests: List[AbstractFrameRequest],
                     progress_callback: Optional[Callable[[int, int, bool], None]] = None,cancel_event: Optional[threading.Event] = None) -> AbstractFrameResponse:
        """
        Execute a list of frame requests.
        
        Args:
            frame_requests: List of frame requests to execute
            progress_callback: Optional callback function called during data block transfers.
                              Signature: callback(received_bytes: int, block_number: int, is_last_block: bool)
        
        Returns:
            The frame response
        """
        logger.debug(f"execute_list: count={len(frame_requests)}", **self._mod)
        meter_requests = self.builder.build(frame_requests, True)
        logger.debug(f"execute_list: built {len(meter_requests)} meter request batch(es)", **self._mod)
        if len(meter_requests) > 1:
            logger.error("execute_list: unique-type batch expected", **self._mod)
            raise FrameExecutorException(FrameExecutorError.LIST_EXECUTION_UNIQUE_TYPE_ERROR)
        return self._execute_meter_request(meter_requests[0], progress_callback=progress_callback,cancel_event=cancel_event)

    def advanced_execute_list(self, frame_requests: List[AbstractFrameRequest],
                              progress_callback: Optional[Callable[[int, int, bool], None]] = None,cancel_event: Optional[threading.Event] = None) -> List[ApplicationResponse]:
        """
        Execute a list of frame requests and return detailed application responses.
        
        Args:
            frame_requests: List of frame requests to execute
            progress_callback: Optional callback function called during data block transfers.
                              Signature: callback(received_bytes: int, block_number: int, is_last_block: bool)
        
        Returns:
            List of application responses
        """
        logger.debug(f"advanced_execute_list: count={len(frame_requests)}", **self._mod)
        response = self.execute_list(frame_requests, progress_callback=progress_callback,cancel_event=cancel_event)
        application_responses = []
        if response is None:
            logger.error("advanced_execute_list: null response", **self._mod)
            raise FrameExecutorException(FrameExecutorError.NULL_RESPONSE_ERROR)

        if isinstance(response, DLMSActionResponseWithList):
            logger.debug("advanced_execute_list: DLMSActionResponseWithList", **self._mod)
            if len(frame_requests) == len(response.list_of_responses):
                for i in range(0, len(frame_requests)):
                    data = None
                    res_i = response.list_of_responses[i]
                    error = None if res_i.return_parameter.data_access_result == DataAccessResult.SUCCESS else \
                        res_i.return_parameter.data_access_result.name
                    if res_i.return_parameter is not None and res_i.return_parameter.data is not None:
                        data = res_i.return_parameter.data.to_python()
                    application_responses.append(
                        ApplicationResponse(frame_requests[i], data, error,
                                            res_i.return_parameter.data_access_result.value)
                    )
                return application_responses
            logger.error("advanced_execute_list: requests/responses length mismatch", **self._mod)
            raise FrameExecutorException(FrameExecutorError.REQUESTS_RESPONSES_LENGTH_ERROR)

        elif isinstance(response, DLMSGetResponseWithList):
            logger.debug("advanced_execute_list: DLMSGetResponseWithList", **self._mod)
            if len(frame_requests) == len(response.result):
                for i in range(0, len(frame_requests)):
                    data = None
                    res_i = response.result[i]
                    error = None if res_i.data_access_result == DataAccessResult.SUCCESS else \
                        res_i.data_access_result.name
                    if error is None and res_i.data is not None:
                        data = res_i.data.to_python()
                    application_responses.append(
                        ApplicationResponse(frame_requests[i], data, error, res_i.data_access_result.value)
                    )
                return application_responses
            logger.error("advanced_execute_list: requests/responses length mismatch", **self._mod)
            raise FrameExecutorException(FrameExecutorError.REQUESTS_RESPONSES_LENGTH_ERROR)

        elif isinstance(response, DLMSSetResponseWithList):
            logger.debug("advanced_execute_list: DLMSSetResponseWithList", **self._mod)
            if len(frame_requests) == len(response.result):
                for i in range(0, len(frame_requests)):
                    res_i = response.result[i]
                    error = None if res_i == DataAccessResult.SUCCESS else res_i.name
                    application_responses.append(
                        ApplicationResponse(frame_requests[i], None, error, res_i.value)
                    )
                return application_responses
            logger.error("advanced_execute_list: requests/responses length mismatch", **self._mod)
            raise FrameExecutorException(FrameExecutorError.REQUESTS_RESPONSES_LENGTH_ERROR)

        logger.error(f"advanced_execute_list: unsupported response type {type(response).__name__}", **self._mod)
        raise FrameExecutorException(FrameExecutorError.RESPONSE_TYPE_ERROR)

    def advanced_execute(self, frame_request: AbstractFrameRequest,
                         progress_callback: Optional[Callable[[int, int, bool], None]] = None,cancel_event: Optional[threading.Event] = None) -> ApplicationResponse:
        """
        Execute a frame request and return a detailed application response.
        
        Args:
            frame_request: The frame request to execute
            progress_callback: Optional callback function called during data block transfers.
                              Signature: callback(received_bytes: int, block_number: int, is_last_block: bool)
        
        Returns:
            Application response with detailed information
        """
        logger.debug(f"advanced_execute: {frame_request}", **self._mod)
        response = self.execute(frame_request, progress_callback=progress_callback,cancel_event=cancel_event)
        if response is None:
            logger.error("advanced_execute: null response", **self._mod)
            raise FrameExecutorException(FrameExecutorError.NULL_RESPONSE_ERROR)

        if isinstance(response, DLMSActionResponseNormal):
            logger.debug("advanced_execute: DLMSActionResponseNormal", **self._mod)
            data = None
            error = None if response.return_parameter.data_access_result == DataAccessResult.SUCCESS else \
                response.return_parameter.data_access_result.name
            if response.return_parameter is not None and response.return_parameter.data is not None:
                data = response.return_parameter.data.to_python()
            return ApplicationResponse(frame_request, data, error, response.return_parameter.data_access_result.value)

        elif isinstance(response, DLMSGetResponseNormal):
            logger.debug("advanced_execute: DLMSGetResponseNormal", **self._mod)
            data = None
            error = None if response.data_access_result == DataAccessResult.SUCCESS else response.data_access_result.name
            if error is None and response.data is not None:
                data = response.data.to_python()
            return ApplicationResponse(frame_request, data, error, response.data_access_result.value)

        elif isinstance(response, DLMSSetResponseNormal):
            logger.debug("advanced_execute: DLMSSetResponseNormal", **self._mod)
            error = None if response.data_access_result == DataAccessResult.SUCCESS else response.data_access_result.name
            return ApplicationResponse(frame_request, None, error, response.data_access_result.value)

        logger.error(f"advanced_execute: unsupported response type {type(response).__name__}", **self._mod)
        raise FrameExecutorException(FrameExecutorError.RESPONSE_TYPE_ERROR)

    def start_keepalive(self):
        """Start the keep-alive mechanism. Should be called after connection is established."""
        with self._keepalive_lock:
            if not self._closed:
                self._schedule_keepalive_locked()
                logger.debug("Keep-alive started", **self._mod)

    def stop_keepalive(self):
        """Stop the keep-alive mechanism."""
        with self._keepalive_lock:
            self._cancel_keepalive_locked()
            logger.debug("Keep-alive stopped", **self._mod)

    def close_keepalive(self):
        """Close and cleanup keep-alive resources. Should be called when executor is being closed."""
        with self._keepalive_lock:
            self._closed = True
            self._cancel_keepalive_locked()
            logger.debug("Keep-alive closed", **self._mod)

    def _on_activity_start(self):
        """Called when a real request starts - cancel keepalive if it's the first active call."""
        with self._keepalive_lock:
            self._active_calls += 1
            if self._active_calls == 1:
                self._cancel_keepalive_locked()
                logger.trace("Activity started - keepalive cancelled", **self._mod)

    def _on_activity_end(self):
        """Called when a real request ends - reschedule keepalive if no more active calls."""
        with self._keepalive_lock:
            self._active_calls -= 1
            if self._active_calls == 0 and not self._closed:
                self._schedule_keepalive_locked()
                logger.trace("Activity ended - keepalive rescheduled", **self._mod)

    def _schedule_keepalive_locked(self):
        """Schedule the next keepalive timer (must be called with lock held)."""
        self._cancel_keepalive_locked()
        self._keepalive_timer = threading.Timer(self.keepalive_interval, self._keepalive_fire)
        self._keepalive_timer.daemon = True
        self._keepalive_timer.start()
        logger.trace(f"Keepalive scheduled in {self.keepalive_interval}s", **self._mod)

    def _cancel_keepalive_locked(self):
        """Cancel the current keepalive timer (must be called with lock held)."""
        if self._keepalive_timer is not None:
            self._keepalive_timer.cancel()
            self._keepalive_timer = None
            logger.trace("Keepalive timer cancelled", **self._mod)

    def _keepalive_fire(self):
        """Called when keepalive timer fires. Sends keepalive request if still idle."""
        with self._keepalive_lock:
            if self._active_calls == 0 and not self._closed:
                # Mark that keepalive is running to prevent concurrent execution
                self._keepalive_running = True
            else:
                # Activity started or closed, don't send keepalive
                return

        # Perform keepalive outside of the lock to avoid blocking other calls
        try:
            self._send_keepalive()
        except Exception as e:
            logger.warning(f"Keepalive request failed: {e}", **self._mod)
        finally:
            with self._keepalive_lock:
                self._keepalive_running = False
                # Still idle? reschedule next keepalive
                if self._active_calls == 0 and not self._closed:
                    self._schedule_keepalive_locked()

    def _send_keepalive(self):
        """Send a keepalive request to prevent meter disconnection."""
        logger.debug("Sending keepalive request", **self._mod)
        try:
            # Use a lightweight GET request to clock (class 8, OBIS 0.0.1.0.0.255, attribute 2)
            # This is a common, lightweight operation that keeps the connection alive
            keepalive_request = DLMSGetRequestNormal(self.configuration.communication.keep_connection.class_id, self.configuration.communication.keep_connection.obis_code, self.configuration.communication.keep_connection.attribute_id)
            meter_requests = self.builder.build([keepalive_request], False)
            if meter_requests:
                # Execute without triggering activity tracking (to avoid recursion)
                # We'll call _execute_meter_request_internal directly
                self._execute_meter_request_internal(meter_requests[0], is_keepalive=True)
                logger.trace("Keepalive request completed", **self._mod)
        except Exception as e:
            logger.warning(f"Keepalive request error: {e}", **self._mod)
            raise

    def _execute_meter_request(self, meter_request: MeterRequest,
                               progress_callback: Optional[
                                   Callable[[int, int, bool], None]] = None,cancel_event: Optional[threading.Event] = None) -> AbstractFrameResponse:
        """Execute a meter request with keepalive management."""
        # Track activity for keepalive management
        if self.configuration.communication.keep_connection.enabled:
            self._on_activity_start()
        try:
            return self._execute_meter_request_internal(meter_request, is_keepalive=False,
                                                        progress_callback=progress_callback,cancel_event=cancel_event)
        finally:
            if self.configuration.communication.keep_connection.enabled:
                self._on_activity_end()

    def _execute_meter_request_internal(self, meter_request: MeterRequest, is_keepalive: bool = False,
                                        progress_callback: Optional[Callable[[int, int, bool], None]] = None,cancel_event: Optional[threading.Event] = None) -> AbstractFrameResponse:
        """Internal method to execute meter request without keepalive tracking."""
        logger.trace(
            f"_execute_meter_request: frames={len(meter_request.frames)} "
            f"type={type(meter_request.request).__name__} "
            f"is_keepalive={is_keepalive}",
            **self._mod)
        
        # Check if keepalive is running and abort it if a real request comes in
        # (but not if this IS the keepalive request itself)
        if not is_keepalive:
            with self._keepalive_lock:
                if self._keepalive_running:
                    logger.debug("Real request detected during keepalive - aborting keepalive", **self._mod)
                    self._cancel_keepalive_locked()
                    self._keepalive_running = False
                    # Reschedule keepalive after this request completes
                    # (will be done in _on_activity_end)
        
        response = None
        for idx, frame in enumerate(meter_request.frames):

            if cancel_event and cancel_event.is_set():
                raise FrameExecutorException(FrameExecutorError.CANCELLED_EXECUTION)

            logger.trace(f"TX[{idx}] -> {frame.hex().upper()}", **self._mod)
            # Log get/set/action request
            if hasattr(meter_request.request, '__class__'):
                req_name = type(meter_request.request).__name__
                if 'Get' in req_name:
                    logger.info("Get Request: " + frame.hex().upper(), **self._mod)
                elif 'Set' in req_name:
                    logger.info("Set Request: " + frame.hex().upper(), **self._mod)
                elif 'Action' in req_name:
                    logger.info("Action Request: " + frame.hex().upper(), **self._mod)
            frame_response = self.communication.transceive(frame)
            logger.trace(f"RX[{idx}] <- {frame_response.hex().upper()}", **self._mod)
            # Log get/set/action response
            if hasattr(meter_request.request, '__class__'):
                req_name = type(meter_request.request).__name__
                if 'Get' in req_name:
                    logger.info("Get Response: " + frame_response.hex().upper(), **self._mod)
                elif 'Set' in req_name:
                    logger.info("Set Response: " + frame_response.hex().upper(), **self._mod)
                elif 'Action' in req_name:
                    logger.info("Action Response: " + frame_response.hex().upper(), **self._mod)

            response = self.builder.parse(MeterResponse(frame_response))
            logger.trace(f"Parsed[{idx}] -> {type(response).__name__}", **self._mod)

            if isinstance(response, DLMSGetResponseWithDatablock):
                logger.debug("Handling DLMSGetResponseWithDatablock", **self._mod)
                if isinstance(meter_request.request, DLMSGetRequestWithList):
                    payload = bytearray([Constant.INVOKED_ID])
                else:
                    payload = bytearray([Constant.INVOKED_ID, DataAccessResult.SUCCESS])

                if response.is_success():
                    payload.extend(response.result.raw_data)
                last_block = response.result.last_block
                block_number = response.result.block_number
                
                # Call progress callback for first block
                if progress_callback is not None:
                    try:
                        progress_callback(len(payload), block_number, last_block)
                    except Exception as e:
                        logger.warning(f"Progress callback error: {e}", **self._mod)
                
                logger.debug(
                    f"DataBlock start: last={last_block} block={block_number}",
                    **self._mod)
                while not last_block:
                    if cancel_event and cancel_event.is_set():
                        raise FrameExecutorException(FrameExecutorError.CANCELLED_EXECUTION)
                    nxt = DLMSGetRequestNext(block_number).to_bytes(self.builder.security_context)
                    logger.debug(f"TX (GetNext block={block_number}) -> {nxt.hex().upper()}",
                                 **self._mod)
                    frame_response = self.communication.transceive(nxt)
                    logger.debug(f"RX (GetNext) <- {frame_response.hex().upper()}",
                                 **self._mod)
                    parsed_response = self.builder.parse(MeterResponse(frame_response))
                    if isinstance(parsed_response, DLMSGetResponseWithDatablock):
                        payload.extend(parsed_response.result.raw_data)
                        last_block = parsed_response.result.last_block
                        block_number = parsed_response.result.block_number
                        
                        # Call progress callback for each subsequent block
                        if progress_callback is not None:
                            try:
                                progress_callback(len(payload), block_number, last_block)
                            except Exception as e:
                                logger.warning(f"Progress callback error: {e}", **self._mod)
                        
                        logger.debug(
                            f"DataBlock cont: last={last_block} block={block_number}",
                            **self._mod)
                    else:
                        logger.warning("Unexpected response while fetching next block", **self._mod)
                        last_block = False

                if isinstance(meter_request.request, DLMSGetRequestWithList):
                    response = DLMSGetResponseWithList(payload)
                else:
                    response = DLMSGetResponseNormal(payload)
                logger.debug(f"Rebuilt response payload -> {payload.hex().upper()}", **self._mod)

            elif isinstance(response, DLMSActionResponseWithPblock):
                logger.debug("Handling DLMSActionResponseWithPblock", **self._mod)
                last_block = response.pblock.last_block
                block_number = response.pblock.block_number
                payload = bytearray([Constant.INVOKED_ID])
                if response.is_success():
                    payload.extend(response.pblock.raw_data)
                
                # Call progress callback for first pblock
                if progress_callback is not None:
                    try:
                        progress_callback(len(payload), block_number, last_block)
                    except Exception as e:
                        logger.warning(f"Progress callback error: {e}", **self._mod)
                
                logger.debug(
                    f"PBlock start: last={last_block} block={block_number}",
                    **self._mod)
                while not last_block:
                    if cancel_event and cancel_event.is_set():
                        raise FrameExecutorException(FrameExecutorError.CANCELLED_EXECUTION)
                    nxt = DLMSActionRequestNextPblock(block_number).to_bytes(self.builder.security_context)
                    logger.debug(f"TX (ActionNext block={block_number}) -> {nxt.hex().upper()}",
                                 **self._mod)
                    frame_response = self.communication.transceive(nxt)
                    logger.debug(f"RX (ActionNext) <- {frame_response.hex().upper()}",
                                 **self._mod)
                    parsed_response = self.builder.parse(MeterResponse(frame_response))
                    if isinstance(parsed_response, DLMSActionResponseWithPblock):
                        payload.extend(parsed_response.pblock.raw_data)
                        last_block = parsed_response.pblock.last_block
                        block_number = parsed_response.pblock.block_number
                        
                        # Call progress callback for each subsequent pblock
                        if progress_callback is not None:
                            try:
                                progress_callback(len(payload), block_number, last_block)
                            except Exception as e:
                                logger.warning(f"Progress callback error: {e}", **self._mod)
                        
                        logger.debug(
                            f"PBlock cont: last={last_block} block={block_number}",
                            **self._mod)
                    else:
                        logger.warning("Unexpected response while fetching next pblock", **self._mod)
                        last_block = False

                if isinstance(meter_request.request, DLMSActionRequestWithList):
                    response = DLMSActionResponseWithList(payload)
                else:
                    response = DLMSActionResponseNormal(payload)
                logger.debug(f"Rebuilt action response -> {type(response).__name__}", **self._mod)

        logger.trace(f"_execute_meter_request: done -> {type(response).__name__ if response else None}",
                     **self._mod)
        return response
