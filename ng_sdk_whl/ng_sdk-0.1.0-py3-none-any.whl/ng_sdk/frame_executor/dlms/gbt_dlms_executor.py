from time import sleep
from typing import Optional, Callable

from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.dlms_enums import DataAccessResult
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_next_pblock import DLMSActionRequestNextPblock
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_with_list import DLMSActionRequestWithList
from ng_sdk.frame_builder.dlms.xdlms.action.response.dlms_action_response_normal import DLMSActionResponseNormal
from ng_sdk.frame_builder.dlms.xdlms.action.response.dlms_action_response_with_list import DLMSActionResponseWithList
from ng_sdk.frame_builder.dlms.xdlms.action.response.dlms_action_response_with_pblock import \
    DLMSActionResponseWithPblock
from ng_sdk.frame_builder.dlms.xdlms.data_type.octet_string import OctetStringData
from ng_sdk.frame_builder.dlms.xdlms.get.request.dlms_get_request_next import DLMSGetRequestNext
from ng_sdk.frame_builder.dlms.xdlms.get.request.dlms_get_request_with_list import DLMSGetRequestWithList
from ng_sdk.frame_builder.dlms.xdlms.get.response.dlms_get_response_normal import DLMSGetResponseNormal
from ng_sdk.frame_builder.dlms.xdlms.get.response.dlms_get_response_with_datablock import DLMSGetResponseWithDatablock
from ng_sdk.frame_builder.dlms.xdlms.get.response.dlms_get_response_with_list import DLMSGetResponseWithList
from ng_sdk.frame_builder.meter_request import MeterRequest
from ng_sdk.frame_builder.meter_response import MeterResponse
from ng_sdk.frame_executor.dlms.dlms_executor import DLMSExecutor
from ng_sdk.frame_executor.models.block_control import BlockControl
from ng_sdk.frame_executor.models.general_block_transfer import GeneralBlockTransfer
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.util.bytes_util import extract_length

logger = get_logger()


class GBTDLMSExecutor(DLMSExecutor):
    _mod = {LoggingConstants.MODULES_NAME: "GBTDLMSExecutor"}

    def _execute_meter_request_internal(self, meter_request: MeterRequest, is_keepalive: bool = False,
                                    progress_callback: Optional[Callable[[int, int, bool], None]] = None) -> AbstractFrameResponse:
        """Internal GBT-specific execution method."""
        # Check if keepalive is running and abort it if a real request comes in
        with self._keepalive_lock:
            if self._keepalive_running:
                logger.debug("Real request detected during keepalive - aborting keepalive", **self._mod)
                self._cancel_keepalive_locked()
                self._keepalive_running = False
                # Reschedule keepalive after this request completes
                # (will be done in _on_activity_end)
        
        response = None
        for frame in meter_request.frames:
            frame_response = self.__gbt_transceive(frame)
            response = self.builder.parse(MeterResponse(frame_response))
            if isinstance(response, DLMSGetResponseWithDatablock):
                if isinstance(meter_request.request, DLMSGetRequestWithList):
                    payload = bytearray([Constant.INVOKED_ID])
                else:
                    payload = bytearray([Constant.INVOKED_ID, DataAccessResult.SUCCESS])

                if response.is_success():
                    payload.extend(response.result.raw_data)
                last_block = response.result.last_block
                block_number = response.result.block_number
                
                # Call progress callback for first block
                if progress_callback is not None:
                    try:
                        progress_callback(len(payload), block_number, last_block)
                    except Exception as e:
                        logger.warning(f"Progress callback error: {e}", **self._mod)
                
                while not last_block:
                    frame_response = self.__gbt_transceive(
                        DLMSGetRequestNext(block_number).to_bytes(self.builder.security_context))
                    parsed_response = self.builder.parse(MeterResponse(frame_response))
                    if isinstance(parsed_response, DLMSGetResponseWithDatablock):
                        payload.extend(parsed_response.result.raw_data)
                        last_block = parsed_response.result.last_block
                        block_number = parsed_response.result.block_number
                        
                        # Call progress callback for each subsequent block
                        if progress_callback is not None:
                            try:
                                progress_callback(len(payload), block_number, last_block)
                            except Exception as e:
                                logger.warning(f"Progress callback error: {e}", **self._mod)
                    else:
                        last_block = False

                if isinstance(meter_request.request, DLMSGetRequestWithList):
                    response = DLMSGetResponseWithList(payload)
                else:
                    response = DLMSGetResponseNormal(payload)
            elif isinstance(response, DLMSActionResponseWithPblock):
                last_block = response.pblock.last_block
                block_number = response.pblock.block_number
                payload = bytearray([Constant.INVOKED_ID])
                if response.is_success():
                    payload.extend(response.pblock.raw_data)
                
                # Call progress callback for first pblock
                if progress_callback is not None:
                    try:
                        progress_callback(len(payload), block_number, last_block)
                    except Exception as e:
                        logger.warning(f"Progress callback error: {e}", **self._mod)
                
                while not last_block:
                    frame_response = self.__gbt_transceive(
                        DLMSActionRequestNextPblock(block_number).to_bytes(self.builder.security_context))
                    parsed_response = self.builder.parse(MeterResponse(frame_response))
                    if isinstance(parsed_response, DLMSActionResponseWithPblock):
                        payload.extend(parsed_response.pblock.raw_data)
                        last_block = parsed_response.pblock.last_block
                        block_number = parsed_response.pblock.block_number
                        
                        # Call progress callback for each subsequent pblock
                        if progress_callback is not None:
                            try:
                                progress_callback(len(payload), block_number, last_block)
                            except Exception as e:
                                logger.warning(f"Progress callback error: {e}", **self._mod)
                    else:
                        last_block = False
                if isinstance(meter_request.request, DLMSActionRequestWithList):
                    response = DLMSActionResponseWithList(payload)
                else:
                    response = DLMSActionResponseNormal(payload)

        return response

    def __gbt_transceive(self, frame: bytes) -> bytes:
        bna = 0
        window = 1
        sent = 0
        bn = 1
        final_response = bytearray()
        block_control = BlockControl(0)
        if self.configuration.features_activation.general_block_transfer:
            max_apdu_size_bytes = self.configuration.session.buffer_size
            logger.info("max_apdu_size_bytes:" + str(max_apdu_size_bytes), **self._mod)
            logger.info("frame:" + frame.hex().upper(), **self._mod)

            slices = [frame[i:i + max_apdu_size_bytes] for i in range(0, len(frame), max_apdu_size_bytes)]


            # sending data
            for idx, chunk in enumerate(slices):
                block_control.last_block = (idx == len(slices) - 1)
                block_control.streaming = not block_control.last_block
                block_control.window = 1
                general_block_transfer = GeneralBlockTransfer(block_control, bn, bna, OctetStringData.from_bytes(chunk))
                bn = bn + 1
                self.communication.send(general_block_transfer.to_bytes())
                sent = sent + 1
                if sent >= window and len(slices) > 1 and idx < len(slices) - 1:
                    response = self.communication.receive()
                    response_general_block_transfer = GeneralBlockTransfer.from_bytes(response)
                    window = response_general_block_transfer.block_control.window
                    sent = 0
                    bna = bna + 1
        else:
            self.communication.send(frame)
        # receiving data
        response = self.communication.receive()
        if response[0] == GeneralBlockTransfer.TAG:
            if len(response) < 5:
                return response
            response_general_block_transfer = GeneralBlockTransfer.from_bytes(response)
            last_block = response_general_block_transfer.block_control.last_block
            logger.info("window:" + str(window), **self._mod)
            logger.info("last_block:" + str(last_block), **self._mod)
            logger.info(
                "response_general_block_transfer.block_data.value:" + response_general_block_transfer.block_data.value.hex().upper(),
                **self._mod)

            length, data = extract_length(response_general_block_transfer.block_data.value)
            final_response.extend(data)
            bna = response_general_block_transfer.block_number
            received = 1
            general_block_transfer = None
            retries = 5
            if received >= window:
                block_control.last_block = True
                block_control.window = 1
                block_control.streaming = False
                general_block_transfer = GeneralBlockTransfer(block_control, bn, bna, None)
                bn = bn + 1
                self.communication.send(general_block_transfer.to_bytes())
            while not last_block:
                response = None
                while response is None and retries > 0:
                    try:
                        response = self.communication.receive()
                    except Exception as e:
                        retries = retries - 1
                        if general_block_transfer is not None:
                            self.communication.send(general_block_transfer.to_bytes())
                        response = None
                        sleep(0.1)
                if response is None:
                    raise Exception("GBT Error data receive" + ("block_number:" + str(
                        general_block_transfer.block_number) if general_block_transfer is not None else ""))
                retries = 5
                response_general_block_transfer = GeneralBlockTransfer.from_bytes(response)
                window = response_general_block_transfer.block_control.window
                last_block = response_general_block_transfer.block_control.last_block
                length, data = extract_length(response_general_block_transfer.block_data.value)
                final_response.extend(data)
                logger.info("window:" + str(window), **self._mod)
                logger.info("last_block:" + str(last_block), **self._mod)
                logger.info(
                    "response_general_block_transfer.block_data.value:" + response_general_block_transfer.block_data.value.hex().upper(),
                    **self._mod)
                bna = response_general_block_transfer.block_number
                received = received + 1

                if received >= window:
                    block_control.last_block = True
                    block_control.window = 1
                    block_control.streaming = False
                    general_block_transfer = GeneralBlockTransfer(block_control, bn, bna, None)
                    bn = bn + 1
                    self.communication.send(general_block_transfer.to_bytes())
                    sleep(0.05)
            response = self.communication.receive()
            return final_response
        else:
            return response
