import time
from typing import Optional, Callable, List

from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.configuration.config_manager import ConfigModuleProxy
from ng_sdk.constant.dlms.constant import Constant
from ng_sdk.constant.logger.constant import LoggingConstants
from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_builder.dlms.dlms_enums import DataAccessResult
from ng_sdk.frame_builder.dlms.dlms_frame_builder import DLMSFrameBuilder
from ng_sdk.frame_builder.dlms.xdlms.get.request.dlms_get_request_normal import DLMSGetRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.get.response.dlms_get_response_normal import DLMSGetResponseNormal
from ng_sdk.frame_builder.dlms.xdlms.get.response.dlms_get_response_with_list import DLMSGetResponseWithList
from ng_sdk.frame_builder.dlms.xdlms.set.request.dlms_set_request_normal import DLMSSetRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.set.response.dlms_set_response_normal import DLMSSetResponseNormal
from ng_sdk.frame_builder.dlms.xdlms.set.response.dlms_set_response_with_list import DLMSSetResponseWithList
from ng_sdk.frame_executor.abstract_frame_executor import AbstractFrameExecutor
from ng_sdk.frame_executor.models.application_response import ApplicationResponse
from ng_sdk.logger.logger import get_logger

import xml.etree.ElementTree as ET

logger = get_logger()


class SimulationDLMSExecutor(AbstractFrameExecutor):


    _mod = {LoggingConstants.MODULES_NAME: "SimulationDLMSExecutor"}

    def __init__(self,path:str):
        super().__init__(None, None, None)
        self.rows = []
        tree = ET.parse(path)  # path to your XML file
        root = tree.getroot()  # <CommandsList ...>

        for child in root:
            # child tags are node0, node1, ..., node1936
            self.rows.append({
                "node": child.tag,
                "Command": child.get("Command"),
                "ClassID": child.get("ClassID"),
                "LogicName": child.get("LogicName"),
                "Attribute": child.get("Attribute"),
                "ObjectName": child.get("ObjectName"),
                "Value": child.get("Value"),
                "Result": child.get("Result"),
            })

    def execute(self, frame_request: AbstractFrameRequest,
                progress_callback: Optional[Callable[[int, int, bool], None]] = None) -> AbstractFrameResponse:
        if isinstance(frame_request, DLMSGetRequestNormal):
            object_capture = next(
                (item for item in self.rows if item["LogicName"] == frame_request.obis_code and int(item["ClassID"]) == frame_request.class_id and int(item["Attribute"]) == frame_request.attribute), None)
            if object_capture is None:
                raise RuntimeError(f"Object {frame_request.obis_code} not found.")
            frame = bytearray([Constant.INVOKED_ID, DataAccessResult.SUCCESS])
            values = object_capture["Value"].split(",")
            logger.info("object_capture[Value].split(,) "+str(len(values)), **self._mod)
            if len(values)<=1:
                frame.extend(bytes.fromhex(object_capture["Value"]))
            else:
                i = 0
                for value in values:
                    frame.extend(bytearray.fromhex(value))
                    progress_callback(len(frame), i, i == len(values)-1)
                    i = i + 1
                    time.sleep(0.1)
            return DLMSGetResponseNormal(frame)

        elif isinstance(frame_request, DLMSSetRequestNormal):
            object_capture = next(
                (item for item in self.rows if item["LogicName"] == frame_request.obis_code and int(item["ClassID"]) == frame_request.class_id and int(item["Attribute"]) == frame_request.attribute), None)
            if object_capture is None:
                raise RuntimeError(f"Object {frame_request.obis_code} not found.")
            object_capture["Value"] = frame_request.payload.hex().upper()
            frame = bytearray([Constant.INVOKED_ID, DataAccessResult.SUCCESS])
            return DLMSSetResponseNormal(frame)

        raise RuntimeError("Request not defined")

    def execute_list(self, frame_requests: List[AbstractFrameRequest],
                     progress_callback: Optional[Callable[[int, int, bool], None]] = None) -> AbstractFrameResponse:


        frame = bytearray([Constant.INVOKED_ID,len(frame_requests) ])
        if isinstance(frame_requests[0], DLMSGetRequestNormal):
            for frame_request in frame_requests:
                response = self.execute(frame_request, progress_callback=progress_callback)
                if isinstance(response, DLMSGetResponseNormal):
                    frame.extend(bytearray([DataAccessResult.SUCCESS]))
                    frame.extend(response.data.to_bytes())
            return DLMSGetResponseWithList(frame)

        elif isinstance(frame_requests[0], DLMSSetRequestNormal):
            for frame_request in frame_requests:
                response = self.execute(frame_request, progress_callback=progress_callback)
                if isinstance(response, DLMSSetResponseNormal):
                    frame.extend(bytearray([DataAccessResult.SUCCESS]))
            return DLMSSetResponseWithList(frame)
        raise RuntimeError("Request not defined")


    def advanced_execute_list(self, frame_requests: List[AbstractFrameRequest],
                              progress_callback: Optional[Callable[[int, int, bool], None]] = None) -> List[
        ApplicationResponse]:
        raise RuntimeError("advanced_execute_list not defined")

    def advanced_execute(self, frame_request: AbstractFrameRequest,
                         progress_callback: Optional[Callable[[int, int, bool], None]] = None) -> ApplicationResponse:
        raise RuntimeError("advanced_execute not defined")

    def start_keepalive(self):
        pass

    def stop_keepalive(self):
        pass













