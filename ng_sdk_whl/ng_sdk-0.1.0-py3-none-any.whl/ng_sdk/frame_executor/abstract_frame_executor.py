import threading
from abc import ABC, abstractmethod
from typing import List, Optional, Callable

from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.configuration.config_manager import  ConfigModuleProxy
from ng_sdk.frame_builder.abstract_frame_builder import AbstractFrameBuilder
from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.frame_executor.models.application_response import ApplicationResponse


class AbstractFrameExecutor(ABC):
    def __init__(self,communication:AbstractCommunication,builder:AbstractFrameBuilder,configuration:ConfigModuleProxy):
        self.is_established = False
        self.communication = communication
        self.builder = builder
        self.configuration = configuration

    @abstractmethod
    def execute_list(self,frame_requests:List[AbstractFrameRequest],progress_callback: Optional[Callable[[int, int, bool], None]] = None,cancel_event: Optional[threading.Event] = None)->AbstractFrameResponse:
        pass

    @abstractmethod
    def execute(self, frame_request: AbstractFrameRequest,progress_callback: Optional[Callable[[int, int, bool], None]] = None,cancel_event: Optional[threading.Event] = None)->AbstractFrameResponse:
        pass

    @abstractmethod
    def advanced_execute_list(self,frame_requests:List[AbstractFrameRequest],progress_callback: Optional[Callable[[int, int, bool], None]] = None,cancel_event: Optional[threading.Event] = None)->List[ApplicationResponse]:
        pass

    @abstractmethod
    def advanced_execute(self, frame_request: AbstractFrameRequest,progress_callback: Optional[Callable[[int, int, bool], None]] = None,cancel_event: Optional[threading.Event] = None)->ApplicationResponse:
        pass

    @abstractmethod
    def start_keepalive(self):
        pass

    @abstractmethod
    def stop_keepalive(self):
        pass