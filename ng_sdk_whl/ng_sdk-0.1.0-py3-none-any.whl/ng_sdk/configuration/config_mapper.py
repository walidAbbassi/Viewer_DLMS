"""
Configuration Mapper Module for DLMS/COSEM SDK.

This module provides dynamic type mapping functionality for configuration dictionaries
based on JSON5 mapping rules. It supports automatic conversion of configuration values
to appropriate Python types including bytes, enums, and other complex types.

The mapper is designed to transform raw configuration data (typically strings) into
strongly-typed objects that can be used directly by the DLMS communication system.

Key Features:
    - Automatic hex string to bytes conversion
    - Dynamic enum loading and value mapping
    - Nested configuration path support (dot notation)
    - Comprehensive error handling and validation
    - Logging integration for debugging and monitoring

Example:
    config = {
        'security': {
            'systemTitle': 'ABC123DEF456',
            'security_level': 'GMAC'
        }
    }
    
    mapped_config = apply_mapper(config)
    # Result: system_title becomes bytes, security_level becomes enum
"""
import copy
import importlib
from importlib.resources import files, as_file
from pathlib import Path
from typing import Any, Dict

import json5

from ng_sdk.logger.logger import LoggingConstants, get_logger

logger = get_logger()
_mod = {LoggingConstants.MODULES_NAME: "CONFIG_MAPPER"}


def _get_mapping_rules_file_path(config_dir: Path) -> Path:
    """
    Get the absolute path to the security configuration mapping file.
    
    This function resolves the mapping file path relative to this module's location,
    ensuring it works correctly regardless of the current working directory.
    
    Returns:
        Path: Absolute path to the security_config_map.json5 file
        
    Raises:
        FileNotFoundError: If the mapping file does not exist
    """

    # Get the directory containing this module

    with as_file(files('ng_sdk.mapper') / 'security_config_map.json5') as mapping_file:
        logger.trace(f"Looking for mapping file at: {mapping_file}", _mod)

        if not mapping_file.exists():
            logger.error(f"Mapping file not found: {mapping_file}", _mod)
            raise FileNotFoundError(f"Configuration mapping file not found: {mapping_file}", _mod)

        logger.trace(f"Mapping file found: {mapping_file}", _mod)
        return mapping_file


def load_mapping_rules(config_dir: Path) -> Dict[str, str]:
    """
    Load and parse the JSON5 mapping rules file.
    
    Args:
        config_dir: Path to the JSON5 mapping rules file
        
    Returns:
        Dictionary containing the mapping rules
        
    Raises:
        FileNotFoundError: If the mapping file cannot be found
        json5.Json5Exception: If the JSON5 file is malformed
        IOError: If there are file reading issues
    """
    mapping_file_path = _get_mapping_rules_file_path(config_dir)
    logger.trace(f"Loading mapping rules from: {mapping_file_path}", _mod)

    try:
        with open(mapping_file_path, 'r', encoding='utf-8') as f:
            mapping_rules = json5.load(f)

        logger.trace(f"Successfully loaded {len(mapping_rules)} mapping rules", _mod)
        return mapping_rules

    except ValueError as e:
        logger.error(f"Invalid JSON5 format in mapping file: {e}", _mod)
        raise
    except IOError as e:
        logger.error(f"Error reading mapping file: {e}", _mod)
        raise


def _validate_input_config(config_dict: Any) -> None:
    """
    Validate the input configuration dictionary.
    
    Args:
        config_dict: Input configuration to validate
        
    Raises:
        TypeError: If config_dict is not a dictionary
        ValueError: If config_dict is None or empty
    """

    if config_dict is None:
        raise ValueError("Configuration dictionary cannot be None")

    if not isinstance(config_dict, dict):
        raise TypeError(f"Configuration must be a dictionary, got: {type(config_dict).__name__}")

    if not config_dict:
        logger.warning("Configuration dictionary is empty", _mod)

    logger.trace(f"Input configuration validated successfully with {len(config_dict)} top-level keys", _mod)


def _convert_hex_to_bytes(hex_value: str, key_path: str) -> bytes:
    """
    Convert hex string to bytes with validation.
    
    Args:
        hex_value: Hexadecimal string to convert
        key_path: Configuration key path for error context
        
    Returns:
        Converted bytes object
        
    Raises:
        ValueError: If hex_value is not a valid hexadecimal string
        TypeError: If hex_value is not a string
    """

    if not isinstance(hex_value, str):
        raise TypeError(f"Hex value must be a string for key '{key_path}', got: {type(hex_value).__name__}")

    # Remove common prefixes and whitespace
    cleaned_hex = hex_value.replace('0x', '').replace('0X', '').replace(' ', '')

    if not cleaned_hex:
        raise ValueError(f"Empty hex string for key '{key_path}'")

    # Validate hex format
    if not all(c in '0123456789ABCDEFabcdef' for c in cleaned_hex):
        raise ValueError(f"Invalid hex string '{hex_value}' for key '{key_path}'")

    # Ensure even length for proper byte conversion
    if len(cleaned_hex) % 2 != 0:
        cleaned_hex = '0' + cleaned_hex
        logger.trace(f"Padded hex string with leading zero for key '{key_path}': {cleaned_hex}", _mod)

    try:
        result = bytes.fromhex(cleaned_hex)
        logger.trace(f"Converted hex '{hex_value}' to {len(result)} bytes for key '{key_path}'", _mod)
        return result

    except ValueError as e:
        logger.error(f"Failed to convert hex '{hex_value}' for key '{key_path}': {e}", _mod)
        raise ValueError(f"Invalid hex string '{hex_value}' for key '{key_path}': {e}", _mod)


def load_enum_class(enum_path: str, key_path: str) -> Any:
    """
    Dynamically load an enum class from its module path.
    
    Args:
        enum_path: Full module path to the enum class (e.g., 'module.submodule.EnumClass')
        key_path: Configuration key path for error context
        
    Returns:
        The loaded enum class
        
    Raises:
        ImportError: If the module cannot be imported
        AttributeError: If the enum class cannot be found in the module
        ValueError: If the enum_path format is invalid
    """

    if not enum_path or not isinstance(enum_path, str):
        raise ValueError(f"Invalid enum path '{enum_path}' for key '{key_path}'")

    if '.' not in enum_path:
        raise ValueError(f"Enum path must contain module and class name for key '{key_path}': {enum_path}")

    try:
        # Split module path and class name
        module_path, class_name = enum_path.rsplit('.', 1)

        logger.trace(f"Loading enum class '{class_name}' from module '{module_path}' for key '{key_path}'", _mod)

        # Import the module
        module = importlib.import_module(module_path)

        # Get the enum class
        if not hasattr(module, class_name):
            raise AttributeError(f"Module '{module_path}' has no attribute '{class_name}'")

        enum_class = getattr(module, class_name)

        logger.trace(f"Successfully loaded enum class '{class_name}' for key '{key_path}'", _mod)
        return enum_class

    except ImportError as e:
        logger.error(f"Failed to import module '{module_path}' for key '{key_path}': {e}", _mod)
        raise ImportError(f"Cannot import enum module '{module_path}' for key '{key_path}': {e}")
    except AttributeError as e:
        logger.error(f"Enum class '{class_name}' not found in module '{module_path}' for key '{key_path}': {e}", _mod)
        raise


def _convert_to_enum(enum_class: Any, value: Any, key_path: str) -> Any:
    """
    Convert a value to an enum member with comprehensive validation.
    
    Args:
        enum_class: The enum class to convert to
        value: The value to convert (string name or enum value)
        key_path: Configuration key path for error context
        
    Returns:
        The enum member
        
    Raises:
        ValueError: If the value cannot be converted to the enum
        TypeError: If the enum_class is not actually an enum
    """

    # Validate that we have an actual enum class
    if not hasattr(enum_class, '__members__'):
        raise TypeError(f"'{enum_class}' is not a valid enum class for key '{key_path}'")

    logger.trace(f"Converting value '{value}' to enum '{enum_class.__name__}' for key '{key_path}'", _mod)

    try:
        # Try by member name first (for string values)
        if isinstance(value, str) and value in enum_class.__members__:
            result = enum_class[value]
            logger.trace(f"Converted string '{value}' to enum member for key '{key_path}'", _mod)
            return result

        # Try by value (for numeric or other values)
        result = enum_class(value)
        logger.trace(f"Converted value '{value}' to enum member for key '{key_path}'", _mod)
        return result

    except (ValueError, KeyError) as e:
        available_values = list(enum_class.__members__.keys())
        logger.error(f"For '{key_path}', expected one of: {available_values}, got: '{value}'", _mod)
        raise ValueError(f"For '{key_path}', expected one of: {available_values}, got: '{value}'")


def apply_mapper_file_saving(mapping_rules: Dict[str, str], config_dict_: Dict[str, Any]) -> Dict[str, Any]:
    config_dict = copy.deepcopy(config_dict_)

    logger.trace(f"Processing {len(mapping_rules)} mapping rules", _mod)
    # Apply each mapping rule
    for key, map_type in mapping_rules.items():
        logger.trace(f"Processing mapping rule: {key} -> {map_type}", _mod)

        try:
            # Parse the key path (e.g., "security.security_level" -> ["security", "security_level"])
            key_path_parts = key.split('.')

            # Traverse the config_dict to find the target location
            current_dict = config_dict

            # Navigate to the parent dictionary
            for path_key in key_path_parts[:-1]:
                if path_key not in current_dict:
                    logger.trace(f"Key path '{path_key}' not found in config, skipping rule for '{key}'", _mod)
                    break

                if not isinstance(current_dict[path_key], dict):
                    logger.warning(
                        f"Expected dictionary at '{path_key}' in path '{key}', got {type(current_dict[path_key])}",
                        _mod)
                    break

                current_dict = current_dict[path_key]
            else:
                # Check if the final key exists
                last_key = key_path_parts[-1]

                if last_key not in current_dict:
                    logger.trace(f"Target key '{last_key}' not found in config, skipping rule for '{key}'", _mod)
                    continue

                # Get the current value
                original_value = current_dict[last_key]
                logger.trace(f"Found value '{original_value}' for key '{key}'", _mod)
                # Apply the appropriate mapping based on type
                if map_type == "byte":
                    # Convert hex string to bytes
                    current_dict[last_key] = original_value.hex().upper()

                elif map_type.startswith("enum_"):
                    # Convert to enum member
                    current_dict[last_key] = original_value.name

                else:
                    logger.warning(f"Unknown mapping type '{map_type}' for key '{key}', skipping", _mod)

        except Exception as e:
            logger.error(f"Failed to apply mapping for key '{key}': {e}", _mod)
            # Continue processing other keys even if one fails
            continue

    logger.trace("Configuration mapping completed successfully", _mod)
    return config_dict


def apply_mapper(mapping_rules: Dict[str, str], config_dict: Dict[str, Any]) -> Dict[str, Any]:
    """
    Apply type mapping to configuration dictionary based on JSON5 mapping rules.
    
    This function transforms configuration values from their raw format (typically strings)
    into strongly-typed Python objects. It supports nested configuration paths using
    dot notation and handles multiple conversion types including bytes and enums.
    
    The mapping rules are loaded from 'security_config_map.json5' in the same directory
    as this module. Each rule specifies a configuration path and the target type.
    
    Supported mapping types:
        - "byte": Converts hex strings to bytes objects
        - "enum_<module.path.EnumClass>": Converts values to enum members
    
    Args:
        mapping_rules:
        config_dict: Configuration dictionary to apply mappings to.
                    This dictionary is modified in-place.
    
    Returns:
        The modified configuration dictionary with applied type mappings.
        
    Raises:
        TypeError: If config_dict is not a dictionary
        ValueError: If config_dict is None or contains invalid values
        FileNotFoundError: If the mapping rules file cannot be found
        ImportError: If required enum modules cannot be imported
        
    Example:
        config = {
            'security': {
                'system_title': 'ABC12345',
                'security_level': 'GMAC'
            }
        }
        
        mapped_config = apply_mapper(config)
        # config['security']['system_title'] becomes bytes
        # config['security']['security_level'] becomes enum member
    """

    logger.trace("Starting configuration mapping process", _mod)

    try:
        # Validate input configuration
        _validate_input_config(config_dict)

        logger.trace(f"Processing {len(mapping_rules)} mapping rules", _mod)

        # Apply each mapping rule
        for key, map_type in mapping_rules.items():
            logger.trace(f"Processing mapping rule: {key} -> {map_type}", _mod)

            try:
                # Parse the key path (e.g., "security.security_level" -> ["security", "security_level"])
                key_path_parts = key.split('.')

                # Traverse the config_dict to find the target location
                current_dict = config_dict

                # Navigate to the parent dictionary
                for path_key in key_path_parts[:-1]:
                    if path_key not in current_dict:
                        logger.trace(f"Key path '{path_key}' not found in config, skipping rule for '{key}'", _mod)
                        break

                    if not isinstance(current_dict[path_key], dict):
                        logger.warning(
                            f"Expected dictionary at '{path_key}' in path '{key}', got {type(current_dict[path_key])}",
                            _mod)
                        break

                    current_dict = current_dict[path_key]
                else:
                    # Check if the final key exists
                    last_key = key_path_parts[-1]

                    if last_key not in current_dict:
                        logger.trace(f"Target key '{last_key}' not found in config, skipping rule for '{key}'", _mod)
                        continue

                    # Get the current value
                    original_value = current_dict[last_key]
                    logger.trace(f"Found value '{original_value}' for key '{key}'", _mod)

                    # Apply the appropriate mapping based on type
                    if map_type == "byte":
                        # Convert hex string to bytes
                        current_dict[last_key] = _convert_hex_to_bytes(original_value, key)
                        logger.trace(f"Converted hex to bytes for key '{key}'", _mod)

                    elif map_type.startswith("enum_"):
                        # Convert to enum member
                        enum_path = map_type.replace("enum_", "")
                        enum_class = load_enum_class(enum_path, key)
                        current_dict[last_key] = _convert_to_enum(enum_class, original_value, key)
                        logger.trace(f"Converted to enum for key '{key}'", _mod)

                    else:
                        logger.warning(f"Unknown mapping type '{map_type}' for key '{key}', skipping", _mod)

            except Exception as e:
                logger.error(f"Failed to apply mapping for key '{key}': {e}", _mod)
                # Continue processing other keys even if one fails
                continue

        logger.trace("Configuration mapping completed successfully", _mod)
        return config_dict

    except Exception as e:
        logger.error(f"Configuration mapping failed: {e}", _mod)
        raise
