import os
import tempfile
import threading
from pathlib import Path
from typing import Dict, Iterable

import json5
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.configuration.config_mapper import apply_mapper, apply_mapper_file_saving, load_mapping_rules

import ujson5


logger = get_logger()
_mod = {LoggingConstants.MODULES_NAME: "CONFIG_MANAGER"}
class ConfigManager:
    """
    Thread-safe singleton per config directory.

    Behavior:
      - Legacy modules: <module>.json5 at config root.
      - Folder modules: <module>/*.json5 (each file loaded under its stem key).

    Access examples:
      configuration.app.db.host
      configuration.datamodel.imageTransfer.block_size
      configuration.datamodel["ActiveEnergyExport(-A)Interval"].classId

    Persistence:
      - Proxy assignments are in-memory.
      - Use set(module, dotted_key, value, persist=True) to write.
        For folder modules, dotted_key = "<file>.<nested.path>".
    """
    _instances: Dict[str, "ConfigManager"] = {}
    _instances_lock = threading.Lock()



    def __new__(cls, config_dir: str):
        with cls._instances_lock:
            key = str(Path(config_dir).resolve())
            if key not in cls._instances:
                inst = super().__new__(cls)
                inst._init(Path(config_dir))
                cls._instances[key] = inst
            return cls._instances[key]

    def _init(self, config_dir: Path):
        self._config_dir = config_dir
        self.config_rules = load_mapping_rules(config_dir)
        self._config_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._configs: dict[str, dict] = {}  # cached, mapped

    # -------- helpers --------
    def _is_folder_module(self, module: str) -> bool:
        return (self._config_dir / module).is_dir()

    def _legacy_file_path(self, module: str) -> Path:
        return self._config_dir / f"{module}.json5"

    def _folder_file_path(self, module: str, file_stem: str) -> Path:
        return self._config_dir / module / f"{file_stem}.json5"

    def _iter_namespace_file_paths(self, module: str) -> Iterable[Path]:
        ns_path = self._config_dir / module
        if ns_path.exists() and ns_path.is_dir():
            yield from sorted(ns_path.glob("*.json5"))

    # -------- loading --------
    def _load_module(self, module: str) -> dict:
        """
        Loads and caches a module:
          - legacy: mapped dict from <module>.json5
          - folder: dict of {stem: mapped dict} from <module>/*.json5
        """
        with self._lock:
            # logger.info(f"Strarting reading module: {module}", _mod)
            if module in self._configs:
                return self._configs[module]

            if self._is_folder_module(module):
                ns_path = self._config_dir / module
                combined: dict[str, dict] = {}
                for p in sorted(ns_path.glob("*.json5")):
                    with open(p, "r", encoding="utf-8") as f:
                        json5_str = f.read()
                        raw = ujson5.loads(json5_str)
                    combined[p.stem] = apply_mapper(self.config_rules, raw)
                self._configs[module] = combined
                return combined

            # legacy single-file module
            path = self._legacy_file_path(module)
            if path.exists():
                with open(path, 'r', encoding='utf-8') as f:
                    json5_str = f.read()
                    cfg = ujson5.loads(json5_str)

                    #cfg = json5.load(f)
                    logger.info(f"Finished reading module: {module}", _mod)
                cfg = apply_mapper(self.config_rules, cfg)
            else:
                cfg = {}
            self._configs[module] = cfg
            return cfg

    # -------- public API --------
    def list_files(self, module: str) -> list[str]:
        """
        For folder modules: return file basenames (without .json5).
        For legacy modules: return [].
        """
        if not self._is_folder_module(module):
            return []
        return [p.stem for p in self._iter_namespace_file_paths(module)]

    def load_namespace(self, module: str) -> dict:
        """
        For folder modules: load every file (mapped) -> { "<stem>": dict, ... }.
        For legacy modules: return the mapped dict for the single file.
        """
        if not self._is_folder_module(module):
            return self._load_module(module)
        out: Dict[str, dict] = {}
        for p in self._iter_namespace_file_paths(module):
            # Use cache loader to stay consistent
            _ = self._load_module(module)  # ensure module cached
            out[p.stem] = self._configs[module][p.stem]
        return out

    def get(self, module: str, key: str, default=None):
        """
        Dotted get on module.
        For folder modules, 'key' should start with the file stem:
          e.g. get("datamodel", "imageTransfer.block_size")
        """
        cfg = self._load_module(module)
        cur = cfg
        for part in key.split('.'):
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            else:
                return default
        return cur

    def set(self, module: str, key: str, value, persist: bool = False):
        """
        Sets module[key] = value (in-memory).
        If persist=True:
          - legacy module: writes <module>.json5
          - folder module: first segment of key is file stem -> writes <module>/<stem>.json5
        """
        with self._lock:
            cfg = self._load_module(module)  # mapped cache

            parts = key.split('.')
            cur = cfg

            # For folder module, ensure dict for the file stem at top-level
            if self._is_folder_module(module):
                if not parts:
                    return
                file_stem = parts[0]
                cur = cur.setdefault(file_stem, {})
                sub_parts = parts[1:]
            else:
                sub_parts = parts

            # nested set into mapped cache
            for part in sub_parts[:-1]:
                if not isinstance(cur.get(part), dict):
                    cur[part] = {}
                cur = cur[part]
            cur[sub_parts[-1]] = value

            if persist:
                if self._is_folder_module(module):
                    file_stem = parts[0]
                    self._atomic_write_folder(module, file_stem, cfg[file_stem])
                else:
                    self._atomic_write_legacy(module, cfg)

    # -------- writing --------
    def _atomic_write_legacy(self, module: str, mapped_cfg: dict):
        path = self._legacy_file_path(module)
        tmp_fd, tmp_path = tempfile.mkstemp(dir=self._config_dir, text=True)
        try:
            with os.fdopen(tmp_fd, 'w', encoding='utf-8') as f:
                f.write(json5.dumps(apply_mapper_file_saving(self.config_rules, mapped_cfg), indent=2))
                f.write('\n')
            os.replace(tmp_path, path)
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

    def _atomic_write_folder(self, module: str, file_stem: str, mapped_cfg: dict):
        ns_dir = self._config_dir / module
        ns_dir.mkdir(parents=True, exist_ok=True)
        path = self._folder_file_path(module, file_stem)

        tmp_fd, tmp_path = tempfile.mkstemp(dir=ns_dir, text=True)
        try:
            with os.fdopen(tmp_fd, 'w', encoding='utf-8') as f:
                f.write(json5.dumps(apply_mapper_file_saving(self.config_rules, mapped_cfg), indent=2))
                f.write('\n')
            os.replace(tmp_path, path)
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

    # --- MAGIC: Support config.module access ---
    def __getattr__(self, module):
        return ConfigModuleProxy(self, module)

    def __getitem__(self, module: str) -> "ConfigModuleProxy":
        return ConfigModuleProxy(self, module)


class ConfigModuleProxy:
    """
    Dynamic view on a module.
    - Legacy: mapped content of <module>.json5
    - Folder: {<file_stem>: <mapped dict>, ...}
    Attribute/item access drills into keys (for folder: files first, then content).
    """
    def __init__(self, manager: ConfigManager, module: str, path=None):
        self._manager = manager
        self._module = module
        self._path = path or []

    # ---- reads ----
    def __getattr__(self, key):
        cfg = self._manager._load_module(self._module)
        cur = cfg
        for part in self._path:
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            else:
                return None

        if isinstance(cur, dict) and key in cur:
            val = cur[key]
            if isinstance(val, dict):
                return ConfigModuleProxy(self._manager, self._module, self._path + [key])
            else:
                return val
        else:
            # Auto-create nested proxy (in-memory only)
            return ConfigModuleProxy(self._manager, self._module, self._path + [key])

    def __getitem__(self, key):
        return getattr(self, key)

    def __call__(self):
        # Return dict at current path
        cfg = self._manager._load_module(self._module)
        cur = cfg
        for part in self._path:
            if isinstance(cur, dict):
                cur = cur.get(part, {})
            else:
                return {}
        return cur if isinstance(cur, dict) else {}

    # ---- writes (in-memory) ----
    def __setattr__(self, key, value):
        if key.startswith('_'):
            super().__setattr__(key, value)
            return

        # mutate in-memory cache at the current path
        cfg = self._manager._load_module(self._module)
        cur = cfg
        for part in self._path:
            nxt = cur.get(part)
            if not isinstance(nxt, dict):
                nxt = {}
                cur[part] = nxt
            cur = nxt
        cur[key] = value

    def __setitem__(self, key, value):
        """
        Enable dict-style item assignment:
          configuration.datamodel["imageTransfer"]["block_size"] = 2048
        (In-memory only; persist via manager.set(..., persist=True))
        """
        self.__setattr__(key, value)

    # ---- namespace helpers you asked to keep ----
    def files(self) -> list[str]:
        """
        For folder modules: ["imageTransfer", "security", ...]
        For legacy modules: []
        """
        if self._path:  # only valid at module root
            return []
        return self._manager.list_files(self._module)

    def as_dict(self) -> dict:
        """
        For folder modules: {"imageTransfer": {...}, ...}
        For legacy modules: the mapped dict for <module>.json5
        """
        if self._path:  # only valid at module root
            return self()
        return self._manager.load_namespace(self._module)


    # ---- mapping-like API ----
    def keys(self) -> list[str]:
        """
        Top-level keys under the current node.
        - Folder module at root => file stems (e.g., ["imageTransfer", "security", ...])
        - Legacy module at root => top-level keys of <module>.json5
        - Nested path => keys under that nested object
        """
        return list(self._current_dict().keys())

    def get(self, key: str, default=None):
        """
        Dotted get relative to the current proxy path.
        Example at module root:
            configuration.app.get("db.host")
        Example under nested path:
            configuration.app.db.get("host")
        For folder modules, include the file stem when used at module root:
            configuration.datamodel.get("imageTransfer.block_size")
        """
        # Load mapped cache
        cfg = self._manager._load_module(self._module)
        # Walk to current path
        cur = cfg
        for part in self._path:
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            else:
                return default

        # Now resolve the provided dotted key relative to current path
        parts = key.split('.') if key else []
        for part in parts:
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            else:
                return default
        return cur

    def set(self, key: str, value, persist: bool = False):
        """
        Dotted set relative to the current proxy path.
        - In-memory by default (mirrors __setattr__/__setitem__).
        - If persist=True:
            * legacy module -> writes <module>.json5
            * folder module -> first segment of resolved key is the file stem
        Examples:
            configuration.app.set("db.host", "localhost", persist=True)
            configuration.app.db.set("host", "localhost", persist=True)
            configuration.datamodel.set("imageTransfer.block_size", 2048, persist=True)
            configuration.datamodel["imageTransfer"].set("block_size", 2048, persist=True)
        """
        # Combine current path with provided dotted key
        cur_path = list(self._path)  # already relative pieces
        sub_parts = key.split('.') if key else []

        # In-memory mutation at the target node
        cfg = self._manager._load_module(self._module)
        # Walk/create down to current path
        cur = cfg
        for part in cur_path:
            nxt = cur.get(part)
            if not isinstance(nxt, dict):
                nxt = {}
                cur[part] = nxt
            cur = nxt

        # Create nested structure for sub_parts (except last)
        for part in sub_parts[:-1]:
            nxt = cur.get(part)
            if not isinstance(nxt, dict):
                nxt = {}
                cur[part] = nxt
            cur = nxt

        # Set final value
        if sub_parts:
            cur[sub_parts[-1]] = value
        else:
            # Setting at the current node with empty key -> replace dict
            # (optional: you can raise if you prefer disallowing empty keys)
            if isinstance(value, dict):
                # replace whole current node
                # Note: we mutate cur in-place; for persistence we still write below
                for k in list(cur.keys()):
                    del cur[k]
                cur.update(value)
            else:
                raise ValueError("Empty key only allowed when 'value' is a dict to replace current node.")

        # Persist if requested
        if persist:
            # Build full dotted key: "<path>.<key>" (no leading/trailing dots)
            full_parts = cur_path + sub_parts
            if not full_parts:
                # Persist whole module root
                if self._manager._is_folder_module(self._module):
                    # Writing the whole namespace as multiple files isn’t defined;
                    # you can choose to raise or iterate files. We raise here to keep semantics clear.
                    raise ValueError("Persisting the entire namespace via proxy root is not supported.")
                else:
                    self._manager._atomic_write_legacy(self._module, cfg)
                return

            full_key = ".".join(full_parts)
            # Delegate to manager.set to re-use its folder/legacy logic
            self._manager.set(self._module, full_key, value, persist=True)

    def _current_dict(self) -> dict:
        """Dict at current path ({} if non-dict)."""
        cfg = self._manager._load_module(self._module)
        cur = cfg
        for part in self._path:
            if isinstance(cur, dict):
                cur = cur.get(part, {})
            else:
                return {}
        return cur if isinstance(cur, dict) else {}

