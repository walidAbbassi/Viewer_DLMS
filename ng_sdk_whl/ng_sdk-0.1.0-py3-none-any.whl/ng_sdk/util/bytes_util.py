import string

#TODO not compleat conversion
def obis_code_to_bytes(obis_code:str)->bytes:
    return bytes.fromhex(obis_code)

def bytearray_pop_range(data:bytearray, start:int, end:int)-> bytes:
    popped = data[start:end]
    del data[start:end]
    return popped

def encode_variable_integer(length: int):
    if length > 0b01111111:
        encoded_length = 1
        while True:
            try:
                length.to_bytes(encoded_length, "big")
            except OverflowError:
                encoded_length += 1
                continue
            break

        length_byte = (0b10000000 + encoded_length).to_bytes(1, "big")
        return length_byte + length.to_bytes(encoded_length, "big")

    else:
        return length.to_bytes(1, "big")
def to_bytes_from_hexish(value) -> bytes:
    """
    Accepts:
      - bytes          -> returned as-is
      - bytearray      -> converted to bytes
      - str (hex)      -> spaces/underscores/0x prefixes allowed, even-length required
    Raises TypeError/ValueError otherwise.
    """
    if isinstance(value, bytes):
        return value
    if isinstance(value, bytearray):
        return bytes(value)
    if isinstance(value, str):
        cleaned = (value.replace(" ", "")
                        .replace("_", "")
                        .removeprefix("0x")
                        .removeprefix("0X"))
        if len(cleaned) % 2:
            raise ValueError("hex string must have an even number of characters")
        try:
            return bytes.fromhex(cleaned)
        except ValueError as e:
            raise ValueError(f"invalid hex string: {value}") from e
    raise TypeError(f"expected bytes/bytearray/hex str, got {type(value).__name__}")




def extract_length(data: bytes) -> tuple[int, bytes]:
    """
    Extract length from given bytes according to DLMS-like rules.

    Returns:
        (length, remaining_data)

    Rules:
    - If first byte < 0x82: that byte is the length.
    - If first byte >= 0x82: number of following bytes = first_byte - 0x80.
    """
    if not data:
        raise ValueError("Empty data")

    first_byte = data[0]

    if first_byte < 0x81:
        length = first_byte
        remaining = data[1:]
    else:
        num_len_bytes = first_byte - 0x80
        if len(data) < 1 + num_len_bytes:
            raise ValueError("Not enough bytes to extract length")

        length_bytes = data[1:1 + num_len_bytes]
        length = int.from_bytes(length_bytes, "big")
        remaining = data[1 + num_len_bytes:]

    return length, remaining

def encode_length(length: int) -> bytes:
    """
    Encode length using DLMS-like rules.
    - If length < 0x82: one byte, the length itself.
    - Else: prefix = 0x80 + number_of_length_bytes,
            followed by length in big-endian.
    """
    if length < 0:
        raise ValueError("Length must be non-negative")

    if length < 0x81:
        return bytes([length])
    else:
        length_bytes = length.to_bytes((length.bit_length() + 7) // 8, "big")
        prefix = 0x80 + len(length_bytes)
        return bytes([prefix]) + length_bytes

