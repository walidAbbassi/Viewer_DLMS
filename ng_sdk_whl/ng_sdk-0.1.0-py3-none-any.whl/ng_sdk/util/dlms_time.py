from datetime import date, datetime, time,timezone, timedelta
from typing import Tuple, Optional, Union


from ng_sdk.frame_builder.dlms.xdlms.data_type.models.clock_status import ClockStatus


def datetime_from_bytes(source_bytes: bytes) -> Tuple[datetime, Optional[ClockStatus]]:
    """
     Datetime is represented byte 12 bytes
     [date[year highbyte, year lowbyte, month, day of month, day of week],
     time[hour, minute, second, hundredths], deviation_high, deviation_low, clock_status]
     }

    date: as above
    time: as above
    deviation: deviation from UTC in minutes. Shows the timezone. signed long-integer
         (-720 < dev < 720)
         Special case:
             0x8000: not specified.

    """
    if len(source_bytes) != 12:
        raise ValueError(
            f"Datetime is represented by 12 bytes, but got {len(source_bytes)}"
        )
    d = date_from_bytes(source_bytes[:5])
    t = time_from_bytes(source_bytes[5:9])
    deviation = get_optional_value(
        int.from_bytes(source_bytes[9:11], "big", signed=True), b"\x80\x00", signed=True
    )
    status_bytes = source_bytes[-1].to_bytes(1, "big")
    status = ClockStatus.from_bytes(status_bytes) if status_bytes else None

    dt = datetime(
        year=d.year,
        month=d.month,
        day=d.day,
        hour=t.hour,
        minute=t.minute,
        second=t.second,
        microsecond=t.microsecond,
        tzinfo=utc_offset_minutes(deviation),
    )

    return dt, status

def date_from_bytes(source_bytes: bytes) -> date:

    """
    Date is represented by 5 bytes.
    [year highbyte, year lowbyte, month, day of month, day of week

    year: long-unsigned int.
        Special case:
            0xFFFF == not specified.

    month:  unsigned int (1-12) 1 = January.
        Special cases:
            0xfd = daylight_savings_end
            0xfe = daylight_savings_begin
            0xff = not specified.

    day_of_month: unsigned int 1-31,
        Special cases:
            0xe0-0xfc: reserved
            0xfd = 2nd last day of month
            0xfe = last day of month
            0xff = not specified

    day_of_week: unsigned in 1-7, 1 = Monday
        Special cases:
            0xff = not specifed

    The elements dayOfMonth and dayOfWeek shall be interpreted together:
    - if last dayOfMonth is specified (0xFE) and dayOfWeek is wildcard, this specifies
        the last calendar day of the month;
    - if last dayOfMonth is specified (0xFE) and an explicit dayOfWeek is specified
        (for example 7, Sunday) then it is the last occurrence of the weekday specified
        in the month, i.e. the last Sunday;
    - if the year is not specified (0xFFFF), and dayOfMonth and dayOfWeek are both
        explicitly specified, this shall be interpreted as the dayOfWeek on, or
        following dayOfMonth;
    - if the year and month are specified, and both the dayOfMonth and dayOfWeek are
        explicitly specified but the values are not consistent it shall be considered
        as an error.



    """
    if len(source_bytes) != 5:
        raise ValueError(f"Date is represented by 5 bytes, but got {len(source_bytes)}")

    year = get_optional_value(int.from_bytes(source_bytes[:2], "big"), b"\xff\xff")
    month = get_optional_value(source_bytes[2], b"\xff")
    day_of_month = get_optional_value(source_bytes[3], b"\xff")
    day_of_week = get_optional_value(source_bytes[4], b"\xff")
    validate_month(month)
    validate_day(day_of_month)
    validate_weekday(day_of_week)

    return date(year=year, month=month, day=day_of_month)


def time_from_bytes(source_bytes: bytes) -> time:
    """
      Time is represented by 4 bytes.
    [hour, minute, second, hundredths]

    hour: unsigned int (0-23)
        Special case:
            0xFF == not specified.

    minute:  unsigned int (0-59)
        Special cases:
            0xff = not specified.

    second: unsigned int (0-59),
        Special cases:
            0xff = not specified

    hundredths: unsigned in (0-99)
        Special cases:
            0xff = not specifed

    """

    if len(source_bytes) != 4:
        raise ValueError(f"Time is represented by 4 bytes, but got {len(source_bytes)}")

    hour: int = get_optional_value(source_bytes[0], b"\xff", replace_with=0)
    minute: int = get_optional_value(source_bytes[1], b"\xff", replace_with=0)
    seconds: int = get_optional_value(source_bytes[2], b"\xff", replace_with=0)
    hundredths: int = get_optional_value(source_bytes[3], b"\xff", replace_with=0)
    validate_hour(hour)
    validate_minute_or_second(minute)
    validate_minute_or_second(seconds)
    validate_hundredths(hundredths)

    return time(
        hour=hour, minute=minute, second=seconds, microsecond=hundredths * 10000
    )

def get_optional_value(
    value: Union[bytes, int],
    optional_indicator: bytes,
    replace_with: Optional[int] = None,
    signed: bool = False,
) -> Optional[int]:
    if isinstance(value, bytes):
        if value == optional_indicator:
            return replace_with
    else:
        if value == int.from_bytes(optional_indicator, "big", signed=signed):
            return replace_with
    return value

def validate_day(value: Optional[int]):
    if value:
        if value < 1 or value > 31:
            raise ValueError(f"Day can only be within 1-31")


def validate_month(value: Optional[int]):
    if value:
        if value < 1 or value > 12:
            raise ValueError(f"Month can only be within 1-12")


def validate_weekday(value: Optional[int]):
    if value:
        if value < 1 or value > 7:
            raise ValueError(f"Day can only be within 1-7")


def validate_hour(value: Optional[int]):
    if value:
        if value < 0 or value > 23:
            raise ValueError(f"Minutes and seconds can only be within 0-23")


def validate_minute_or_second(value: Optional[int]):
    if value:
        if value < 0 or value > 59:
            raise ValueError(f"Minutes and seconds can only be within 0-59")


def validate_hundredths(value: Optional[int]):
    if value:
        if value < 0 or value > 99:
            raise ValueError(f"Hundredths can only be within 0-99")

def utc_offset_minutes(offset_minutes: Optional[int]) -> Optional[timezone]:
    """
    Big issue in DLMS about timezone.
    The DLMS standard and IDIS standard use the "correct" way of defining the utc offset.
    In the Blue Book 4.1.6.1 the timezone deviation is defined as minutes from local time to UTC.
    NOT deviation from UTC.
    In practice that means we need to negate the offset.
    UTC+01:00 == -60 minutes since you need to subtract 60 minutes to get to UTC.
    UTC-01:00 == +60 minutes since you need to add 60 minutes to get to UTC.

    To make it harder some companion standard is not using the the standard way of
    deviation from localtime but the deviation from UTC.

    # TODO: We need a way to handle different ways of interpretating the timezone offset.

    """
    if offset_minutes:
        return timezone(timedelta(minutes=-offset_minutes))
    else:
        return None




def encode_optional_int(
    value: Optional[int],
    optional_indicator: bytes,
    signed: bool = False,
) -> bytes:
    """
    Inverse of get_optional_value for the 'int' case:

    - If value is None  -> encode as the optional_indicator.
    - Else              -> encode as big-endian on len(optional_indicator) bytes.
    """
    if value is None:
        return optional_indicator

    return int(value).to_bytes(len(optional_indicator), "big", signed=signed)

def date_to_bytes(d: Optional[date]) -> bytes:
    """
    Encode a date into 5 bytes:
      year (2 bytes, 0xFFFF = not specified)
      month (1 byte, 0xFF = not specified)
      day   (1 byte, 0xFF = not specified)
      weekday (1 byte, 0xFF = not specified)

    This mirrors the bytes -> date logic you showed.
    """
    if d is None:
        # fully "unspecified"
        return b"\xff\xff\xff\xff\xff"

    # year / month / day can't be None if we actually have a date
    year_bytes = encode_optional_int(d.year, b"\xff\xff")
    month_byte = encode_optional_int(d.month, b"\xff")
    day_byte = encode_optional_int(d.day, b"\xff")

    # DLMS weekday: 1=Mon..7=Sun (Python isoweekday matches that)
    weekday = d.isoweekday()
    weekday_byte = encode_optional_int(weekday, b"\xff")

    return year_bytes + month_byte + day_byte + weekday_byte



def time_to_bytes(t: time) -> bytes:
    """
    Inverse of time_from_bytes:

    Encodes time as 4 bytes: [hour, minute, second, hundredths]

    - hour:       0–23
    - minute:     0–59
    - second:     0–59
    - hundredths: 0–99 (from microseconds)
    """
    hour = t.hour
    minute = t.minute
    seconds = t.second
    # Convert microseconds back to hundredths (1 hundredth = 10_000 μs)
    hundredths = t.microsecond // 10_000

    validate_hour(hour)
    validate_minute_or_second(minute)
    validate_minute_or_second(seconds)
    validate_hundredths(hundredths)

    return bytes([hour, minute, seconds, hundredths])



def datetime_to_bytes(
    dt: datetime,
    status: Optional["ClockStatus"] = None,
) -> bytes:
    """
    Inverse of datetime_from_bytes.

    Layout (12 bytes total):
    [ date(5), time(4), deviation(2), clock_status(1) ]

    - date:     encoded by date_to_bytes
    - time:     encoded by time_to_bytes
    - deviation: signed int minutes from UTC (-720 < dev < 720),
                 0x8000 means "not specified"
    - clock_status: 1 byte, from ClockStatus.to_bytes()
    """
    # ----- date & time -----
    date_bytes = date_to_bytes(dt.date())          # 5 bytes
    time_bytes = time_to_bytes(dt.timetz())        # 4 bytes (hour, min, sec, hundredths)

    # ----- deviation (timezone offset in minutes) -----
    # If dt is naive or utcoffset() is None -> encode as "not specified" (0x8000)
    deviation: Optional[int]
    if dt.tzinfo is None:
        deviation = None
    else:
        offset = dt.utcoffset()
        if offset is None:
            deviation = None
        else:
            deviation = int(offset.total_seconds() // 60)

    if deviation is not None and not (-720 < deviation < 720):
        raise ValueError(f"Deviation out of range (-720 < dev < 720): {deviation}")

    deviation_bytes = encode_optional_int(
        deviation,
        b"\x80\x00",   # special "not specified"
        signed=True,
    )  # 2 bytes

    # ----- clock status -----
    if status is None:
        # You can choose any convention here; 0x00 is a reasonable default.
        status_bytes = b"\xFF"
    else:
        status_bytes = status.to_bytes()
        if len(status_bytes) != 1:
            raise ValueError("ClockStatus.to_bytes() must return exactly 1 byte")

    return date_bytes + time_bytes + deviation_bytes + status_bytes



