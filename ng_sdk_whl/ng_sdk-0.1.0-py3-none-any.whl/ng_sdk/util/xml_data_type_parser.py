import xml.etree.ElementTree as ET
from datetime import datetime

from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, DLMS_TYPE_REGISTRY
from ng_sdk.frame_builder.dlms.xdlms.data_type.models.clock_status import ClockStatus


def parse_dlms_xml(xml: str) -> AbstractDlmsType:
    root = ET.fromstring(xml)
    return parse_dlms_xml_element(root)


def parse_dlms_xml_element(elem: ET.Element) -> AbstractDlmsType:
    tag = elem.tag  # e.g., "Integer", "Boolean", "Array"
    cls = DLMS_TYPE_REGISTRY.get(tag)
    if cls is None:
        raise ValueError(f"Unknown DLMS type for XML tag: {tag}")
    return cls.from_xml(elem)


def parse_clock_status(line: str):
        # 1) First 19 chars are the datetime: "dd/MM/YYYY HH:MM:SS"
        dt_str = line[:19]
        dt = datetime.strptime(dt_str, "%d/%m/%Y %H:%M:%S")

        # 2) The rest: "invalid: True doubtful: False ..."
        rest = line[19:].strip()
        if rest == "":
            return dt, None
        parts = rest.split()  # ['invalid:', 'True', 'doubtful:', 'False', ...]
        clock_status: ClockStatus = ClockStatus()

        it = iter(parts)
        for label in it:
            value = next(it)  # the boolean string after the label
            key = label.rstrip(":")  # "invalid:" -> "invalid"

            v_lower = value.lower()
            value = False
            if v_lower in ("true", "1"):
                value  = True
            if key == "invalid":
                clock_status.invalid = value
            elif key == "doubtful":
                clock_status.doubtful = value
            elif key == "different_base":
                clock_status.different_base = value
            elif key == "invalid_status":
                clock_status.invalid_status = value
            elif key == "daylight_saving_active":
                clock_status.daylight_saving_active = value

        return dt, clock_status