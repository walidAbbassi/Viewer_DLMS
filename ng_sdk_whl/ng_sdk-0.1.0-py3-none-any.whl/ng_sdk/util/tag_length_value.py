from typing import Union, Tuple

from ng_sdk.util.bytes_util import extract_length, encode_length


class TagLengthValue:


    @staticmethod
    def to_tlv(tag: Union[int, bytes], data: Union[bytearray, bytes]):

        if isinstance(tag, int):
            # Simplification since we now just use ints as tags when they are single
            # bytes.
            _tag_bytes = tag.to_bytes(1, "big")
        else:
            _tag_bytes = tag

        if data is None:
            return b""

        if not isinstance(data, (bytes, bytearray)):
            raise ValueError(
                f"TagLengthValue encoding requires bytes or bytearray, got {data!r} of {type(data)}"
            )

        length = encode_length(len(data))
        return b"".join([_tag_bytes, length, data])




    @staticmethod
    def from_bytes(_bytes: bytes, tag_length: int = 1) -> Tuple[bytes, int, bytes]:
        input_bytearray = bytearray(_bytes)
        tag = b"".join([input_bytearray.pop(0).to_bytes(1, "big") for _ in range(tag_length)])
        length,data = extract_length(input_bytearray)
        if len(data) != length:
            raise ValueError(
                f"BER-decoding failed. Length byte {length} does "
                f"not correspond to length of data {len(data)}"
            )
        return tag, length, data
