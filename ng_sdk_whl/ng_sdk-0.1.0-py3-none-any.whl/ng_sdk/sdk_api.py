"""
High-level API for the DLMS/COSEM NG SDK.

This module provides a simplified interface for common operations:
- Connection management (connect/disconnect)
- DLMS operations (get/set/action)
- Configuration loading
"""
import json
import shutil
import tempfile
from datetime import datetime
from pathlib import Path
# Standard library imports
from typing import Any, Optional, Dict, List

from ng_sdk.api_helpers.core_helpers import CoreHelper, ensure_connected
from ng_sdk.api_helpers.dlms_operations import DLMSOperations
from ng_sdk.api_helpers.dlms_session_manager import DLMSSessionManager
# NG SDK - Configuration modules
from ng_sdk.configuration.config_manager import ConfigManager, ConfigModuleProxy
from ng_sdk.frame_builder.dlms.xdlms.data_type.abstract_dlms_type import AbstractDlmsType, DLMS_TYPE_REGISTRY
from ng_sdk.frame_builder.dlms.xdlms.data_type.dlms_data_factory import DlmsDataFactory
from ng_sdk.frame_builder.dlms.xdlms.data_type.date_time import DateTime
from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_16 import Unsigned16
from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_32 import Unsigned32
from ng_sdk.frame_builder.dlms.xdlms.selective_access.capture_object_definition import CaptureObjectDefinition
from ng_sdk.frame_builder.dlms.xdlms.selective_access.entry_selective_access import EntrySelectiveAccess
from ng_sdk.frame_builder.dlms.xdlms.selective_access.range_selective_access import RangeSelectiveAccess
# NG SDK - Constants and logging
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.push_data_server.push_data_server_manager import PushDataServerManager, PushNotification

logger = get_logger()

__all__ = ['SDKApi']


class SDKApi:
    """
    High-level API for DLMS/COSEM communication.
    
    This class provides a simplified interface for common DLMS operations
    including connection management, configuration loading, and data operations.
    """

    def __init__(self):
        """Initialize the SDK API with simplified components."""
        # Core components  
        self._config_manager: Optional[ConfigManager] = None
        self._dlms_operations: Optional[DLMSOperations] = None

        # Use dedicated session manager to handle complexity
        self._session_manager = DLMSSessionManager()

        # Error handling configuration
        self._raise_unknown_errors = False

        self._mod = {LoggingConstants.MODULES_NAME: "SDKApi"}  # module tag for logs
        self._push_server_manager: Optional[PushDataServerManager] = None

    def set_error_handling_mode(self, raise_unknown_errors: bool = False) -> None:
        """
        Configure error handling behavior.
        
        Args:
            raise_unknown_errors: If True, raise exceptions for error codes not found in auto_tools.json5
        """
        self._raise_unknown_errors = raise_unknown_errors

    @staticmethod
    def _extract_structure_field_names(dlms_type: Any) -> Optional[List[str]]:
        if not isinstance(dlms_type, dict):
            return None

        dlms_kind = str(dlms_type.get("type", "")).lower()
        fields = dlms_type.get("fields")

        if dlms_kind == "structure" and isinstance(fields, list):
            names: List[str] = []
            for index, field_def in enumerate(fields):
                if isinstance(field_def, dict):
                    names.append(str(field_def.get("name") or f"key{index}"))
                else:
                    names.append(f"key{index}")
            return names or None

        if isinstance(fields, dict):
            return SDKApi._extract_structure_field_names(fields)

        return None

    def _get_datamodel_field_names(self, object_name: str, attribute_name: str) -> Optional[List[str]]:
        if self._config_manager is None:
            return None

        try:
            data_model = self._config_manager.datamodel[object_name]
            if data_model is None:
                return None

            for attr in getattr(data_model, "dlmsAttribute", []):
                if attr.get("name") == attribute_name:
                    return self._extract_structure_field_names(attr.get("dlmsType"))
        except Exception as e:
            logger.debug(f"Could not resolve field names for '{object_name}.{attribute_name}': {e}", **self._mod)
            return None

        return None

    def _get_datamodel_field_names_by_obis(self, obis_code: str, attribute_id: int) -> Optional[List[str]]:
        """Look up structure field names from the datamodel using OBIS code and attribute ID."""
        if self._config_manager is None:
            return None

        try:
            obis_upper = obis_code.upper()
            datamodel_dict = self._config_manager._load_module("datamodel")
            if not isinstance(datamodel_dict, dict):
                return None

            for obj_data in datamodel_dict.values():
                if not isinstance(obj_data, dict):
                    continue
                if str(obj_data.get("logicalName_hex", "")).upper() != obis_upper:
                    continue
                for attr in obj_data.get("dlmsAttribute", []):
                    if int(attr.get("id", -1)) == attribute_id:
                        return self._extract_structure_field_names(attr.get("dlmsType"))
                break  # found the right object, no need to continue
        except Exception as e:
            logger.debug(f"Could not resolve field names for obis='{obis_code}' attr_id={attribute_id}: {e}", **self._mod)
            return None

        return None

    def load_configuration(self, config_dir: str) -> None:
        """
        Load configuration from the specified directory.
        
        Args:
            config_dir: Path to the configuration directory containing JSON5 files
            
        Raises:
            FileNotFoundError: If configuration files are not found
            ValueError: If configuration is invalid
        """
        logger.info(f"Loading configuration from: {config_dir}",
                    **self._mod)

        try:
            self._config_manager = ConfigManager(config_dir)

            logger.trace("Configuration loaded successfully",
                        **self._mod)

        except (FileNotFoundError, ValueError, OSError) as e:
            logger.error(f"Failed to load configuration: {e}",
                         **self._mod)
            raise

    def connect(self, client_name: str) -> None:
        """
        Establish connection to the DLMS device.

        Args:
            client_name: Name of the client configuration to use (default: "LocalAdmin")

        Raises:
            RuntimeError: If configuration is not loaded or connection fails
        """
        # Delegate to the session manager
        self._session_manager.connect(self._config_manager, client_name)
        if self._session_manager.frame_executor.configuration.communication.keep_connection.enabled:
            self._session_manager.frame_executor.start_keepalive()
        # Initialize DLMS operations using the session manager's components
        config_dir = self._config_manager._config_dir if self._config_manager else None
        self._dlms_operations = DLMSOperations(self._session_manager.frame_executor, config_dir)

    def disconnect(self) -> None:
        """
        Close the connection to the DLMS device.
        
        Raises:
            RuntimeError: If not connected
        """
        if self._session_manager.frame_executor.configuration.communication.keep_connection.enabled:
            self._session_manager.frame_executor.stop_keepalive()
        # Delegate to session manager
        self._session_manager.disconnect()

        # Clear DLMS operations instance
        self._dlms_operations = None

    def enable_keep_connect(self) -> None:
        """Enable keep connection and start keepalive mechanism."""
        ensure_connected(self._session_manager.is_connected)

        frame_executor = self._session_manager.frame_executor
        if frame_executor is None:
            raise RuntimeError("Frame executor not initialized. Call connect() first.")

        frame_executor.configuration.communication.keep_connection.enabled = True
        frame_executor.start_keepalive()

    def disable_keep_connect(self) -> None:
        """Disable keep connection and stop keepalive mechanism."""
        ensure_connected(self._session_manager.is_connected)

        frame_executor = self._session_manager.frame_executor
        if frame_executor is None:
            raise RuntimeError("Frame executor not initialized. Call connect() first.")

        frame_executor.configuration.communication.keep_connection.enabled = False
        frame_executor.stop_keepalive()

    def get_raw_object_by_obis(self, class_id: int, obis_code: str, attribute_id: int,
                               raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS GET operation to read an attribute value (raw, no data parsing).
        
        This method returns the raw hex data without interpreting the DLMS structure.
        Use ``get_object_by_name`` or ``get_objects_with_list_by_name`` if you need
        parsed ``readable_data`` with named fields.
        
        Args:
            class_id: COSEM class ID of the object
            obis_code: OBIS code identifying the object (e.g., "0100630200FF")
            attribute_id: Attribute ID to read
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)
            
        Returns:
            Dictionary containing:
            - success: bool - True if operation succeeded
            - error_code: int - Error code (0 for success)
            - error_description: str - Description of error or success status
            - raw_data: str - Raw hex string of the response
            
        Raises:
            RuntimeError: If not connected
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        # Use SDK-level setting if not specified
        use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
        # Raw function: no field_names resolution, no data parsing
        result_dict = self._dlms_operations.get(class_id, obis_code, attribute_id,
                                                raise_unknown_errors=use_raise_errors)
        # Raw function: value = raw_data, remove readable_data
        result_dict.pop('readable_data', None)
        result_dict['value'] = result_dict.pop('raw_data', None)
        return result_dict

    def _get_object_by_name_common(self, object_name: str, attribute_name: str, raise_unknown_errors: Optional[bool] = None):
        """
        Internal helper to resolve class_id, obis_code, attribute_id and call self._dlms_operations.get()
        **with** field_names resolution (parsed readable_data).
        Returns the tuple (class_id, obis_code, attribute_id, get_result).
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")
        try:
            class_id, obis_code, attribute_id, _ = CoreHelper.get_object_metadata_and_attribute_id(
                self._config_manager, object_name, attribute_name)
            logger.info(
                f"GET operation by name: object='{object_name}', attribute='{attribute_name}', class_id={class_id}, obis={obis_code}, attr_id={attribute_id}",
                **self._mod)
            use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
            field_names = self._get_datamodel_field_names(object_name, attribute_name)
            get_result = self._dlms_operations.get(class_id, obis_code, attribute_id,
                                                   raise_unknown_errors=use_raise_errors,
                                                   field_names=field_names)
            return class_id, obis_code, attribute_id, get_result
        except Exception as e:
            logger.error(f"GET operation by name failed: {e}", **self._mod)
            raise

    def _get_raw_object_by_name_common(self, object_name: str, attribute_name: str, raise_unknown_errors: Optional[bool] = None):
        """
        Internal helper to resolve class_id, obis_code, attribute_id and call self._dlms_operations.get()
        **without** field_names resolution (raw, no data parsing).
        Returns the tuple (class_id, obis_code, attribute_id, get_result).
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")
        try:
            class_id, obis_code, attribute_id, _ = CoreHelper.get_object_metadata_and_attribute_id(
                self._config_manager, object_name, attribute_name)
            logger.info(
                f"GET RAW operation by name: object='{object_name}', attribute='{attribute_name}', class_id={class_id}, obis={obis_code}, attr_id={attribute_id}",
                **self._mod)
            use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
            # Raw: no field_names resolution, no data parsing
            get_result = self._dlms_operations.get(class_id, obis_code, attribute_id,
                                                   raise_unknown_errors=use_raise_errors)
            return class_id, obis_code, attribute_id, get_result
        except Exception as e:
            logger.error(f"GET RAW operation by name failed: {e}", **self._mod)
            raise

    def get_raw_object_by_name(self, object_name: str, attribute_name: str,
                               raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """Perform a DLMS GET operation using object and attribute names (raw, no data parsing).

        This method returns the raw hex data without interpreting the DLMS structure.
        Use ``get_object_by_name`` if you need parsed ``readable_data`` with named fields.
        """
        _, _, _, result_dict = self._get_raw_object_by_name_common(object_name, attribute_name, raise_unknown_errors)
        # Raw function: value = raw_data, remove readable_data
        result_dict.pop('readable_data', None)
        result_dict['value'] = result_dict.pop('raw_data', None)
        # Add names into communication_details.request alongside obis_code/attribute_id
        if "communication_details" in result_dict and "request" in result_dict["communication_details"]:
            result_dict["communication_details"]["request"]["object_name"] = object_name
            result_dict["communication_details"]["request"]["attribute_name"] = attribute_name
        return result_dict

    def get_object_by_name(self, object_name: str, attribute_name: str,
                           raise_unknown_errors: Optional[bool] = None) -> dict:
        """
        Perform a DLMS GET operation to read an attribute value using object and attribute names.

        Behavior:
        - Calls ``_dlms_operations.get`` with field name resolution when available.
        - Moves ``readable_data`` into ``value`` and removes ``raw_data`` for a user-friendly result.
        - Adds ``object_name`` / ``attribute_name`` into ``communication_details.request`` when present.

        Args:
            object_name: Name of the COSEM object (e.g., "CosemDataProtection")
            attribute_name: Name of the attribute to read (e.g., "logical_name")
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)
            
        Returns:
            Result dictionary where ``value`` contains the parsed readable data and ``raw_data`` is removed.

        Raises:
            RuntimeError: If not connected or object/attribute not found
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
        """
        _, _, _, get_result = self._get_object_by_name_common(object_name, attribute_name, raise_unknown_errors)
        # Object function: value = readable_data, remove raw_data
        get_result.pop('raw_data', None)
        get_result['value'] = get_result.pop('readable_data', None)
        # Add names into communication_details.request alongside obis_code/attribute_id
        if "communication_details" in get_result and "request" in get_result["communication_details"]:
            get_result["communication_details"]["request"]["object_name"] = object_name
            get_result["communication_details"]["request"]["attribute_name"] = attribute_name
        return get_result

    @staticmethod
    def _coerce_range_value(val, label: str) -> AbstractDlmsType:
        """Convert *val* to an :class:`AbstractDlmsType` suitable for
        :class:`RangeSelectiveAccess`.

        Accepted inputs:
        - ``datetime``  → wrapped into ``DateTime(value=(val, None)).to_octet_string()``
        - ``AbstractDlmsType`` subclass (OctetStringData, Integer32, Unsigned32,
          Integer64, Unsigned64, Float32, Float64, DateTime, Date, Time, …)
          → used as-is.

        Raises:
            TypeError: When *val* is not one of the accepted types.
        """
        if isinstance(val, datetime):
            return DateTime(value=(val, None)).to_octet_string()
        if isinstance(val, AbstractDlmsType):
            return val
        raise TypeError(
            f"{label} must be a datetime or an AbstractDlmsType instance "
            f"(e.g. OctetStringData, Integer32, Unsigned32, DateTime, …), "
            f"got {type(val).__name__}"
        )

    def get_by_name_by_range(self, object_name: str, attribute_name: str,
                             from_value, to_value,
                             restricting_object: Optional[Dict[str, Any]] = None,
                             selected_values: Optional[List[Dict[str, Any]]] = None,
                             raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS GET operation with Range Selective Access (access selector 1)
        using object and attribute names.

        Reads all buffer entries whose restricting value lies between
        ``from_value`` and ``to_value``.  This is typically used on profile
        objects (class_id 7) to retrieve a bounded slice of their buffer.

        ``from_value`` and ``to_value`` can be:

        * A plain ``datetime`` — automatically converted to a DLMS
          *octet-string* (date-time encoding).
        * Any ``AbstractDlmsType`` subclass matching the restricting object's
          value type (e.g. ``Integer32``, ``Unsigned32``, ``Integer64``,
          ``Unsigned64``, ``OctetStringData``, ``Float32``, ``Float64``,
          ``DateTime``, ``Date``, ``Time``, ``VisibleString``, ``Utf8String``).

        Args:
            object_name: Name of the COSEM object (e.g. ``"LoadProfile1"``)
            attribute_name: Name of the attribute to read (e.g. ``"buffer"``)
            from_value: Start of the range — oldest / smallest entry to retrieve
                (``datetime`` or ``AbstractDlmsType``)
            to_value: End of the range — newest / largest entry to retrieve
                (``datetime`` or ``AbstractDlmsType``)
            restricting_object: Optional dictionary defining the capture object
                that restricts the range.  Keys:
                    - class_id: int   (e.g. 8 for Clock)
                    - obis_code: str  (e.g. ``"0000010000FF"``)
                    - attribute_index: int (e.g. 2)
                    - data_index: int (e.g. 0)
                If ``None``, defaults to the standard Clock object
                ``{class_id=8, obis_code="0000010000FF", attribute_index=2, data_index=0}``.
            selected_values: Optional list of dictionaries specifying which
                columns (capture objects) to retrieve.  Each dictionary has the
                same keys as *restricting_object*.  If empty or ``None``, all
                captured data is returned.
            raise_unknown_errors: Whether to raise exceptions for unknown errors
                (uses default if ``None``)

        Returns:
            Dictionary containing:
            - success: bool
            - value: parsed readable data or None
            - error_code: int
            - error_description: str

        Raises:
            RuntimeError: If not connected or object/attribute not found
            TypeError: If ``from_value`` or ``to_value`` is neither a
                ``datetime`` nor an ``AbstractDlmsType``
            FrameExecutorException: If the operation fails and
                *raise_unknown_errors* is ``True``

        Example:
            >>> from datetime import datetime, timedelta
            >>> now = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            >>> result = api.get_by_name_by_range(
            ...     "LoadProfile1", "buffer",
            ...     from_value=now,
            ...     to_value=now + timedelta(days=1),
            ... )
            >>> if result["success"]:
            ...     print(result["value"])
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        # Coerce from_value / to_value into AbstractDlmsType
        dlms_from = self._coerce_range_value(from_value, "from_value")
        dlms_to = self._coerce_range_value(to_value, "to_value")

        logger.info(
            f"GET by range: object='{object_name}', attribute='{attribute_name}', "
            f"from_type={type(from_value).__name__}, to_type={type(to_value).__name__}",
            **self._mod,
        )

        try:
            # Resolve object/attribute names
            class_id, obis_code, attribute_id, _ = CoreHelper.get_object_metadata_and_attribute_id(
                self._config_manager, object_name, attribute_name
            )

            logger.info(
                f"GET by range resolved: class_id={class_id}, obis={obis_code}, attr_id={attribute_id}",
                **self._mod,
            )

            # Build restricting_object (default: Clock 0.0.1.0.0.255 attr 2)
            if restricting_object is not None:
                ro = CaptureObjectDefinition(
                    class_id=restricting_object["class_id"],
                    logical_name=bytes.fromhex(restricting_object["obis_code"]),
                    attribute_index=restricting_object["attribute_index"],
                    data_index=restricting_object["data_index"],
                )
            else:
                ro = CaptureObjectDefinition(
                    class_id=8,
                    logical_name=bytes.fromhex("0000010000FF"),
                    attribute_index=2,
                    data_index=0,
                )

            # Build selected_values list
            sv: List[CaptureObjectDefinition] = []
            if selected_values:
                for col in selected_values:
                    sv.append(CaptureObjectDefinition(
                        class_id=col["class_id"],
                        logical_name=bytes.fromhex(col["obis_code"]),
                        attribute_index=col["attribute_index"],
                        data_index=col["data_index"],
                    ))

            # Build RangeSelectiveAccess
            range_sa = RangeSelectiveAccess(
                from_value=dlms_from,
                to_value=dlms_to,
                restricting_object=ro,
                selected_values=sv,
            )

            # Execute with selective access
            use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
            field_names = self._get_datamodel_field_names(object_name, attribute_name)
            result = self._dlms_operations.get(
                class_id, obis_code, attribute_id,
                raise_unknown_errors=use_raise_errors,
                field_names=field_names,
                selective_access=range_sa,
            )

            if result.get("success"):
                logger.info("GET by range completed successfully", **self._mod)
            else:
                logger.warning(f"GET by range failed: {result.get('error_description')}", **self._mod)

            # Object function: value = readable_data, remove raw_data
            result.pop('raw_data', None)
            result['value'] = result.pop('readable_data', None)
            # Add names into communication_details.request alongside obis_code/attribute_id
            if "communication_details" in result and "request" in result["communication_details"]:
                result["communication_details"]["request"]["object_name"] = object_name
                result["communication_details"]["request"]["attribute_name"] = attribute_name
            return result

        except Exception as e:
            logger.error(f"GET by range failed: {e}", **self._mod)
            raise

    def get_by_name_by_entry(self, object_name: str, attribute_name: str,
                             from_entry: int = 1, to_entry: int = 0,
                             from_selected_value: int = 1, to_selected_value: int = 0,
                             raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS GET operation with Entry Selective Access (access selector 2)
        using object and attribute names.

        Reads buffer entries between ``from_entry`` and ``to_entry``, and only
        the columns between ``from_selected_value`` and ``to_selected_value``.

        Args:
            object_name: Name of the COSEM object (e.g. ``"LoadProfile1"``)
            attribute_name: Name of the attribute to read (e.g. ``"buffer"``)
            from_entry: First entry (row) to retrieve (1-based). Default ``1``.
            to_entry: Last entry to retrieve.  ``0`` means the highest possible
                entry (i.e. up to the most recent). Default ``0``.
            from_selected_value: Index of the first column to retrieve (1-based).
                Default ``1``.
            to_selected_value: Index of the last column to retrieve.  ``0`` means
                the highest possible column. Default ``0``.
            raise_unknown_errors: Whether to raise exceptions for unknown errors
                (uses default if ``None``)

        Returns:
            Dictionary containing:
            - success: bool
            - value: parsed readable data or None
            - error_code: int
            - error_description: str

        Raises:
            RuntimeError: If not connected or object/attribute not found
            ValueError: If ``from_entry`` is negative
            FrameExecutorException: If the operation fails and
                *raise_unknown_errors* is ``True``

        Example:
            >>> # Read the last 10 entries, all columns
            >>> result = api.get_by_name_by_entry(
            ...     "LoadProfile1", "buffer",
            ...     from_entry=1, to_entry=10,
            ... )
            >>> if result["success"]:
            ...     print(result["value"])
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        if from_entry < 0:
            raise ValueError(f"from_entry must be >= 0, got {from_entry}")

        logger.info(
            f"GET by entry: object='{object_name}', attribute='{attribute_name}', "
            f"from_entry={from_entry}, to_entry={to_entry}, "
            f"from_selected_value={from_selected_value}, to_selected_value={to_selected_value}",
            **self._mod,
        )

        try:
            # Resolve object/attribute names
            class_id, obis_code, attribute_id, _ = CoreHelper.get_object_metadata_and_attribute_id(
                self._config_manager, object_name, attribute_name
            )

            logger.info(
                f"GET by entry resolved: class_id={class_id}, obis={obis_code}, attr_id={attribute_id}",
                **self._mod,
            )

            # Build EntrySelectiveAccess
            entry_sa = EntrySelectiveAccess(
                from_value=Unsigned32(value=from_entry),
                to_value=Unsigned32(value=to_entry),
                from_selected_value=Unsigned16(value=from_selected_value),
                to_selected_value=Unsigned16(value=to_selected_value),
            )

            # Execute with selective access
            use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
            field_names = self._get_datamodel_field_names(object_name, attribute_name)
            result = self._dlms_operations.get(
                class_id, obis_code, attribute_id,
                raise_unknown_errors=use_raise_errors,
                field_names=field_names,
                selective_access=entry_sa,
            )

            if result.get("success"):
                logger.info("GET by entry completed successfully", **self._mod)
            else:
                logger.warning(f"GET by entry failed: {result.get('error_description')}", **self._mod)

            # Object function: value = readable_data, remove raw_data
            result.pop('raw_data', None)
            result['value'] = result.pop('readable_data', None)
            # Add names into communication_details.request alongside obis_code/attribute_id
            if "communication_details" in result and "request" in result["communication_details"]:
                result["communication_details"]["request"]["object_name"] = object_name
                result["communication_details"]["request"]["attribute_name"] = attribute_name
            return result

        except Exception as e:
            logger.error(f"GET by entry failed: {e}", **self._mod)
            raise

    def get_objects_with_list(self, objects_list: List[Dict[str, Any]],
                             raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS GET-WITH-LIST operation to read multiple attributes in a single request.
        
        This method is more efficient than multiple individual GET operations when reading
        several attributes, as it sends all requests in a single DLMS frame.
        
        Args:
            objects_list: List of dictionaries, each containing:
                - class_id: int - COSEM class ID
                - obis_code: str - OBIS code string (e.g., "0100010700FF")
                - attribute_id: int - Attribute ID
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)
            
        Returns:
            Dictionary containing:
            {
                "success": bool - True if all operations succeeded, False if any failed
                "results": [ - List of individual results in the same order as requests
                    {
                        "success": bool,
                        "value": str (hex) or None,
                        "error_code": int,
                        "error_description": str,
                        "raw_data": object or None
                    },
                    ...
                ],
                "total_requested": int - Total number of objects requested
                "successful_count": int - Number of successful reads
                "failed_count": int - Number of failed reads
                "frame_details": {...} - Frame transmission details
            }
            
        Raises:
            RuntimeError: If not connected
            ValueError: If objects_list is empty or contains invalid entries
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
            
        Example:
            >>> objects = [
            ...     {"class_id": 1, "obis_code": "0000010000FF", "attribute_id": 2},
            ...     {"class_id": 3, "obis_code": "0100010700FF", "attribute_id": 2},
            ...     {"class_id": 7, "obis_code": "0000600100FF", "attribute_id": 2}
            ... ]
            >>> result = api.get_objects_with_list(objects)
            >>> if result["success"]:
            ...     for idx, res in enumerate(result["results"]):
            ...         print(f"Object {idx}: {res['value']}")
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        if not objects_list:
            raise ValueError("objects_list cannot be empty")

        # Use SDK-level setting if not specified
        use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
        
        # Auto-resolve field_names from the datamodel for each object that doesn't already have them
        for obj in objects_list:
            if "field_names" not in obj:
                obis_code = obj.get("obis_code", "")
                attribute_id = obj.get("attribute_id")
                if obis_code and attribute_id is not None:
                    obj["field_names"] = self._get_datamodel_field_names_by_obis(
                        str(obis_code), int(attribute_id)
                    )
        
        return self._dlms_operations.get_with_list(objects_list, raise_unknown_errors=use_raise_errors)

    def get_objects_with_list_by_name(self, objects_names_list: List[List[str]],
                                      raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS GET-WITH-LIST operation using object and attribute names.
        
        This method resolves object and attribute names to COSEM identifiers and then
        performs a bulk read operation in a single DLMS request.
        
        Args:
            objects_names_list: List of [object_name, attribute_name] pairs, e.g.:
                [
                    ['AccumulatedErrorFlagsChannel1', 'value'],
                    ['AverageCurrentL1', 'scaler_unit'],
                    ['Clock', 'time_zone']
                ]
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)
            
        Returns:
            Dictionary containing:
            {
                "success": bool - True if all operations succeeded
                "results": [...] - List of individual results
                "total_requested": int - Total number of objects requested
                "successful_count": int - Number of successful reads
                "failed_count": int - Number of failed reads
                "result_tuple": tuple - (success_global, [raw_values])
                "objects_list": list - [[class_id, obis_code, attribute_id], ...]
                "objects_names": list - Original names [[object_name, attribute_name], ...]
                "frame_details": {...} - Frame transmission details
            }
            
        Raises:
            RuntimeError: If not connected or object/attribute not found in configuration
            ValueError: If objects_names_list is empty or contains invalid entries
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
            
        Example:
            >>> objects_names = [
            ...     ['AccumulatedErrorFlagsChannel1', 'value'],
            ...     ['AverageCurrentL1', 'scaler_unit'],
            ...     ['Clock', 'time_zone']
            ... ]
            >>> result = api.get_objects_with_list_by_name(objects_names)
            >>> if result["success"]:
            ...     for idx, (names, res) in enumerate(zip(objects_names, result["results"])):
            ...         print(f"{names[0]}.{names[1]}: {res['value']}")
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")
        
        if not objects_names_list:
            raise ValueError("objects_names_list cannot be empty")
        
        logger.info(f"GET-WITH-LIST operation by name: {len(objects_names_list)} objects requested", **self._mod)
        
        # Resolve each object/attribute name to class_id, obis_code, attribute_id
        resolved_objects = self._resolve_objects_names(objects_names_list)
        
        # Call get_objects_with_list with resolved objects
        logger.info("All objects resolved, executing GET-WITH-LIST...", **self._mod)
        result = self.get_objects_with_list(resolved_objects, raise_unknown_errors)
        
        self._enrich_objects_list(result, objects_names_list)
        
        logger.info(
            f"GET-WITH-LIST by name completed: {result['successful_count']}/{result['total_requested']} successful",
            **self._mod
        )
        
        return result

    # ------------------------------------------------------------------
    #  GET-WITH-LIST + Selective Access
    # ------------------------------------------------------------------

    def get_with_list_by_name_by_range(self, objects_names_list: List[List[str]],
                                       from_value, to_value,
                                       restricting_object: Optional[Dict[str, Any]] = None,
                                       selected_values: Optional[List[Dict[str, Any]]] = None,
                                       raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS GET-WITH-LIST operation with Range Selective Access (access selector 1)
        using object and attribute names.

        Reads all buffer entries whose restricting value lies between
        ``from_value`` and ``to_value`` for **every** object/attribute pair
        in the list.  This is typically used on profile objects (class_id 7)
        to retrieve a bounded slice of their buffers in a single request.

        ``from_value`` and ``to_value`` can be:

        * A plain ``datetime`` — automatically converted to a DLMS
          *octet-string* (date-time encoding).
        * Any ``AbstractDlmsType`` subclass matching the restricting object's
          value type.

        Args:
            objects_names_list: List of [object_name, attribute_name] pairs, e.g.:
                [
                    ['LoadProfilewithperiode1', 'buffer'],
                    ['LoadProfilewithperiode2', 'buffer'],
                ]
            from_value: Start of the range (``datetime`` or ``AbstractDlmsType``)
            to_value: End of the range (``datetime`` or ``AbstractDlmsType``)
            restricting_object: Optional dictionary defining the capture object
                that restricts the range.  Keys: class_id, obis_code,
                attribute_index, data_index.
                If ``None``, defaults to the standard Clock object.
            selected_values: Optional list of capture object dictionaries
                specifying which columns to retrieve.
            raise_unknown_errors: Whether to raise exceptions for unknown errors
                (uses default if ``None``)

        Returns:
            Dictionary containing:
            {
                "success": bool,
                "results": [...],
                "total_requested": int,
                "successful_count": int,
                "failed_count": int,
                "objects_names": [[object_name, attribute_name], ...],
                "frame_details": {...}
            }

        Raises:
            RuntimeError: If not connected or object/attribute not found
            TypeError: If ``from_value`` or ``to_value`` is neither a
                ``datetime`` nor an ``AbstractDlmsType``
            ValueError: If objects_names_list is empty or contains invalid entries
            FrameExecutorException: If the operation fails and
                *raise_unknown_errors* is ``True``

        Example:
            >>> from datetime import datetime, timedelta
            >>> now = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            >>> result = api.get_with_list_by_name_by_range(
            ...     [['LoadProfilewithperiode1', 'buffer'],
            ...      ['LoadProfilewithperiode2', 'buffer']],
            ...     from_value=now,
            ...     to_value=now + timedelta(days=1),
            ... )
            >>> if result["success"]:
            ...     for names, res in zip(result["objects_names"], result["results"]):
            ...         print(f"{names[0]}.{names[1]}: {res['value']}")
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        if not objects_names_list:
            raise ValueError("objects_names_list cannot be empty")

        # Coerce from_value / to_value into AbstractDlmsType
        dlms_from = self._coerce_range_value(from_value, "from_value")
        dlms_to = self._coerce_range_value(to_value, "to_value")

        logger.info(
            f"GET-WITH-LIST by range: {len(objects_names_list)} objects, "
            f"from_type={type(from_value).__name__}, to_type={type(to_value).__name__}",
            **self._mod,
        )

        try:
            # Resolve all object/attribute names
            resolved_objects = self._resolve_objects_names(objects_names_list)

            # Build restricting_object (default: Clock 0.0.1.0.0.255 attr 2)
            if restricting_object is not None:
                ro = CaptureObjectDefinition(
                    class_id=restricting_object["class_id"],
                    logical_name=bytes.fromhex(restricting_object["obis_code"]),
                    attribute_index=restricting_object["attribute_index"],
                    data_index=restricting_object["data_index"],
                )
            else:
                ro = CaptureObjectDefinition(
                    class_id=8,
                    logical_name=bytes.fromhex("0000010000FF"),
                    attribute_index=2,
                    data_index=0,
                )

            # Build selected_values list
            sv: List[CaptureObjectDefinition] = []
            if selected_values:
                for col in selected_values:
                    sv.append(CaptureObjectDefinition(
                        class_id=col["class_id"],
                        logical_name=bytes.fromhex(col["obis_code"]),
                        attribute_index=col["attribute_index"],
                        data_index=col["data_index"],
                    ))

            # Build RangeSelectiveAccess
            range_sa = RangeSelectiveAccess(
                from_value=dlms_from,
                to_value=dlms_to,
                restricting_object=ro,
                selected_values=sv,
            )

            # Execute GET-WITH-LIST with selective access
            use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
            result = self._dlms_operations.get_with_list(
                resolved_objects,
                raise_unknown_errors=use_raise_errors,
                selective_access=range_sa,
            )

            self._enrich_objects_list(result, objects_names_list)

            if result.get("success"):
                logger.info(
                    f"GET-WITH-LIST by range completed: "
                    f"{result['successful_count']}/{result['total_requested']} successful",
                    **self._mod,
                )
            else:
                logger.warning(
                    f"GET-WITH-LIST by range completed with errors: "
                    f"{result['successful_count']}/{result['total_requested']} successful",
                    **self._mod,
                )

            return result

        except Exception as e:
            logger.error(f"GET-WITH-LIST by range failed: {e}", **self._mod)
            raise

    def get_with_list_by_name_by_entry(self, objects_names_list: List[List[str]],
                                        from_entry: int = 1, to_entry: int = 0,
                                        from_selected_value: int = 1, to_selected_value: int = 0,
                                        raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS GET-WITH-LIST operation with Entry Selective Access (access selector 2)
        using object and attribute names.

        Reads buffer entries between ``from_entry`` and ``to_entry``, and only
        the columns between ``from_selected_value`` and ``to_selected_value``
        for **every** object/attribute pair in the list.

        Args:
            objects_names_list: List of [object_name, attribute_name] pairs, e.g.:
                [
                    ['LoadProfilewithperiode1', 'buffer'],
                    ['LoadProfilewithperiode2', 'buffer'],
                ]
            from_entry: First entry (row) to retrieve (1-based). Default ``1``.
            to_entry: Last entry to retrieve.  ``0`` means the highest possible
                entry. Default ``0``.
            from_selected_value: Index of the first column (1-based). Default ``1``.
            to_selected_value: Index of the last column.  ``0`` means the highest
                possible column. Default ``0``.
            raise_unknown_errors: Whether to raise exceptions for unknown errors
                (uses default if ``None``)

        Returns:
            Dictionary containing:
            {
                "success": bool,
                "results": [...],
                "total_requested": int,
                "successful_count": int,
                "failed_count": int,
                "objects_names": [[object_name, attribute_name], ...],
                "frame_details": {...}
            }

        Raises:
            RuntimeError: If not connected or object/attribute not found
            ValueError: If objects_names_list is empty, contains invalid entries,
                or ``from_entry`` is negative
            FrameExecutorException: If the operation fails and
                *raise_unknown_errors* is ``True``

        Example:
            >>> result = api.get_with_list_by_name_by_entry(
            ...     [['LoadProfilewithperiode1', 'buffer'],
            ...      ['LoadProfilewithperiode2', 'buffer']],
            ...     from_entry=1, to_entry=10,
            ... )
            >>> if result["success"]:
            ...     for names, res in zip(result["objects_names"], result["results"]):
            ...         print(f"{names[0]}.{names[1]}: {res['value']}")
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        if not objects_names_list:
            raise ValueError("objects_names_list cannot be empty")

        if from_entry < 0:
            raise ValueError(f"from_entry must be >= 0, got {from_entry}")

        logger.info(
            f"GET-WITH-LIST by entry: {len(objects_names_list)} objects, "
            f"from_entry={from_entry}, to_entry={to_entry}, "
            f"from_selected_value={from_selected_value}, to_selected_value={to_selected_value}",
            **self._mod,
        )

        try:
            # Resolve all object/attribute names
            resolved_objects = self._resolve_objects_names(objects_names_list)

            # Build EntrySelectiveAccess
            entry_sa = EntrySelectiveAccess(
                from_value=Unsigned32(value=from_entry),
                to_value=Unsigned32(value=to_entry),
                from_selected_value=Unsigned16(value=from_selected_value),
                to_selected_value=Unsigned16(value=to_selected_value),
            )

            # Execute GET-WITH-LIST with selective access
            use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
            result = self._dlms_operations.get_with_list(
                resolved_objects,
                raise_unknown_errors=use_raise_errors,
                selective_access=entry_sa,
            )

            self._enrich_objects_list(result, objects_names_list)

            if result.get("success"):
                logger.info(
                    f"GET-WITH-LIST by entry completed: "
                    f"{result['successful_count']}/{result['total_requested']} successful",
                    **self._mod,
                )
            else:
                logger.warning(
                    f"GET-WITH-LIST by entry completed with errors: "
                    f"{result['successful_count']}/{result['total_requested']} successful",
                    **self._mod,
                )

            return result

        except Exception as e:
            logger.error(f"GET-WITH-LIST by entry failed: {e}", **self._mod)
            raise

    def _resolve_objects_names(self, objects_names_list: List[List[str]]) -> List[Dict[str, Any]]:
        """Resolve a list of [object_name, attribute_name] pairs to COSEM identifiers.

        Returns a list of dictionaries suitable for ``get_with_list`` / ``get_objects_with_list``.
        """
        resolved_objects = []
        for idx, name_pair in enumerate(objects_names_list):
            if not isinstance(name_pair, (list, tuple)) or len(name_pair) != 2:
                raise ValueError(
                    f"Invalid entry at index {idx}: {name_pair}. "
                    f"Expected [object_name, attribute_name]"
                )

            object_name, attribute_name = name_pair
            logger.trace(f"  [{idx + 1}] Resolving {object_name}.{attribute_name}", **self._mod)

            try:
                class_id, obis_code, attribute_id, _ = CoreHelper.get_object_metadata_and_attribute_id(
                    self._config_manager, object_name, attribute_name
                )

                resolved_objects.append({
                    "class_id": class_id,
                    "obis_code": obis_code,
                    "attribute_id": attribute_id,
                    "field_names": self._get_datamodel_field_names(object_name, attribute_name),
                })

                logger.trace(
                    f"  [{idx + 1}] Resolved: class_id={class_id}, obis={obis_code}, attr_id={attribute_id}",
                    **self._mod,
                )
            except Exception as e:
                logger.error(
                    f"Failed to resolve object '{object_name}', attribute '{attribute_name}': {e}",
                    **self._mod,
                )
                raise RuntimeError(
                    f"Cannot resolve object '{object_name}', attribute '{attribute_name}': {e}"
                ) from e

        return resolved_objects

    def _enrich_objects_list(self, result: Dict, objects_names_list: List,
                             id_key: str = "attribute_id",
                             name_keys: Optional[List[tuple]] = None) -> None:
        """Enrich objects_list in communication_details with name information.

        Args:
            result: The result dict returned by a list operation.
            objects_names_list: The original list of name pairs/triplets.
            id_key: The key name for the third element of each raw entry
                    (e.g. 'attribute_id' or 'method_id').
            name_keys: List of (entry_key, index) tuples specifying how to map
                       names from objects_names_list entries.
                       Defaults to [('object_name', 0), ('attribute_name', 1)].
        """
        if name_keys is None:
            name_keys = [("object_name", 0), ("attribute_name", 1)]
        if "communication_details" not in result:
            result["communication_details"] = {}
        enriched = []
        raw_list = result["communication_details"].get("objects_list", [])
        for i in range(max(len(raw_list), len(objects_names_list))):
            entry = {}
            if i < len(raw_list):
                raw = raw_list[i]
                entry["class_id"] = raw[0] if len(raw) > 0 else None
                entry["obis_code"] = raw[1] if len(raw) > 1 else None
                entry[id_key] = raw[2] if len(raw) > 2 else None
            if i < len(objects_names_list):
                names = objects_names_list[i]
                for key, idx in name_keys:
                    entry[key] = names[idx] if len(names) > idx else None
            enriched.append(entry)
        result["communication_details"]["objects_list"] = enriched

    def _set_by_name_common(self, object_name: str, attribute_name: str, value: Any,
                            raise_unknown_errors: Optional[bool] = None, log_suffix: str = "") -> Dict[str, Any]:
        """Internal helper for DLMS SET by object/attribute name.

        Args:
            object_name: COSEM object name.
            attribute_name: Attribute name.
            value: Value to write (already in the expected format for DLMSSetRequestNormal).
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None).
            log_suffix: Optional suffix for log messages.

        Returns:
            Result dictionary from DLMSOperations.set.
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        suffix = f" {log_suffix}" if log_suffix else ""
        logger.info(f"SET operation by name: object='{object_name}', attribute='{attribute_name}'{suffix}", **self._mod)

        try:
            class_id, obis_code, attribute_id, _ = CoreHelper.get_object_metadata_and_attribute_id(
                self._config_manager, object_name, attribute_name
            )

            logger.info(
                f"SET operation by name: object='{object_name}', attribute='{attribute_name}', class_id={class_id}, obis={obis_code}, attr_id={attribute_id}{suffix}",
                **self._mod,
            )

            use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
            result = self._dlms_operations.set(class_id, obis_code, attribute_id, value,
                                               raise_unknown_errors=use_raise_errors)
            # Add names into communication_details.request alongside obis_code/attribute_id
            if "communication_details" in result and "request" in result["communication_details"]:
                result["communication_details"]["request"]["object_name"] = object_name
                result["communication_details"]["request"]["attribute_name"] = attribute_name
            return result

        except Exception as e:
            logger.error(f"SET operation by name failed{suffix}: {e}", **self._mod)
            raise

    def set_raw_object_by_name(self, object_name: str, attribute_name: str, value: str,
                               raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS SET operation to write an attribute value using object and attribute names.
        
        Args:
            object_name: Name of the COSEM object (e.g., "CosemDataProtection")
            attribute_name: Name of the attribute to write (e.g., "logical_name")
            value: Value to write
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)
            
        Returns:
            Dictionary containing:
            - success: bool - True if operation succeeded
            - value: str - Hex string of response data if any, None otherwise
            - error_code: int - Error code (0 for success)
            - error_description: str - Description of error or success status
            - raw_data: object - Original response object for advanced usage
            
        Raises:
            RuntimeError: If not connected or object/attribute not found
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
        """
        value_bytes = bytes.fromhex(value)
        return self._set_by_name_common(object_name, attribute_name, value_bytes,
                                        raise_unknown_errors=raise_unknown_errors,
                                        log_suffix="(raw hex)")

    @staticmethod
    def _resolve_dlms_type_class(attribute_type: str) -> type:
        """Resolve a DLMS type class by its name (class name or XML tag).

        Resolution order:
        1. Search by class name (case-insensitive) in DlmsDataFactory.MAP values
        2. Search by XML_TAG (key) in DLMS_TYPE_REGISTRY

        Args:
            attribute_type: Name of the DLMS type class (e.g. ``"Unsigned16"``,
                ``"Integer32"``, ``"visible_string"``, …)

        Returns:
            The matching ``AbstractDlmsType`` subclass.

        Raises:
            ValueError: If no matching type is found.
        """
        # 1. Search by class name (case-insensitive)
        for cls in DlmsDataFactory.MAP.values():
            if cls.__name__.lower() == attribute_type.lower():
                return cls
        # 2. Search by XML_TAG in DLMS_TYPE_REGISTRY (case-insensitive)
        for tag, cls in DLMS_TYPE_REGISTRY.items():
            if tag.lower() == attribute_type.lower():
                return cls
        raise ValueError(
            f"Unknown DLMS attribute type: '{attribute_type}'. "
            f"Available types: {sorted(c.__name__ for c in DlmsDataFactory.MAP.values())}"
        )

    def set_object_by_name(self, object_name: str, attribute_name: str,
                           value: str,
                           raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS SET operation using object and attribute names.

        The DLMS type is extracted automatically from the data model
        (``dlmsType.type`` field), so the caller only needs to provide the
        string representation of the value — no manual type instantiation
        is required.

        Args:
            object_name: Name of the COSEM object (e.g., ``"Clock"``)
            attribute_name: Name of the attribute to write (e.g., ``"time_zone"``)
            value: String representation of the value to write (e.g., ``"120"``,
                ``"true"``, ``"FF00AA"`` for octet-strings, …)
            raise_unknown_errors: Whether to raise exceptions for unknown errors
                (uses default if ``None``)

        Returns:
            Dictionary containing operation result (same as DLMSOperations.set).

        Raises:
            RuntimeError: If not connected, object/attribute not found, or the
                data model does not declare a ``dlmsType`` for the attribute.
            ValueError: If the type declared in the data model is not a known
                DLMS type.
            FrameExecutorException: If the operation fails and
                *raise_unknown_errors* is ``True``.

        Example:
            >>> api.set_object_by_name("Clock", "time_zone", "120")
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        # Extract class_id, obis_code, attribute_id AND attribute_type from data model
        class_id, obis_code, attribute_id, attribute_type = \
            CoreHelper.get_object_metadata_and_attribute_id(
                self._config_manager, object_name, attribute_name
            )

        if not attribute_type:
            raise RuntimeError(
                f"No dlmsType declared for attribute '{attribute_name}' "
                f"of object '{object_name}' in the data model."
            )

        # Resolve the DLMS type class from the data model type string
        dlms_cls = self._resolve_dlms_type_class(attribute_type)

        # Instantiate via from_string so each type handles its own str→native conversion
        dlms_obj: AbstractDlmsType = dlms_cls.from_string(value)

        logger.info(
            f"SET operation by name: object='{object_name}', attribute='{attribute_name}', "
            f"class_id={class_id}, obis={obis_code}, attr_id={attribute_id}, "
            f"type='{attribute_type}', value={value!r}",
            **self._mod,
        )

        # Encode to bytes and send
        value_bytes = dlms_obj.to_bytes()
        use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
        result = self._dlms_operations.set(class_id, obis_code, attribute_id, value_bytes,
                                           raise_unknown_errors=use_raise_errors)

        # Enrich communication_details with names and resolved type
        if "communication_details" in result and "request" in result["communication_details"]:
            result["communication_details"]["request"]["object_name"]    = object_name
            result["communication_details"]["request"]["attribute_name"] = attribute_name
            result["communication_details"]["request"]["attribute_type"] = attribute_type

        return result

    def set_objects_with_list(self, objects_list: List[Dict[str, Any]],
                              raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS SET-WITH-LIST operation to write multiple attributes in a single request.

        This method is more efficient than multiple individual SET operations when writing
        several attributes, as it sends all requests in a single DLMS frame.

        Args:
            objects_list: List of dictionaries, each containing:
                - class_id: int - COSEM class ID
                - obis_code: str - OBIS code string (e.g., "0100010700FF")
                - attribute_id: int - Attribute ID
                - value: Any - Value to set
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)

        Returns:
            Dictionary containing:
            {
                "success": bool - True if all operations succeeded, False if any failed
                "results": [ - List of individual results in the same order as requests
                    {
                        "success": bool,
                        "value": str or None,
                        "error_code": int,
                        "error_description": str,
                        "raw_data": object or None
                    },
                    ...
                ],
                "total_requested": int - Total number of objects requested
                "successful_count": int - Number of successful writes
                "failed_count": int - Number of failed writes
                "objects_list": list - [[class_id, obis_code, attribute_id, value], ...]
                "frame_details": {...} - Frame transmission details
            }

        Raises:
            RuntimeError: If not connected
            ValueError: If objects_list is empty or contains invalid entries
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        if not objects_list:
            raise ValueError("objects_list cannot be empty")

        use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
        return self._dlms_operations.set_with_list(objects_list, raise_unknown_errors=use_raise_errors)

    def set_objects_with_list_by_name(self, objects_names_list: List[List[Any]],
                                      raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS SET-WITH-LIST operation using object and attribute names.

        This method resolves object and attribute names to COSEM identifiers and then
        performs a bulk write operation in a single DLMS request.

        Args:
            objects_names_list: List of [object_name, attribute_name, value] triplets, e.g.:
                [
                    ['Clock', 'time_zone', b'\x09\x01\x31'],
                    ['Clock', 'status', b'\x09\x01\x32']
                ]
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)

        Returns:
            Dictionary containing:
            {
                "success": bool - True if all operations succeeded
                "results": [...] - List of individual results
                "total_requested": int - Total number of objects requested
                "successful_count": int - Number of successful writes
                "failed_count": int - Number of failed writes
                "objects_list": list - [[class_id, obis_code, attribute_id, value], ...]
                "objects_names": list - Original names [[object_name, attribute_name, value], ...]
                "frame_details": {...} - Frame transmission details
            }

        Raises:
            RuntimeError: If not connected or object/attribute not found in configuration
            ValueError: If objects_names_list is empty or contains invalid entries
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        if not objects_names_list:
            raise ValueError("objects_names_list cannot be empty")

        logger.info(f"SET-WITH-LIST operation by name: {len(objects_names_list)} objects requested", **self._mod)

        resolved_objects = []
        for idx, name_triplet in enumerate(objects_names_list):
            if not isinstance(name_triplet, (list, tuple)) or len(name_triplet) != 3:
                raise ValueError(
                    f"Invalid entry at index {idx}: {name_triplet}. "
                    f"Expected [object_name, attribute_name, value]"
                )

            object_name, attribute_name, value = name_triplet
            logger.trace(f"  [{idx + 1}] Resolving {object_name}.{attribute_name}", **self._mod)

            try:
                class_id, obis_code, attribute_id, _ = CoreHelper.get_object_metadata_and_attribute_id(
                    self._config_manager, object_name, attribute_name
                )

                resolved_objects.append({
                    "class_id": class_id,
                    "obis_code": obis_code,
                    "attribute_id": attribute_id,
                    "value": value
                })

                logger.trace(
                    f"  [{idx + 1}] Resolved: class_id={class_id}, obis={obis_code}, attr_id={attribute_id}",
                    **self._mod
                )
            except Exception as e:
                logger.error(
                    f"Failed to resolve object '{object_name}', attribute '{attribute_name}': {e}",
                    **self._mod
                )
                raise RuntimeError(
                    f"Cannot resolve object '{object_name}', attribute '{attribute_name}': {e}"
                ) from e

        logger.info("All objects resolved, executing SET-WITH-LIST...", **self._mod)
        result = self.set_objects_with_list(resolved_objects, raise_unknown_errors)

        self._enrich_objects_list(
            result, objects_names_list,
            name_keys=[("object_name", 0), ("attribute_name", 1), ("value_to_set", 2)]
        )

        logger.info(
            f"SET-WITH-LIST by name completed: {result['successful_count']}/{result['total_requested']} successful",
            **self._mod
        )

        return result

    def action_raw_object_by_name(self, object_name: str, method_name: str, parameters: str = "",
                                  raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS ACTION operation using object and method names (raw, no data parsing).
        
        This method returns the raw hex data without interpreting the DLMS structure.
        Use ``action_object_by_name`` if you need parsed ``readable_data``.
        
        Args:
            object_name: Name of the COSEM object (e.g., "CosemDataProtection")
            method_name: Name of the method to execute (e.g., "reset")
            parameters: Optional parameters for the method as hex string
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)
            
        Returns:
            Dictionary containing:
            - success: bool - True if operation succeeded
            - error_code: int - Error code (0 for success)
            - error_description: str - Description of error or success status
            - raw_data: str - Raw hex string of the response
            
        Raises:
            RuntimeError: If not connected or object/method not found
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
        """
        # Accept empty string or hex string.
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")
        parameters_bytes = bytes.fromhex(parameters) if parameters else None

        logger.info(f"ACTION RAW operation by name: object='{object_name}', method='{method_name}'",
                    **self._mod)

        try:
            # Extract metadata using helper method (single data model call)
            class_id, obis_code, method_id, _ = CoreHelper.get_object_metadata_and_method_id(self._config_manager,
                                                                                             object_name,
                                                                                             method_name)

            logger.info(
                f"ACTION RAW operation by name: object='{object_name}', method='{method_name}', class_id={class_id}, obis={obis_code}, method_id={method_id}",
                **self._mod)

            # Perform the ACTION operation using OBIS code
            # Use SDK-level setting if not specified
            use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
            result_dict = self._dlms_operations.action(class_id, obis_code, method_id, parameters_bytes,
                                                raise_unknown_errors=use_raise_errors)
            # For raw action: value = raw hex data, remove raw_data and readable_data
            raw_data_hex = result_dict.pop('raw_data', None)
            result_dict.pop('readable_data', None)
            if result_dict.get('success'):
                result_dict['value'] = None if raw_data_hex is None else raw_data_hex
            # Add names into communication_details.request alongside obis_code/method_id
            if "communication_details" in result_dict and "request" in result_dict["communication_details"]:
                result_dict["communication_details"]["request"]["object_name"] = object_name
                result_dict["communication_details"]["request"]["method_name"] = method_name
            return result_dict

        except Exception as e:
            logger.error(f"ACTION RAW operation by name failed: {e}",
                         **self._mod)
            raise

    def action_object_by_name(self, object_name: str, method_name: str,
                              parameters: Optional[AbstractDlmsType] = None,
                              raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """Perform a DLMS ACTION operation using object and method names with a typed parameter.

        This method is similar to action_raw_object_by_name, but it expects `parameters` to be an
        `AbstractDlmsType` instance (already typed) instead of a hex string.

        Args:
            object_name: Name of the COSEM object
            method_name: Name of the method to execute
            parameters: Optional typed DLMS parameter (encoded using to_bytes())
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)

        Returns:
            Dictionary containing operation result (same as DLMSOperations.action).

        Raises:
            RuntimeError: If not connected or object/method not found
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        payload_bytes = parameters.to_bytes() if parameters is not None else None

        logger.info(f"ACTION operation by name (typed): object='{object_name}', method='{method_name}'",
                    **self._mod)

        try:
            class_id, obis_code, method_id, _ = CoreHelper.get_object_metadata_and_method_id(
                self._config_manager, object_name, method_name
            )

            logger.info(
                f"ACTION operation by name (typed): object='{object_name}', method='{method_name}', class_id={class_id}, obis={obis_code}, method_id={method_id}",
                **self._mod,
            )

            use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
            result = self._dlms_operations.action(class_id, obis_code, method_id, payload_bytes,
                                                  raise_unknown_errors=use_raise_errors)
            # For typed action: value = readable_data, remove raw_data
            result.pop('raw_data', None)
            readable = result.pop('readable_data', None)
            if result.get('success'):
                result['value'] = None if readable is None else readable
            # Add names into communication_details.request alongside obis_code/method_id
            if "communication_details" in result and "request" in result["communication_details"]:
                result["communication_details"]["request"]["object_name"] = object_name
                result["communication_details"]["request"]["method_name"] = method_name
            return result

        except Exception as e:
            logger.error(f"ACTION operation by name (typed) failed: {e}", **self._mod)
            raise

    def action_objects_with_list(self, objects_list: List[Dict[str, Any]],
                                 raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS ACTION-WITH-LIST operation to execute multiple methods in a single request.

        This method is more efficient than multiple individual ACTION operations when executing
        several methods, as it sends all requests in a single DLMS frame.

        Args:
            objects_list: List of dictionaries, each containing:
                - class_id: int - COSEM class ID
                - obis_code: str - OBIS code string
                - method_id: int - Method ID
                - parameters: Any (optional) - Method parameters payload
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)

        Returns:
            Dictionary containing:
            {
                "success": bool - True if all operations succeeded, False if any failed
                "results": [ - List of individual results in the same order as requests
                    {
                        "success": bool,
                        "value": str or None,
                        "error_code": int,
                        "error_description": str,
                        "raw_data": object or None
                    },
                    ...
                ],
                "total_requested": int - Total number of objects requested
                "successful_count": int - Number of successful actions
                "failed_count": int - Number of failed actions
                "objects_list": list - [[class_id, obis_code, method_id, parameters], ...]
                "frame_details": {...} - Frame transmission details
            }

        Raises:
            RuntimeError: If not connected
            ValueError: If objects_list is empty or contains invalid entries
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        if not objects_list:
            raise ValueError("objects_list cannot be empty")

        use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
        return self._dlms_operations.action_with_list(objects_list, raise_unknown_errors=use_raise_errors)

    def action_objects_with_list_by_name(self, objects_names_list: List[List[Any]],
                                         raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS ACTION-WITH-LIST operation using object and method names.

        This method resolves object and method names to COSEM identifiers and then
        executes a bulk action operation in a single DLMS request.

        Args:
            objects_names_list: List of [object_name, method_name, parameters] triplets, e.g.:
                [
                    ['ImageTransfer', 'image_verify', bytes.fromhex('090101')],
                    ['Clock', 'adjust_to_quarter', None]
                ]
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)

        Returns:
            Dictionary containing:
            {
                "success": bool - True if all operations succeeded
                "results": [...] - List of individual results
                "total_requested": int - Total number of objects requested
                "successful_count": int - Number of successful actions
                "failed_count": int - Number of failed actions
                "objects_list": list - [[class_id, obis_code, method_id, parameters], ...]
                "objects_names": list - Original names [[object_name, method_name, parameters], ...]
                "frame_details": {...} - Frame transmission details
            }

        Raises:
            RuntimeError: If not connected or object/method not found in configuration
            ValueError: If objects_names_list is empty or contains invalid entries
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        if not objects_names_list:
            raise ValueError("objects_names_list cannot be empty")

        logger.info(f"ACTION-WITH-LIST operation by name: {len(objects_names_list)} objects requested", **self._mod)

        resolved_objects = []
        for idx, name_triplet in enumerate(objects_names_list):
            if not isinstance(name_triplet, (list, tuple)) or len(name_triplet) != 3:
                raise ValueError(
                    f"Invalid entry at index {idx}: {name_triplet}. "
                    f"Expected [object_name, method_name, parameters]"
                )

            object_name, method_name, parameters = name_triplet
            logger.trace(f"  [{idx + 1}] Resolving {object_name}.{method_name}", **self._mod)

            try:
                class_id, obis_code, method_id, _ = CoreHelper.get_object_metadata_and_method_id(
                    self._config_manager, object_name, method_name
                )

                resolved_objects.append({
                    "class_id": class_id,
                    "obis_code": obis_code,
                    "method_id": method_id,
                    "parameters": parameters
                })

                logger.trace(
                    f"  [{idx + 1}] Resolved: class_id={class_id}, obis={obis_code}, method_id={method_id}",
                    **self._mod
                )
            except Exception as e:
                logger.error(
                    f"Failed to resolve object '{object_name}', method '{method_name}': {e}",
                    **self._mod
                )
                raise RuntimeError(
                    f"Cannot resolve object '{object_name}', method '{method_name}': {e}"
                ) from e

        logger.info("All objects resolved, executing ACTION-WITH-LIST...", **self._mod)
        result = self.action_objects_with_list(resolved_objects, raise_unknown_errors)

        self._enrich_objects_list(
            result, objects_names_list,
            id_key="method_id",
            name_keys=[("object_name", 0), ("method_name", 1), ("parameters", 2)]
        )

        logger.info(
            f"ACTION-WITH-LIST by name completed: {result['successful_count']}/{result['total_requested']} successful",
            **self._mod
        )

        return result

    def set_raw_object_by_obis(self, class_id: int, obis_code: str, attribute_id: int, value: str,
                               raise_unknown_errors: Optional[bool] = None) -> Dict[str, Any]:
        """
        Perform a DLMS SET operation to write an attribute value.
        
        Args:
            class_id: COSEM class ID of the object
            obis_code: OBIS code identifying the object
            attribute_id: Attribute ID to write
            value: Value to write
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)
            
        Returns:
            Dictionary containing:
            - success: bool - True if operation succeeded
            - value: str - Hex string of response data if any, None otherwise
            - error_code: int - Error code (0 for success)
            - error_description: str - Description of error or success status
            - raw_data: object - Original response object for advanced usage
            
        Raises:
            RuntimeError: If not connected
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
        """
        value_bytes = bytes.fromhex(value)

        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")

        # Use SDK-level setting if not specified
        use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
        return self._dlms_operations.set(class_id, obis_code, attribute_id, value_bytes,
                                         raise_unknown_errors=use_raise_errors)

    def action_raw_object_by_obis(self, class_id: int, obis_code: str, method_id: int,
                                  parameters: str = "", raise_unknown_errors: Optional[bool] = None) -> Dict[
        str, Any]:
        """
        Perform a DLMS ACTION operation to execute a method (raw, no data parsing).
        
        This method returns the raw hex data without interpreting the DLMS structure.
        Use ``action_object_by_name`` if you need parsed ``readable_data``.
        
        Args:
            class_id: COSEM class ID of the object
            obis_code: OBIS code identifying the object
            method_id: Method ID to execute
            parameters: Optional parameters for the method as hex string
            raise_unknown_errors: Whether to raise exceptions for unknown errors (uses default if None)
            
        Returns:
            Dictionary containing:
            - success: bool - True if operation succeeded
            - error_code: int - Error code (0 for success)
            - error_description: str - Description of error or success status
            - raw_data: str - Raw hex string of the response
            
        Raises:
            RuntimeError: If not connected
            FrameExecutorException: If the operation fails and raise_unknown_errors is True
        """
        ensure_connected(self._session_manager.is_connected)
        if self._dlms_operations is None:
            raise RuntimeError("DLMS operations not initialized. Call connect() first.")
        # Accept empty string or hex string.
        parameters_bytes = bytes.fromhex(parameters) if parameters else None

        # Use SDK-level setting if not specified
        use_raise_errors = self._raise_unknown_errors if raise_unknown_errors is None else raise_unknown_errors
        result_dict = self._dlms_operations.action(class_id, obis_code, method_id, parameters_bytes,
                                            raise_unknown_errors=use_raise_errors)
        # For raw action: value = raw hex data, remove raw_data and readable_data
        raw_data_hex = result_dict.pop('raw_data', None)
        result_dict.pop('readable_data', None)
        if result_dict.get('success'):
            result_dict['value'] = None if raw_data_hex is None else raw_data_hex
        return result_dict

    def clear_configuration(self) -> None:
        """
        Clear configuration objects from memory and reset session state.
        
        This method is useful for cleanup operations and resetting the API
        to its initial state. It will disconnect any active session and
        clear all loaded configurations from memory.
        
        Note: This will force disconnection if currently connected.
        """
        logger.trace("Clearing configuration and resetting session state",
                     **self._mod)

        try:
            # Disconnect if currently connected
            if self._session_manager.is_connected:
                logger.info("Disconnecting active session before clearing configuration",
                            **self._mod)
                self.disconnect()

            # Clear DLMS operations and session manager
            self._dlms_operations = None
            self._session_manager.clear_session()

            # Clear configuration manager and reset its cache safely
            if self._config_manager:
                try:
                    # Clear the cached configurations from memory
                    if hasattr(self._config_manager, '_lock') and hasattr(self._config_manager, '_configs'):
                        with self._config_manager._lock:
                            self._config_manager._configs.clear()

                    # Clear the singleton instance to force fresh loading next time
                    if hasattr(self._config_manager, '_config_dir') and hasattr(ConfigManager, '_instances'):
                        config_dir_str = str(self._config_manager._config_dir)
                        if config_dir_str in ConfigManager._instances:
                            del ConfigManager._instances[config_dir_str]
                except AttributeError as ae:
                    logger.warning(f"Could not fully clear configuration cache: {ae}",
                                   **self._mod)

            self._config_manager = None

            logger.info("Configuration cleared and session state reset successfully",
                        **self._mod)

        except Exception as e:
            logger.error(f"Error during configuration clearing: {e}",
                         **self._mod)
            # Still reset the state even if there was an error
            self._config_manager = None
            self._dlms_operations = None
            self._session_manager.clear_session()
            raise
    # =========================================================================
    # Configuration Management Operations (Runtime Configuration APIs)
    # =========================================================================
    def change_configuration_parameter(
            self,
            config_handle: ConfigModuleProxy,
            parameter_name: str,
            parameter_value: Any
    ) -> bool:
        """
        Change a configuration parameter at runtime without modifying files.
        Overloads a specific parameter for the given config object in the current session.
        Allows runtime updates without file changes. The modification is stored in memory
        and will persist for the duration of the session.
        Args:
            config_handle: ConfigModuleProxy instance (e.g., config_manager.LocalAdmin)
            parameter_name: Dotted path to the parameter (e.g., "session.timeout")
            parameter_value: New value to set (can be any type: str, int, bool, dict, etc.)
        Returns:
            bool: True if the parameter was successfully changed, False otherwise
        Raises:
            RuntimeError: If configuration is not loaded
            ValueError: If config_handle or parameter_name is invalid
        Example:
            api = SDKApi()
            api.load_configuration("configuration")
            api.change_configuration_parameter(
            api._config_manager.LocalAdmin,
            "session.timeout",
            300
            )
            True
        """
        if self._config_manager is None:
            raise RuntimeError("Configuration not loaded. Call load_configuration() first.")
        logger.info(
            f"ChangeConfigurationParameter: parameter='{parameter_name}', value type={type(parameter_value).__name__}",
            **self._mod
        )
        try:
            # Validate inputs
            if not isinstance(config_handle, ConfigModuleProxy):
                logger.error("config_handle must be a ConfigModuleProxy instance", **self._mod)
                raise ValueError("config_handle must be a ConfigModuleProxy instance")
            if not parameter_name:
                logger.error("parameter_name cannot be empty", **self._mod)
                raise ValueError("parameter_name cannot be empty or None")
            # Navigate to the parameter using dotted notation
            parts = parameter_name.split('.')
            current = config_handle
            # Navigate to parent of target parameter
            for part in parts[:-1]:
                try:
                    current = getattr(current, part)
                except AttributeError:
                    logger.error(f"Parameter path '{parameter_name}' not found", **self._mod)
                    raise ValueError(f"Parameter path '{parameter_name}' does not exist")
            # Set the final parameter
            setattr(current, parts[-1], parameter_value)
            logger.info(
                f"Parameter '{parameter_name}' changed successfully to: {parameter_value}",
                **self._mod
            )
            return True
        except ValueError as e:
            logger.error(f"Validation error: {e}", **self._mod)
            raise
        except Exception as e:
            logger.error(
                f"Failed to change parameter '{parameter_name}': {e}",
                **self._mod
            )
            return False
    def save_configuration_to_file(
            self,
            config_handle: ConfigModuleProxy,
            file_path: Optional[str] = None
    ) -> bool:
        """
        Save configuration changes to file for persistent storage.
        Persists changes in the config object to the config file. Ensures modifications
        are saved for future sessions. If no file_path is provided, saves to the default
        location based on the module structure.
        Args:
            config_handle: ConfigModuleProxy instance (e.g., config_manager.LocalAdmin)
            file_path: Optional custom file path (uses default if None)
        Returns:
            bool: True if configuration was successfully saved, False otherwise
        Raises:
            RuntimeError: If configuration is not loaded
            ValueError: If config_handle is invalid
        Example:
             api = SDKApi()
             api.load_configuration("configuration")
             api.change_configuration_parameter(
             api._config_manager.LocalAdmin,
             "session.timeout",
             300
             )
             api.save_configuration_to_file(api._config_manager.LocalAdmin)
            True
        """
        if self._config_manager is None:
            raise RuntimeError("Configuration not loaded. Call load_configuration() first.")
        logger.info(
            f"SaveConfigurationToFile: module='{config_handle._module}', file_path={file_path if file_path else 'default'}",
            **self._mod
        )
        try:
            # Validate inputs
            if not isinstance(config_handle, ConfigModuleProxy):
                logger.error("config_handle must be a ConfigModuleProxy instance", **self._mod)
                raise ValueError("config_handle must be a ConfigModuleProxy instance")
            # Access the underlying manager and module
            manager = config_handle._manager
            module_name = config_handle._module
            # If custom file_path is specified, use it
            if file_path:
                logger.info(f"Saving to custom path: {file_path}", **self._mod)
                custom_path = Path(file_path)
                # Get current module config
                module_config = manager._configs.get(module_name, {})
                # Write to temp file first
                with tempfile.NamedTemporaryFile('w', delete=False, suffix='.json5') as tmp:
                    json.dump(module_config, tmp, indent=2)
                    tmp_path = tmp.name
                # Move temp file to target (atomic on most systems)
                shutil.move(tmp_path, custom_path)
            else:
                # Use default save mechanism
                logger.info(f"Saving to default location for module '{module_name}'", **self._mod)
                # Get the current module config from in-memory cache
                module_config = manager._configs.get(module_name, {})
                # Determine if it's a folder module or legacy module
                if manager._is_folder_module(module_name):
                    # For folder modules, write each file
                    for file_stem, file_config in module_config.items():
                        if isinstance(file_config, dict):
                            manager._atomic_write_folder(module_name, file_stem, file_config)
                else:
                    # For legacy modules, write the whole config
                    manager._atomic_write_legacy(module_name, module_config)
            logger.info(
                f"Configuration '{module_name}' saved successfully",
                **self._mod
            )
            return True
        except ValueError as e:
            logger.error(f"Validation error: {e}", **self._mod)
            raise
        except Exception as e:
            logger.error(
                f"Failed to save configuration: {e}",
                **self._mod,
                exc_info=True
            )
            return False
    def reload_configuration(
            self,
            config_handle: ConfigModuleProxy
    ) -> bool:
        """
        Reload configuration from disk, discarding unsaved changes.

        Resets configuration values to persistent values. Useful for restoring original
        settings after runtime modifications. This method reloads the configuration from
        disk, discarding any in-memory changes that were not persisted.

        Args:
            config_handle: ConfigModuleProxy instance (e.g., config_manager.LocalAdmin)

        Returns:
            bool: True if configuration was successfully reloaded, False otherwise

        Raises:
            RuntimeError: If configuration is not loaded
            ValueError: If config_handle is invalid

        Example:
             api = SDKApi()
             api.load_configuration("configuration")
             api.change_configuration_parameter(
             api._config_manager.LocalAdmin,
             "session.timeout",
             999
             )
             # Discard changes and reload original values
             api.reload_configuration(api._config_manager.LocalAdmin)
            True
        """
        if self._config_manager is None:
            raise RuntimeError("Configuration not loaded. Call load_configuration() first.")
        logger.info(
            f"ReloadConfiguration: module='{config_handle._module}', reloading from persistent storage",
            **self._mod
        )
        try:
            # Validate inputs
            if not isinstance(config_handle, ConfigModuleProxy):
                logger.error("config_handle must be a ConfigModuleProxy instance", **self._mod)
                raise ValueError("config_handle must be a ConfigModuleProxy instance")
            # Access the underlying manager and module
            manager = config_handle._manager
            module_name = config_handle._module
            # Clear the in-memory cache for the module to force reload from disk
            with manager._lock:
                if module_name in manager._configs:
                    logger.debug(f"Clearing cached config for '{module_name}'", **self._mod)
                    del manager._configs[module_name]
            # Re-load the module from disk (happens automatically on next access)
            logger.debug(f"Reloading '{module_name}' from disk", **self._mod)
            manager._load_module(module_name)
            logger.info(
                f"Configuration '{module_name}' reloaded successfully from disk",
                **self._mod
            )
            return True
        except ValueError as e:
            logger.error(f"Validation error: {e}", **self._mod)
            raise
        except Exception as e:
            logger.error(
                f"Failed to reload configuration: {e}",
                **self._mod,
                exc_info=True
            )
            return False

    # ------------------------------------------------------------------ #
    #  Push Data Server                                                    #
    # ------------------------------------------------------------------ #

    def start_push_server(self, protocol: str, host: str, port: int, association: str = "LocalManagement") -> None:
        """
        Start a push data server (TCP or UDP) and begin listening for notifications.

        Args:
            protocol:    "tcp" or "udp"
            host:        Bind address (e.g. "0.0.0.0")
            port:        Listening port
            association: Configuration association name (default: "LocalManagement")
        """
        from ng_sdk.push_data_server.tcp_server import TcpServer
        from ng_sdk.push_data_server.udp_server import UdpServer
        from ng_sdk.security.security_context import SecurityContext
        from ng_sdk.transport.tcp.tcp_transport import TCPUDPTransport

        if self._push_server_manager is not None:
            raise RuntimeError("A push server is already running. Call stop_push_server first.")

        configuration = getattr(self._config_manager.association, association)
        security_context = SecurityContext(configuration)
        transport = TCPUDPTransport(configuration)

        protocol = protocol.lower()
        if protocol == "tcp":
            server = TcpServer(
                host=host,
                port=port,
                configuration=configuration,
                handler=None,  # will be replaced by PushDataServerManager
                security_context=security_context,
                transport=transport,
                is_complete=TCPUDPTransport.is_complete,
            )
        elif protocol == "udp":
            server = UdpServer(
                host=host,
                port=port,
                configuration=configuration,
                security_context=security_context,
                transport=transport,
                handler=None,  # will be replaced by PushDataServerManager
                is_complete=None,
            )
        else:
            raise ValueError(f"Unknown protocol '{protocol}'. Use 'tcp' or 'udp'.")

        self._push_server_manager = PushDataServerManager()
        self._push_server_manager.start(server)
        logger.info(f"Push server started on {protocol.upper()} {host}:{port}", **self._mod)

    def stop_push_server(self) -> None:
        """Stop the running push data server."""
        if self._push_server_manager is None:
            raise RuntimeError("No push server is running.")
        self._push_server_manager.stop()
        self._push_server_manager = None
        logger.info("Push server stopped", **self._mod)

    def get_frame_counter(
        self,
        communication: "AbstractCommunication",
        public_association: str = "Public",
        local_association: str = "LocalManagement",
    ) -> int:
        """
        Open a DLMS session on the public association to retrieve the frame counter,
        then update the local management association security context.

        Args:
            communication:      Communication channel to use.
            public_association: Name of the public association (default: "Public").
            local_association:  Name of the local management association whose
                                frame counter will be updated (default: "LocalManagement").

        Returns:
            The retrieved frame counter value.
        """
        from ng_sdk.session.dlms_session import DLMSSession

        public_config = getattr(self._config_manager.association, public_association)
        local_config = getattr(self._config_manager.association, local_association)

        session = DLMSSession(public_config, communication)
        session.open()
        session.get_frame_counter(local_config)
        frame_counter = public_config.security.frame_counter
        session.close()
        local_config.security.frame_counter = frame_counter
        logger.info(f"Frame counter: {frame_counter}", **self._mod)
        return frame_counter

    def wait_for_notification(self, timeout: float = 30.0) -> Optional[PushNotification]:
        """
        Block until a push notification is received or timeout expires.

        Args:
            timeout: Maximum seconds to wait (default: 30s)

        Returns:
            PushNotification with: notification, addr, communication,
            source_port, dest_port, server_system_title.
            Returns None if no notification arrives within timeout.

        Raises:
            RuntimeError if no server is running.
        """
        if self._push_server_manager is None:
            raise RuntimeError("No push server is running. Call start_push_server first.")
        try:
            return self._push_server_manager.wait_for_notification(timeout=timeout)
        except TimeoutError:
            logger.warning(f"No push notification received within {timeout}s", **self._mod)
            return None

    def send_ack(self, push_notification: PushNotification, association: str = "LocalManagement") -> None:
        """
        Build and send a ciphered acknowledgement back to the device.

        Args:
            push_notification: The notification returned by wait_for_notification.
            association:       Configuration association used to cipher the ack (default: "LocalManagement").

        Raises:
            RuntimeError if no server is running.
        """
        from ng_sdk.security.security_context import SecurityContext

        if self._push_server_manager is None:
            raise RuntimeError("No push server is running. Call start_push_server first.")

        configuration = getattr(self._config_manager.association, association)
        security_context = SecurityContext(configuration)
        self._push_server_manager.send_ack(push_notification, security_context)


# Convenience functions for quick usage
def create_api() -> SDKApi:
    """Create a new DLMS API instance."""
    return SDKApi()


def quick_connect(config_dir: str, client_name: str) -> SDKApi:
    """
    Quickly create and connect a DLMS API instance.
    
    Args:
        config_dir: Path to configuration directory
        client_name: Name of the client configuration to use (default: "LocalAdmin")

    Returns:
        Connected DLMS API instance
    """
    api = SDKApi()
    api.load_configuration(config_dir)
    api.connect(client_name)
    return api
