from enum import StrEnum


class SecurityError(StrEnum):
    KEY_ERROR = "The key has bad character"
    CERTIFICATE_ERROR = "The certificate does not belong to this meter."
    KEY_LENGTH_ERROR = "The length of global key is not correct"
    HLS_SECRET_INCORRECT ="Hls secret is not correct"
    SECURITY_CONTROL_INCORRECT = "Security control is not correct"
    INVOCATION_COUNTER_INCORRECT = "Invocation counter is not correct"
    AUTHENTICATION_KEY_INCORRECT = "Authentication key is not correct"
    SYSTEM_TITLE_CLIENT_INCORRECT = "System title client is not correct"
    SYSTEM_TITLE_SERVER_INCORRECT = "System title server is not correct"
    HLS_PASS_3_ERROR = "Error in hls pass 3"
    DEDICATED_KEY_NOT_CONFIGURED = "Dedicated key is required but not configured"


class SecurityException(Exception):
    code:SecurityError
    def __init__(self,code:SecurityError):
        super().__init__(code.value)
        self.code = code

class InvalidInputException(Exception):
    """
    Exception Invalid Input
    """

    def __init__(self, message):
        super(InvalidInputException, self).__init__(message)
        self.msg = message

    def __str__(self):
        return str(self.msg)