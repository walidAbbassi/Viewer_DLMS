from enum import StrEnum


class HdlcTransportError(StrEnum):
      INVALID_ADDRESS = "Invalid Address"
      ADDRESS_TOO_LONG = "Address Too Long"

class HdlcTransportException(Exception):
    code:HdlcTransportError
    def __init__(self,code:HdlcTransportError):
        super().__init__(code.value)
        self.code = code