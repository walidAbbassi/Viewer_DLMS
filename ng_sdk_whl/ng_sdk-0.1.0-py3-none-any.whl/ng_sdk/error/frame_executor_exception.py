from enum import StrEnum


class FrameExecutorError(StrEnum):
    LIST_EXECUTION_UNIQUE_TYPE_ERROR = "All requests must be with same type"
    NULL_RESPONSE_ERROR = "Null response"
    REQUESTS_RESPONSES_LENGTH_ERROR = "Requests and responses must have same length"
    RESPONSE_TYPE_ERROR = "Response type error"
    CANCELLED_EXECUTION = "Cancelled Execution"

class FrameExecutorException(Exception):
    code:FrameExecutorError
    def __init__(self,code:FrameExecutorError):
        super().__init__(code.value)
        self.code = code