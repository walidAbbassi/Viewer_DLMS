from enum import StrEnum


class FrameBuilderError(StrEnum):
    RESPONSE_PARSING_ERROR = "Error parsing response"

class FrameBuilderException(Exception):
    code:FrameBuilderError
    def __init__(self,code:FrameBuilderError):
        super().__init__(code.value)
        self.code = code