from enum import StrEnum


class CommunicationError(StrEnum):
    INVALID_SERIAL_PORT = "Invalid serial port"
    INVALID_BAUDRATE = "Invalid baudrate"
    SERIAL_PORT_CLOSED = "Serial port closed"
    INVALID_FRAME_SIZE = "Invalid TCP frame size"
    INVALID_FRAME_TYPE = "Invalid TCP frame type"
    INVALID_TCP_FRAME = "Invalid tcp_frame"
    INVALID_HOST= "Invalid tcp host"
    INVALID_TCP_PORT = "Invalid tcp port"
    CONNECTION_FAILED = "TCP Connection failed"
    SEND_ERROR = "Send error"
    TCP_SOCKET_CLOSED = "TCP socket closed"
    TIMEOUT="Timeout"
    METER_NOT_RESPONDING = "Meter did not respond after all retries"


class CommunicationException(Exception):
    code:CommunicationError
    def __init__(self,code:CommunicationError):
        super().__init__(code.value)
        self.code = code


