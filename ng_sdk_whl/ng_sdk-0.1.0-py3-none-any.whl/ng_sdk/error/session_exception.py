from enum import StrEnum


class SessionError(StrEnum):
    WRONG_PASSWORD = "The key has bad character"
    BAD_CLIENT_ADDRESS = "This client address is not implemented"



class SessionException(Exception):
    code:SessionError
    def __init__(self,code:SessionError):
        super().__init__(code.value)
        self.code = code

try:
    raise SessionException(SessionError.BAD_CLIENT_ADDRESS)
except SessionException as e :
    print(e)

