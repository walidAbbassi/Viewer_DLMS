"""
Core helper class and constants for the DLMS API.

This module consolidates constants, validation, initialization, and configuration helpers.
"""

from typing import Optional, Tuple

from ng_sdk.configuration.config_manager import ConfigManager, ConfigModuleProxy
from ng_sdk.frame_builder.dlms.dlms_frame_builder import DLMSFrameBuilder
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.security.security_constant import DlmsSecurityPolicy
from ng_sdk.security.security_context import SecurityContext

logger = get_logger()

# =============================================================================
# CONSTANTS
# =============================================================================

# Client configuration names
PUBLIC_CLIENT_NAME = "Public"

# Session types
SESSION_TYPE_HLS = "HLS"
SESSION_TYPE_LLS = "LLS"
SESSION_TYPE_LOWEST = "LOWEST"

# Link types
SERIAL_COMMUNICATION = 'serial'

# Transport types
HDLC = 'HDLC'

# HDLC modes
HDLC_DIRECT = 'DirectHDLC'
HDLC_MODE_E = 'Mode_E'


# =============================================================================
# CORE HELPER CLASS
# =============================================================================

class CoreHelper:
    """
    Class providing core helper methods for DLMS API operations.
    
    This class consolidates validation, initialization, and configuration 
    helper methods with consistent logging and error handling.
    """
    _mod = {LoggingConstants.MODULES_NAME: "CoreHelper"}


    # =========================================================================
    # VALIDATION METHODS
    # =========================================================================

    @staticmethod
    def ensure_configuration_loaded(config_manager: Optional[ConfigManager]) -> None:
        """
        Ensure that configuration has been loaded.
        
        Args:
            config_manager: The configuration manager instance
            
        Raises:
            RuntimeError: If configuration is not loaded
        """
        if config_manager is None:
            raise RuntimeError("Configuration not loaded. Call load_configuration() first.")

    @staticmethod
    def ensure_connected(is_connected: bool) -> None:
        """
        Ensure that a connection is established.
        
        Args:
            is_connected: Connection status flag
            
        Raises:
            RuntimeError: If not connected
        """
        if not is_connected:
            raise RuntimeError("Not connected to DLMS device. Call connect() first.")

    @staticmethod
    def ensure_components_initialized(security_context: Optional[SecurityContext],
                                      frame_builder: Optional[DLMSFrameBuilder]) -> bool:
        """
        Check if components are initialized.
        
        Args:
            security_context: The security context instance
            frame_builder: The frame builder instance
            
        Returns:
            True if components are initialized, False otherwise
        """
        return security_context is not None and frame_builder is not None

    # =========================================================================
    # INITIALIZATION METHODS
    # =========================================================================
    @staticmethod
    def initialize_components(config_manager: ConfigManager,
                              client_name: str) -> Tuple[SecurityContext, DLMSFrameBuilder]:
        """
        Initialize security context and frame builder components.
        
        Args:
            config_manager: Configuration manager instance
            client_name: Name of the client configuration
            
        Returns:
            Tuple of (SecurityContext, DLMSFrameBuilder)
            
        Raises:
            RuntimeError: If initialization fails
        """
        try:
            logger.info(f"Initializing components for client: {client_name}",
                        **CoreHelper._mod)

            # Get client configuration
            client_config: ConfigModuleProxy = config_manager[client_name]

            # Initialize security context
            security_context = SecurityContext(client_config)

            # Initialize frame builder
            frame_builder = DLMSFrameBuilder(client_config, security_context)

            logger.trace("Components initialized successfully",
                         **CoreHelper._mod)

            return security_context, frame_builder

        except Exception as e:
            logger.error(f"Failed to initialize components: {e}",
                         **CoreHelper._mod)
            raise RuntimeError(f"Component initialization failed: {e}") from e

    # =========================================================================
    # CONFIGURATION METHODS
    # =========================================================================

    @staticmethod
    def get_session_type(config: ConfigModuleProxy) -> str:
        """
        Extract session type from configuration.
        
        Args:
            config: Configuration proxy
            
        Returns:
            Session type string: 'HLS', 'LLS', 'LOWEST', or default 'HLS'
        """
        try:
            session_type = config.security.session_type
            session_type_str = str(session_type) if session_type is not None else SESSION_TYPE_LOWEST

            # Validate session type and return appropriate constant
            if session_type_str in [SESSION_TYPE_HLS, SESSION_TYPE_LLS, SESSION_TYPE_LOWEST]:
                return session_type_str
            elif session_type_str == "NoSecurity":
                # Handle legacy "NoSecurity" as LOWEST security level
                return SESSION_TYPE_LOWEST
            else:
                # Default to HLS for unknown session types
                return SESSION_TYPE_LOWEST

        except (KeyError, AttributeError):
            return SESSION_TYPE_HLS

    @staticmethod
    def get_security_policy(config: ConfigModuleProxy) -> str:
        """
        Extract security policy from configuration.
        
        Args:
            config: Configuration proxy
            
        Returns:
            Security policy string
        """
        try:
            security_policy = config.security.security_policy
            return security_policy if security_policy is not None else "NoSecurity"
        except (KeyError, AttributeError):
            return "NoSecurity"

    @staticmethod
    def is_valid_session_type(session_type: str) -> bool:
        """
        Validate if the session type is supported.
        
        Args:
            session_type: Session type string to validate
            
        Returns:
            True if session type is valid, False otherwise
        """
        valid_types = [SESSION_TYPE_HLS, SESSION_TYPE_LLS, SESSION_TYPE_LOWEST]
        return session_type in valid_types

    @staticmethod
    def needs_frame_counter(security_policy: str) -> bool:
        """
        Determine if frame counter is needed based on security policy.
        
        Args:
            security_policy: Security policy string
            
        Returns:
            True if frame counter is needed, False otherwise
        """
        # Frame counter is typically needed for authenticated/encrypted sessions
        authenticated_policies = [DlmsSecurityPolicy.AE, DlmsSecurityPolicy.A, DlmsSecurityPolicy.E]
        return security_policy in authenticated_policies

    @staticmethod
    def requires_authentication(session_type: str) -> bool:
        """
        Determine if authentication is required based on session type.
        
        Args:
            session_type: Session type string
            
        Returns:
            True if authentication is required, False otherwise
        """
        return session_type in [SESSION_TYPE_HLS, SESSION_TYPE_LLS]

    @staticmethod
    def convert_logical_name_to_obis(logical_name: str) -> str:
        """
        Convert logical name format to OBIS code format.
        
        Args:
            logical_name: Logical name in format "0;3;24;1;0;255" or "1-0:2.29.0.255"
            
        Returns:
            OBIS code in format "0003180100FF" or original format if already in OBIS format
            
        Raises:
            ValueError: If logical name format is invalid or values are out of range
        """
        try:
            # Handle different input formats
            if '-' in logical_name or ':' in logical_name or '.' in logical_name:
                # OBIS format like "1-0:2.29.0.255" - return as-is for now
                # Could be converted to hex format if needed, but keeping original for compatibility
                return logical_name

            # Handle semicolon format: "0;3;24;1;0;255"
            parts = logical_name.split(';')
            if len(parts) != 6:
                raise ValueError(f"Invalid logical name format: {logical_name}")

            # Convert each part to integer and then to hex (2 digits, uppercase)
            obis_parts = []
            for part in parts:
                value = int(part.strip())
                if value < 0 or value > 255:
                    raise ValueError(f"Invalid logical name value: {value} (must be 0-255)")
                obis_parts.append(f"{value:02X}")

            return ''.join(obis_parts)

        except (ValueError, AttributeError) as e:
            raise ValueError(f"Failed to convert logical name '{logical_name}' to OBIS code: {e}")

    @staticmethod
    def convert_obis_to_hex(obis_code: str) -> str:
        """
        Convert OBIS code format to hexadecimal format.
        
        Args:
            obis_code: OBIS code in format "1-0:2.29.0.255"
            
        Returns:
            Hex format like "0100021D00FF"
            
        Raises:
            ValueError: If OBIS format is invalid
        """
        try:
            # Handle OBIS format: "1-0:2.29.0.255"
            if '-' in obis_code and ':' in obis_code and '.' in obis_code:
                # Split by delimiters: "1-0:2.29.0.255" -> ["1", "0", "2", "29", "0", "255"]
                parts = obis_code.replace('-', '.').replace(':', '.').split('.')

                if len(parts) != 6:
                    raise ValueError(f"Invalid OBIS format: {obis_code}")

                # Convert each part to hex
                hex_parts = []
                for part in parts:
                    value = int(part.strip())
                    if value < 0 or value > 255:
                        raise ValueError(f"Invalid OBIS value: {value} (must be 0-255)")
                    hex_parts.append(f"{value:02X}")

                return ''.join(hex_parts)

            # If already in hex format or semicolon format, use existing method
            return CoreHelper.convert_obis_to_hex(obis_code)

        except (ValueError, AttributeError) as e:
            raise ValueError(f"Failed to convert OBIS code '{obis_code}' to hex: {e}")
    @staticmethod
    def get_object_metadata_and_attribute_id(config_manager: ConfigManager, object_name: str,
                                             attribute_name: str) -> \
            tuple[int, str, int, str]:
        """
        Extract class ID, logical name, attribute ID and attribute type from data model for a given object and attribute.

        Args:
            config_manager: Configuration manager instance
            object_name: Name of the COSEM object
            attribute_name: Name of the attribute
            
        Returns:
            Tuple of (class_id, obis_code, attribute_id, attribute_type)
            Example: (3, "0100021D00FF", 1, "OCTET_STRING")

        Raises:
            RuntimeError: If object/attribute not found or invalid data model
        """
        if config_manager is None:
            raise RuntimeError("Configuration not loaded. Call load_configuration() first.")

        # Get object configuration from data model (single call)
        # data_model = config_manager.get_data_model(object_name)
        data_model = config_manager.datamodel[object_name]
        if data_model is None:
            raise RuntimeError(f"Object '{object_name}' not found in data model")

        # Get class ID and logical name from data model
        class_id = data_model.classId
        logical_name = data_model.logicalName

        if class_id is None or logical_name is None:
            # ConfigModuleProxy auto-creates stubs for missing objects;
            # classId/logicalName will be None when the object does not exist.
            raise RuntimeError(
                f"Object '{object_name}' not found in data model "
                f"(no classId/logicalName). Check the object name matches "
                f"a .json5 file under configuration/datamodel/."
            )

        # Find the attribute in the data model
        dlms_attributes = data_model.dlmsAttribute
        attribute_id = None
        attribute_type = None

        for attr in dlms_attributes:
            if attr.get('name') == attribute_name:
                attribute_id = int(attr.get('id'))
                # Extract just the type string from dlmsType
                dlms_type_dict = attr.get('dlmsType')
                if dlms_type_dict:
                    attribute_type = dlms_type_dict.get('type')
                break

        if attribute_id is None:
            raise RuntimeError(f"Attribute '{attribute_name}' not found in object '{object_name}'")

        # Convert logical name to OBIS code (format: "0;3;24;1;0;255" -> "0003180100FF")
        obis_code = CoreHelper.convert_obis_to_hex(logical_name)

        logger.debug(f"Found attribute '{attribute_name}' in object '{object_name}' with ID {attribute_id}, type '{attribute_type}'",
                     **CoreHelper._mod)
        logger.debug(f"Converted logical name '{logical_name}' to OBIS code '{obis_code}'",
                     **CoreHelper._mod)

        return class_id, obis_code, attribute_id, attribute_type

    @staticmethod
    def get_object_metadata_and_method_id(config_manager: ConfigManager, object_name: str, method_name: str) -> \
            tuple[
                int, str, int, str]:
        """
        Extract class ID, logical name, method ID and method type from data model for a given object and method.

        Args:
            config_manager: Configuration manager instance
            object_name: Name of the COSEM object
            method_name: Name of the method
            
        Returns:
            Tuple of (class_id, obis_code, method_id, method_type)
            Example: (3, "0100021D00FF", 1, "OCTET_STRING")

        Raises:
            RuntimeError: If object/method not found or invalid data model
        """
        if config_manager is None:
            raise RuntimeError("Configuration not loaded. Call load_configuration() first.")

        # Get object configuration from data model (single call)
        # data_model = config_manager.get_data_model(object_name)
        data_model = config_manager.datamodel[object_name]
        if data_model is None:
            raise RuntimeError(f"Object '{object_name}' not found in data model")

        # Get class ID and logical name from data model
        class_id = data_model.classId
        logical_name = data_model.logicalName

        if class_id is None or logical_name is None:
            # ConfigModuleProxy auto-creates stubs for missing objects;
            # classId/logicalName will be None when the object does not exist.
            raise RuntimeError(
                f"Object '{object_name}' not found in data model "
                f"(no classId/logicalName). Check the object name matches "
                f"a .json5 file under configuration/datamodel/."
            )

        # Find the method in the data model
        dlms_methods = data_model.dlmsMethod
        method_id = None
        method_type = None

        for method in dlms_methods:
            if method.get('name') == method_name:
                method_id = int(method.get('id'))
                # Extract just the type string from dlmsType
                dlms_type_dict = method.get('dlmsType')
                if dlms_type_dict:
                    method_type = dlms_type_dict.get('type')
                break

        if method_id is None:
            raise RuntimeError(f"Method '{method_name}' not found in object '{object_name}'")

        # Convert logical name to OBIS code (format: "0;3;24;1;0;255" -> "0003180100FF")
        obis_code = CoreHelper.convert_obis_to_hex(logical_name)

        logger.debug(f"Found method '{method_name}' in object '{object_name}' with ID {method_id}, type '{method_type}'",
                     **CoreHelper._mod)
        logger.debug(f"Converted logical name '{logical_name}' to OBIS code '{obis_code}'",
                     **CoreHelper._mod)

        return class_id, obis_code, method_id, method_type


# =============================================================================
# BACKWARD COMPATIBILITY FUNCTIONS
# =============================================================================

def ensure_configuration_loaded(config_manager: Optional[ConfigManager]) -> None:
    """Backward compatibility wrapper for ensure_configuration_loaded."""
    core_helper = CoreHelper()
    return core_helper.ensure_configuration_loaded(config_manager)


def ensure_connected(is_connected: bool) -> None:
    """Backward compatibility wrapper for ensure_connected."""
    core_helper = CoreHelper()
    return core_helper.ensure_connected(is_connected)


def ensure_components_initialized(security_context: Optional[SecurityContext],
                                  frame_builder: Optional[DLMSFrameBuilder]) -> bool:
    """Backward compatibility wrapper for ensure_components_initialized."""
    core_helper = CoreHelper()
    return core_helper.ensure_components_initialized(security_context, frame_builder)


def initialize_components(config_manager: ConfigManager, client_name: str) -> Tuple[SecurityContext, DLMSFrameBuilder]:
    """Backward compatibility wrapper for initialize_components."""
    core_helper = CoreHelper()
    return core_helper.initialize_components(config_manager, client_name)


def get_session_type(config: ConfigModuleProxy) -> str:
    """Backward compatibility wrapper for get_session_type."""
    core_helper = CoreHelper()
    return core_helper.get_session_type(config)


def get_security_policy(config: ConfigModuleProxy) -> str:
    """Backward compatibility wrapper for get_security_policy."""
    core_helper = CoreHelper()
    return core_helper.get_security_policy(config)


def is_valid_session_type(session_type: str) -> bool:
    """Backward compatibility wrapper for is_valid_session_type."""
    core_helper = CoreHelper()
    return core_helper.is_valid_session_type(session_type)


def needs_frame_counter(security_policy: str) -> bool:
    """Backward compatibility wrapper for needs_frame_counter."""
    core_helper = CoreHelper()
    return core_helper.needs_frame_counter(security_policy)


def requires_authentication(session_type: str) -> bool:
    """Backward compatibility wrapper for requires_authentication."""
    core_helper = CoreHelper()
    return core_helper.requires_authentication(session_type)


def convert_logical_name_to_obis(logical_name: str) -> str:
    """Backward compatibility wrapper for convert_logical_name_to_obis."""
    return CoreHelper.convert_obis_to_hex(logical_name)


def get_object_metadata_and_attribute_id(config_manager: ConfigManager, object_name: str, attribute_name: str) -> tuple[
    int, str, int,str]:
    """Backward compatibility wrapper for get_object_metadata_and_attribute_id."""
    return CoreHelper.get_object_metadata_and_attribute_id(config_manager, object_name, attribute_name)


def get_object_metadata_and_method_id(config_manager: ConfigManager, object_name: str, method_name: str) -> tuple[
    int, str, int,str]:
    """Backward compatibility wrapper for get_object_metadata_and_method_id."""
    return CoreHelper.get_object_metadata_and_method_id(config_manager, object_name, method_name)
