"""
DLMS response processing utilities.
Processes DLMS operation responses and formats them into structured dictionaries
with comprehensive frame details and error information.
"""
from pathlib import Path
from typing import Dict, Any, Optional

import json5

from ng_sdk.frame_builder.dlms.xdlms.exception.dlms_exception_response import DLMSExceptionResponse
from ng_sdk.logger.logger import LoggingConstants, get_logger

logger = get_logger()


class DLMSResponseProcessor:
    """
    Processes DLMS operation responses into structured result dictionaries.
    
    Handles both successful and error responses, integrates frame transmission details,
    and provides custom error descriptions from configuration files.
    """

    def __init__(self, config_dir: Optional[str] = None):
        """
        Initialize response processor with optional configuration directory.
        
        Args:
            config_dir: Path to configuration directory containing auto_tools.json5
        """
        self._mod = {LoggingConstants.MODULES_NAME: "DLMSResponseProcessor"}  # module tag for logs
        self._config_dir = config_dir
        self._config = None  # Full configuration from auto_tools.json5
        self._error_codes = None
        self._success_messages = None
        self._options = None
        self._load_configuration()

    def _load_configuration(self):
        """Load complete configuration from auto_tools.json5 if available."""
        if not self._config_dir:
            logger.debug("No config directory provided, using minimal configuration",
                         **self._mod)
            self._set_default_configuration()
            return

        try:
            # Try robot_dlms/configuration first (new location)
            auto_tools_file = Path.cwd() / "robot_dlms/configuration/auto_tools.json5"

            if auto_tools_file.exists():
                with open(auto_tools_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                    self._config = json5.loads(content)

                    # Load all configuration sections
                    self._error_codes = self._config.get('error_descriptions', {})
                    self._success_messages = self._config.get('success_messages', {})
                    self._options = self._config.get('options', {})

                    logger.trace(f"Loaded configuration from auto_tools.json5: ",
                                 **self._mod)
            else:
                logger.warning("auto_tools.json5 not found, using default configuration",
                               **self._mod)
                self._set_default_configuration()
        except Exception as e:
            logger.error(f"Failed to load configuration from auto_tools.json5: {e}",
                         **self._mod)
            self._set_default_configuration()

    def _set_default_configuration(self):
        """Set minimal default configuration when auto_tools.json5 is not available."""
        self._config = {}
        self._error_codes = {}
        self._success_messages = {
            "get": "Data retrieved successfully",
            "set": "Value updated successfully",
            "action": "Method executed successfully"
        }
        self._options = {
            "use_hex_error_codes": False,
            "include_raw_error_in_description": True,
            "fallback_to_default": False,  # Changed: No fallback by default
            "raise_on_missing_error": True  # New: Raise exception for missing errors
        }

    def _get_config_options(self) -> Dict[str, Any]:
        """Get configuration options, returning defaults if not loaded."""
        return self._options or {
            "use_hex_error_codes": False,
            "include_raw_error_in_description": True,
            "fallback_to_default": False,  # Changed: No fallback by default
            "raise_on_missing_error": True  # New: Raise exception for missing errors
        }

    @staticmethod
    def _apply_field_names(readable_value: Any, field_names: Optional[list]) -> Any:
        if not field_names:
            return readable_value

        if isinstance(readable_value, list):
            return [DLMSResponseProcessor._apply_field_names(item, field_names) for item in readable_value]

        if isinstance(readable_value, dict):
            keys = list(readable_value.keys())
            has_generic_keys = all(
                isinstance(key, str) and key.startswith("key") and key[3:].isdigit()
                for key in keys
            )
            if has_generic_keys and len(readable_value) == len(field_names):
                mapped = {}
                for index, name in enumerate(field_names):
                    mapped[name] = readable_value.get(f"key{index}")
                return mapped

        return readable_value

    def get_error_description(self, error_code: int, error_name: str) -> str:
        """
        Get error description for a given error code from configuration.
        
        Args:
            error_code: Numeric error code
            error_name: Error name/type
            
        Returns:
            Human-readable error description from auto_tools.json5
            
        Raises:
            RuntimeError: If error code not found in error_descriptions and raise_on_missing_error is True
        """
        # First try to get from loaded configuration
        if self._error_codes and str(error_code) in self._error_codes:
            return self._error_codes[str(error_code)]

        # Check configuration options for behavior when error not found
        options = self._get_config_options()

        # New behavior: raise exception if configured to do so
        if options.get("raise_on_missing_error", True):
            error_msg = f"Error code {error_code} ({error_name}) not found in error_descriptions configuration"
            logger.error(error_msg, **self._mod)
            raise RuntimeError(error_msg)

        # Legacy fallback behavior (only if explicitly enabled)
        if options.get("fallback_to_default", False):
            # Construct fallback description based on configuration options
            if options.get("include_raw_error_in_description", True):
                fallback = f"{error_name} (Code: {error_code})"
            else:
                fallback = error_name

            if options.get("use_hex_error_codes", False):
                fallback = fallback.replace(f"Code: {error_code}", f"Code: 0x{error_code:02X}")

            logger.warning(f"Error code {error_code} not found in auto_tools.json5, using fallback: {fallback}",
                           **self._mod)

            return fallback
        else:
            # No fallback allowed, return minimal description
            return f"Unknown error {error_code}"

    def _build_exception_response_result(self, response: DLMSExceptionResponse,
                                          frame_details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Build an error result from a DLMSExceptionResponse."""
        state = response.state_error.name if response.state_error else "UNKNOWN_STATE"
        service = response.service_error.name if response.service_error else "UNKNOWN_SERVICE"
        error_description = f"EXCEPTION_RESPONSE: {state} / {service}"
        logger.warning(f"Meter returned exception-response: state_error={state}, service_error={service}",
                       **self._mod)
        result = {
            "success": False,
            "value": None,
            "data_type": None,
            "error_code": 999,
            "error_description": error_description,
        }
        if frame_details:
            result["communication_details"] = frame_details
        return result

    def _build_exception_response_with_list_result(self, response: DLMSExceptionResponse,
                                                    frame_details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Build a with-list-style error result from a DLMSExceptionResponse."""
        state = response.state_error.name if response.state_error else "UNKNOWN_STATE"
        service = response.service_error.name if response.service_error else "UNKNOWN_SERVICE"
        error_description = f"EXCEPTION_RESPONSE: {state} / {service}"
        logger.warning(f"Meter returned exception-response: state_error={state}, service_error={service}",
                       **self._mod)
        result = {
            "success": False,
            "results": [],
            "total_requested": 0,
            "successful_count": 0,
            "failed_count": 0,
            "error_code": 999,
            "error_description": error_description,
        }
        comm_details = dict(frame_details) if frame_details else {}
        result["communication_details"] = comm_details
        return result

    def create_success_result(self, value_hex: str, raw_data: Any = None,
                              frame_details: Optional[Dict[str, Any]] = None,
                              operation_type: str = "operation",
                              field_names: Optional[list] = None) -> Dict[str, Any]:
        """
        Create a structured success result dictionary.
        
        Args:
            value_hex: Hexadecimal representation of the value
            raw_data: Optional raw response object
            frame_details: Optional frame transmission details
            operation_type: Type of operation (get, set, action) for success message
            
        Returns:
            Success result dictionary with frame details
        """
        # Get success description from configuration or use generic success
        success_description = self.get_success_description(operation_type)
        if hasattr(raw_data, 'to_readable_format'):
            readable_format = raw_data.to_readable_format(keys=field_names)
        else:
            readable_format = raw_data

        result = {
            "success": True,
            "value": value_hex,
            "data_type": type(raw_data).__name__ if (raw_data is not None and hasattr(raw_data, 'to_bytes')) else None,
            "error_code": 0,
            "error_description": success_description,
            "raw_data": raw_data.to_bytes().hex().upper() if raw_data and hasattr(raw_data, 'to_bytes') else raw_data,
            "readable_data": readable_format,
        }

        if frame_details:
            result["communication_details"] = frame_details

        return result

    def get_success_description(self, operation_type: str = "operation") -> str:
        """
        Get success description for a given operation type from configuration.
        
        Args:
            operation_type: Type of operation (get, set, action)
            
        Returns:
            Success message from auto_tools.json5 or default
        """
        # Try to get success code 0 from error descriptions first
        if self._error_codes and "0" in self._error_codes:
            return self._error_codes["0"]

        # Try to get from success messages
        if self._success_messages and operation_type in self._success_messages:
            return self._success_messages[operation_type]

        # Fallback to generic success message
        return "Operation completed successfully"

    def reload_configuration(self):
        """
        Reload configuration from auto_tools.json5.
        Useful when configuration file has been updated at runtime.
        """
        logger.info("Reloading configuration from auto_tools.json5",
                    **self._mod)
        self._load_configuration()

    def validate_configuration(self) -> Dict[str, Any]:
        """
        Validate the current configuration and return validation results.
        
        Returns:
            Dictionary with validation results and statistics
        """
        validation_result = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "statistics": {
                "error_codes_count": len(self._error_codes or {}),
                "success_messages_count": len(self._success_messages or {}),
                "has_config_file": self._config is not None,
                "raise_on_missing_error": self._get_config_options().get("raise_on_missing_error", True)
            }
        }

        # Check if configuration was loaded
        if not self._config:
            validation_result["warnings"].append("No auto_tools.json5 configuration loaded, using defaults")

        # Check for common error codes
        common_error_codes = ["1", "2", "3", "4", "250"]
        missing_codes = []

        if self._error_codes:
            for code in common_error_codes:
                if code not in self._error_codes:
                    missing_codes.append(code)

        if missing_codes:
            validation_result["warnings"].append(f"Common error codes not defined: {missing_codes}")

        # Check success messages
        expected_operations = ["get", "set", "action"]
        if self._success_messages:
            missing_operations = [op for op in expected_operations if op not in self._success_messages]
            if missing_operations:
                validation_result["warnings"].append(f"Success messages not defined for: {missing_operations}")
        else:
            validation_result["warnings"].append("No success messages defined")

        # Check strict error handling configuration
        options = self._get_config_options()
        if options.get("raise_on_missing_error", True):
            validation_result["statistics"]["strict_mode"] = True
            if not self._error_codes:
                validation_result["errors"].append("Strict error mode enabled but no error_descriptions defined")
        else:
            validation_result["statistics"]["strict_mode"] = False

        logger.debug("Configuration validation completed",
                     **self._mod)

        return validation_result

    def get_configuration_info(self) -> Dict[str, Any]:
        """
        Get detailed information about the loaded configuration.
        
        Returns:
            Dictionary with configuration information
        """
        options = self._get_config_options()

        return {
            "config_file_loaded": self._config is not None,
            "config_directory": self._config_dir,
            "total_error_codes": len(self._error_codes or {}),
            "total_success_messages": len(self._success_messages or {}),
            "options": options,
            "available_error_codes": list(self._error_codes.keys()) if self._error_codes else [],
            "strict_mode_enabled": options.get("raise_on_missing_error", True)
        }

    def create_error_result(self, error_code: int, error_name: str, raw_data: Any = None,
                            raise_exception: bool = False,
                            frame_details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Create a structured error result dictionary.
        
        Args:
            error_code: Numeric error code
            error_name: Error name/type
            raw_data: Optional raw response object
            raise_exception: Whether to raise exception for unknown errors (overrides config)
            frame_details: Optional frame transmission details
            
        Returns:
            Error result dictionary with frame details
            
        Raises:
            RuntimeError: If error code not found in error_descriptions and exceptions are enabled
        """
        try:
            error_description = self.get_error_description(error_code, error_name)
        except RuntimeError:
            # Don't log here - get_error_description already logged
            # Just re-raise if strict mode is enabled
            if raise_exception or self._get_config_options().get("raise_on_missing_error", True):
                raise
            # Minimal fallback
            error_description = f"Unknown error {error_code}: {error_name}"

        result = {
            "success": False,
            "value": None,
            "data_type": None,
            "error_code": error_code,
            "error_description": error_description,
            "raw_data": raw_data
        }

        if frame_details:
            result["communication_details"] = frame_details

        return result

    def process_get_response(self, response, raise_unknown_errors: bool = False,
                             frame_details: Optional[Dict[str, Any]] = None,
                             field_names: Optional[list] = None) -> Dict[str, Any]:
        """
        Process a DLMS GET response into a structured result dictionary.
        
        Args:
            response: DLMS GET response object
            raise_unknown_errors: Whether to raise exception for unknown errors
            frame_details: Optional frame transmission details
            field_names: Optional list of field names for structure key mapping
            
        Returns:
            Structured result dictionary with success/error info and frame details
        """
        if isinstance(response, DLMSExceptionResponse):
            return self._build_exception_response_result(response, frame_details)
        try:
            if response.is_success():
                if hasattr(response, 'data') and response.data:
                    if not isinstance(response.data.value, (bytes, bytearray)):
                        value_hex = str(response.data.value)
                    else:
                        value_hex = bytes(response.data.value).hex().upper()
                    return self.create_success_result(value_hex, response.data, frame_details, "get",
                                                       field_names=field_names)
                else:
                    return self.create_success_result("", response, frame_details, "get",
                                                       field_names=field_names)
            else:
                error_code = response.data_access_result.value
                error_name = response.data_access_result.name
                return self.create_error_result(error_code, error_name, response,
                                                raise_unknown_errors, frame_details)
        except RuntimeError:
            # Don't log here - the error was already logged in get_error_description
            # Just re-raise the exception
            raise
        except Exception as e:
            # Only log unexpected processing errors
            logger.error(f"Error processing GET response: {e}",
                         **self._mod)
            return self.create_error_result(255, "PROCESSING_ERROR", response,
                                            raise_unknown_errors, frame_details)

    def process_set_response(self, response, raise_unknown_errors: bool = False,
                             frame_details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Process a DLMS SET response into a structured result dictionary.
        
        Args:
            response: DLMS SET response object
            raise_unknown_errors: Whether to raise exception for unknown errors
            frame_details: Optional frame transmission details
            
        Returns:
            Structured result dictionary with success/error info and frame details
        """
        if isinstance(response, DLMSExceptionResponse):
            return self._build_exception_response_result(response, frame_details)
        try:
            if response.is_success():
                result = self.create_success_result(None, None, frame_details, "set")
                result.pop('raw_data', None)
                result.pop('readable_data', None)
                return result
            else:
                error_code = response.data_access_result.value
                error_name = response.data_access_result.name
                result = self.create_error_result(error_code, error_name, response,
                                                raise_unknown_errors, frame_details)
                result.pop('raw_data', None)
                return result
        except RuntimeError:
            # Don't log here - error was already logged at source
            # Just re-raise for strict mode
            raise
        except Exception as e:
            # Only log truly unexpected errors
            logger.error(f"Error processing SET response: {e}",
                         **self._mod)
            result = self.create_error_result(255, "PROCESSING_ERROR", response,
                                            raise_unknown_errors, frame_details)
            result.pop('raw_data', None)
            return result

    def process_set_response_with_list(self, response, raise_unknown_errors: bool = False,
                                       frame_details: Optional[Dict[str, Any]] = None,
                                       objects_list: Optional[list] = None) -> Dict[str, Any]:
        """
        Process a DLMS SET-WITH-LIST response into a structured result dictionary.

        Args:
            response: DLMS SET-WITH-LIST response object (DLMSSetResponseWithList)
            raise_unknown_errors: Whether to raise exception for unknown errors
            frame_details: Optional frame transmission details
            objects_list: Optional list of requested objects (for reference in result)

        Returns:
            Structured result dictionary with list of individual results.
        """
        if isinstance(response, DLMSExceptionResponse):
            return self._build_exception_response_with_list_result(response, frame_details)
        try:
            results_list = []
            successful_count = 0
            failed_count = 0

            if hasattr(response, 'result') and response.result:
                for set_result in response.result:
                    error_code = getattr(set_result, 'value', 255)
                    error_name = getattr(set_result, 'name', str(set_result))

                    if error_code == 0:
                        result_item = {
                            "success": True,
                            "value": "None",
                            "error_code": 0,
                            "error_description": self._success_messages.get("set", "Data written successfully"),
                        }
                        successful_count += 1
                    else:
                        try:
                            error_description = self.get_error_description(error_code, error_name)
                        except RuntimeError:
                            if raise_unknown_errors or self._get_config_options().get("raise_on_missing_error", True):
                                raise
                            error_description = f"Unknown error {error_code}: {error_name}"

                        result_item = {
                            "success": False,
                            "value": None,
                            "error_code": error_code,
                            "error_description": error_description,
                        }
                        failed_count += 1

                    results_list.append(result_item)

            formatted_objects_list = []
            if objects_list:
                for obj in objects_list:
                    value = obj.get('value')
                    if isinstance(value, (bytes, bytearray)):
                        value_repr = bytes(value).hex().upper()
                    else:
                        value_repr = value

                    formatted_objects_list.append([
                        obj.get('class_id'),
                        obj.get('obis_code'),
                        obj.get('attribute_id'),
                        value_repr
                    ])

            overall_result = {
                "success": failed_count == 0,
                "results": results_list,
                "total_requested": len(results_list),
                "successful_count": successful_count,
                "failed_count": failed_count,
            }

            comm_details = dict(frame_details) if frame_details else {}
            comm_details["objects_list"] = formatted_objects_list
            overall_result["communication_details"] = comm_details
            return overall_result

        except RuntimeError:
            raise
        except Exception as e:
            logger.error(f"Error processing SET-WITH-LIST response: {e}",
                         **self._mod)
            return {
                "success": False,
                "results": [],
                "total_requested": 0,
                "successful_count": 0,
                "failed_count": 0,
                "error_code": 255,
                "error_description": f"PROCESSING_ERROR: {str(e)}",
            }

    def process_action_response(self, response, raise_unknown_errors: bool = False,
                                frame_details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Process a DLMS ACTION response into a structured result dictionary.
        
        Args:
            response: DLMS ACTION response object
            raise_unknown_errors: Whether to raise exception for unknown errors
            frame_details: Optional frame transmission details
            
        Returns:
            Structured result dictionary with success/error info and frame details
        """
        if isinstance(response, DLMSExceptionResponse):
            return self._build_exception_response_result(response, frame_details)
        try:
            if response.is_success():
                if hasattr(response,
                           'return_parameter') and response.return_parameter and response.return_parameter.data:
                    if not isinstance(response.return_parameter.data.value, (bytes, bytearray)):
                        value_hex = str(response.return_parameter.data.value)
                    else:
                        value_hex = bytes(response.return_parameter.data.value).hex().upper()
                    return self.create_success_result(value_hex, response.return_parameter.data, frame_details,
                                                      "action")
                else:
                    return self.create_success_result("ACTION_SUCCESS", None, frame_details, "action")
            else:
                if hasattr(response, 'return_parameter') and response.return_parameter:
                    error_code = response.return_parameter.data_access_result.value
                    error_name = response.return_parameter.data_access_result.name
                else:
                    error_code = response.result.value
                    error_name = response.result.name
                return self.create_error_result(error_code, error_name, response,
                                                raise_unknown_errors, frame_details)
        except RuntimeError:
            # Don't log here - error was already logged at source
            # Just re-raise for strict mode
            raise
        except Exception as e:
            # Only log truly unexpected errors
            logger.error(f"Error processing ACTION response: {e}",
                         **self._mod)
            return self.create_error_result(255, "PROCESSING_ERROR", response,
                                            raise_unknown_errors, frame_details)

    def process_action_response_with_list(self, response, raise_unknown_errors: bool = False,
                                          frame_details: Optional[Dict[str, Any]] = None,
                                          objects_list: Optional[list] = None) -> Dict[str, Any]:
        """
        Process a DLMS ACTION-WITH-LIST response into a structured result dictionary.

        Args:
            response: DLMS ACTION-WITH-LIST response object (DLMSActionResponseWithList)
            raise_unknown_errors: Whether to raise exception for unknown errors
            frame_details: Optional frame transmission details
            objects_list: Optional list of requested objects (for reference in result)

        Returns:
            Structured result dictionary with list of individual results.
        """
        if isinstance(response, DLMSExceptionResponse):
            return self._build_exception_response_with_list_result(response, frame_details)
        try:
            results_list = []
            successful_count = 0
            failed_count = 0

            if hasattr(response, 'list_of_responses') and response.list_of_responses:
                for action_item in response.list_of_responses:
                    action_result = getattr(action_item, 'result', None)
                    error_code = getattr(action_result, 'value', 255)
                    error_name = getattr(action_result, 'name', str(action_result))

                    if error_code == 0:
                        response_value = None
                        raw_data = getattr(action_item, 'return_parameter', None)

                        if raw_data and hasattr(raw_data, 'data') and raw_data.data is not None:
                            if not isinstance(raw_data.data.value, (bytes, bytearray)):
                                response_value = str(raw_data.data.value)
                            else:
                                response_value = bytes(raw_data.data.value).hex().upper()

                        result_item = {
                            "success": True,
                            "value": response_value,
                            "error_code": 0,
                            "error_description": self._success_messages.get("action", "Method executed successfully"),
                        }
                        successful_count += 1
                    else:
                        response_value = None
                        try:
                            error_description = self.get_error_description(error_code, error_name)
                        except RuntimeError:
                            if raise_unknown_errors or self._get_config_options().get("raise_on_missing_error", True):
                                raise
                            error_description = f"Unknown error {error_code}: {error_name}"

                        raw_data = getattr(action_item, 'return_parameter', None)

                        if raw_data and hasattr(raw_data, 'data') and raw_data.data is not None:
                            if not isinstance(raw_data.data.value, (bytes, bytearray)):
                                response_value = str(raw_data.data.value)
                            else:
                                response_value = bytes(raw_data.data.value).hex().upper()
                        result_item = {
                            "success": False,
                            "value": response_value,
                            "error_code": error_code,
                            "error_description": error_description,
                        }
                        failed_count += 1

                    results_list.append(result_item)

            formatted_objects_list = []
            if objects_list:
                for obj in objects_list:
                    parameters = obj.get('parameters')
                    if isinstance(parameters, (bytes, bytearray)):
                        parameters_repr = bytes(parameters).hex().upper()
                    else:
                        parameters_repr = parameters

                    formatted_objects_list.append([
                        obj.get('class_id'),
                        obj.get('obis_code'),
                        obj.get('method_id'),
                        parameters_repr
                    ])

            overall_result = {
                "success": failed_count == 0,
                "results": results_list,
                "total_requested": len(results_list),
                "successful_count": successful_count,
                "failed_count": failed_count,
            }

            comm_details = dict(frame_details) if frame_details else {}
            comm_details["objects_list"] = formatted_objects_list
            overall_result["communication_details"] = comm_details

            return overall_result

        except RuntimeError:
            raise
        except Exception as e:
            logger.error(f"Error processing ACTION-WITH-LIST response: {e}",
                         **self._mod)
            return {
                "success": False,
                "results": [],
                "total_requested": 0,
                "successful_count": 0,
                "failed_count": 0,
                "error_code": 255,
                "error_description": f"PROCESSING_ERROR: {str(e)}",
            }

    def process_get_response_with_list(self, response, raise_unknown_errors: bool = False,
                                       frame_details: Optional[Dict[str, Any]] = None,
                                       objects_list: Optional[list] = None) -> Dict[str, Any]:
        """
        Process a DLMS GET-WITH-LIST response into a structured result dictionary.
        
        Args:
            response: DLMS GET-WITH-LIST response object (DLMSGetResponseWithList)
            raise_unknown_errors: Whether to raise exception for unknown errors
            frame_details: Optional frame transmission details
            objects_list: Optional list of requested objects (for reference in result)
            
        Returns:
            Structured result dictionary with list of individual results:
            {
                "success": bool,
                "results": [
                    {
                        "success": bool,
                        "value": str (hex) or None,
                        "error_code": int,
                        "error_description": str,
                        "raw_data": object or None
                    },
                    ...
                ],
                "total_requested": int,
                "successful_count": int,
                "failed_count": int,
                "result_tuple": tuple(bool, list[str]),  # (global success, [raw values or '' if failure])
                "objects_list": list,  # [[class_id, obis_code, attribute_id], ...]
                "frame_details": {...}  # if provided
            }
            
        Example result_tuple:
            (False, ['090C07EA021203092924FFFFC400', '', '093020202020...'])
            - First element: True if all results are successful, False otherwise
            - Second element: List with hex values for success, '' for failures

        Example objects_list:
            [[1, '0000600100FF', 2], [1, '0300600101FF', 2], [1, '0000600102FF', 2]]
        """
        if isinstance(response, DLMSExceptionResponse):
            return self._build_exception_response_with_list_result(response, frame_details)
        try:
            results_list = []
            successful_count = 0
            failed_count = 0
            raw_values_list = []  # List for the final tuple (value or '' if failure)

            # Process each result in the list
            if hasattr(response, 'result') and response.result:
                for idx, get_data_result in enumerate(response.result):
                    # Check if this is a success or error
                    data_access_result = getattr(get_data_result, 'data_access_result', None)
                    if data_access_result is not None and data_access_result.value != 0:
                        # This is an error result
                        error_code = data_access_result.value
                        error_name = data_access_result.name
                        
                        try:
                            error_description = self.get_error_description(error_code, error_name)
                        except RuntimeError:
                            if raise_unknown_errors or self._get_config_options().get("raise_on_missing_error", True):
                                raise
                            error_description = f"Unknown error {error_code}: {error_name}"
                        
                        result_item = {
                            "success": False,
                            "value": None,
                            "error_code": error_code,
                            "error_description": error_description,
                        }
                        failed_count += 1
                        raw_values_list.append('')  # Empty string for failures
                    else:
                        # This is a success result with data
                        if hasattr(get_data_result, 'data') and get_data_result.data:
                            if not isinstance(get_data_result.data.value, (bytes, bytearray)):
                                value_hex = str(get_data_result.data.value)
                            else:
                                value_hex = bytes(get_data_result.data.value).hex().upper()
                            
                            # Get the raw value for the tuple
                            if hasattr(get_data_result.data, 'to_bytes'):
                                raw_hex = get_data_result.data.to_bytes().hex().upper()
                            else:
                                raw_hex = value_hex

                            field_names = None
                            if objects_list and idx < len(objects_list):
                                field_names = objects_list[idx].get("field_names")

                            if hasattr(get_data_result.data, 'to_readable_format'):
                                readable_format = get_data_result.data.to_readable_format(keys=field_names)
                            else:
                                readable_format = value_hex
                            
                            result_item = {
                                "success": True,
                                "value": readable_format,
                                "error_code": 0,
                                "error_description": self._success_messages.get("get", "Data retrieved successfully"),
                            }
                            successful_count += 1
                            raw_values_list.append(raw_hex)  # Hex value for successes
                        else:
                            result_item = {
                                "success": True,
                                "value": "",
                                "error_code": 0,
                                "error_description": self._success_messages.get("get", "Data retrieved successfully"),
                            }
                            successful_count += 1
                            raw_values_list.append('')  # Empty string if no data

                    results_list.append(result_item)
            
            # Create the final tuple (global success, [list_raw_values])
            result_tuple = (failed_count == 0, raw_values_list)
            
            # Create the list of requested objects in the format [[class_id, obis_code, attribute_id], ...]
            formatted_objects_list = []
            if objects_list:
                for obj in objects_list:
                    formatted_objects_list.append([
                        obj.get('class_id'),
                        obj.get('obis_code'),
                        obj.get('attribute_id')
                    ])
            
            # Create overall result
            overall_result = {
                "success": failed_count == 0,  # Overall success if no failures
                "results": results_list,
                "total_requested": len(results_list),
                "successful_count": successful_count,
                "failed_count": failed_count,
            }
            
            # Always create communication_details with objects_list and result_tuple
            comm_details = dict(frame_details) if frame_details else {}
            comm_details["objects_list"] = formatted_objects_list
            comm_details["result_tuple"] = result_tuple
            overall_result["communication_details"] = comm_details
            return overall_result
            
        except RuntimeError:
            # Don't log here - the error was already logged in get_error_description
            # Just re-raise the exception
            raise
        except Exception as e:
            # Only log unexpected processing errors
            logger.error(f"Error processing GET-WITH-LIST response: {e}",
                         **self._mod)
            return {
                "success": False,
                "results": [],
                "total_requested": 0,
                "successful_count": 0,
                "failed_count": 0,
                "error_code": 255,
                "error_description": f"PROCESSING_ERROR: {str(e)}",
                "raw_data": response
            }


# =============================================================================
# BACKWARD COMPATIBILITY ALIAS
# =============================================================================

class DLMSErrorHandler(DLMSResponseProcessor):
    """
    Backward compatibility alias for DLMSResponseProcessor.
    
    @deprecated: Use DLMSResponseProcessor instead.
    This alias is maintained for backward compatibility with existing code.
    """

    def __init__(self, config_dir: Optional[str] = None):
        """Initialize with backward compatibility warning."""
        logger.warning("DLMSErrorHandler is deprecated, use DLMSResponseProcessor instead",
                       **self._mod)
        super().__init__(config_dir)
