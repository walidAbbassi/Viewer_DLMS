"""
Dedicated session management for DLMS connections.
Handles all session lifecycle operations in a centralized location.
"""

from typing import Optional, Tuple

from ng_sdk.api_helpers.core_helpers import CoreHelper, PUBLIC_CLIENT_NAME, SESSION_TYPE_HLS, SESSION_TYPE_LLS, \
    needs_frame_counter, SERIAL_COMMUNICATION, HDLC, HDLC_DIRECT, HDLC_MODE_E
from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.communication.hdlc_communication import HDLCCommunication
from ng_sdk.communication.hdlc_mode_e_communication import HDLCModeECommunication
from ng_sdk.communication.lower.serial_communication import SerialCommunication
from ng_sdk.communication.tcp_communication import TCPCommunication
from ng_sdk.configuration.config_manager import ConfigManager, ConfigModuleProxy
from ng_sdk.frame_builder.dlms.acse.models.conformance import Conformance
from ng_sdk.frame_builder.dlms.dlms_frame_builder import DLMSFrameBuilder
from ng_sdk.frame_executor.dlms.dlms_executor import DLMSExecutor
from ng_sdk.frame_executor.dlms.gbt_dlms_executor import GBTDLMSExecutor
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.session.abstract_session import AbstractSession
from ng_sdk.session.dlms_hls_session import DLMSHlsSession
from ng_sdk.session.dlms_password_session import DLMSPasswordSession
from ng_sdk.session.dlms_session import DLMSSession
from ng_sdk.transport.hdlc.hdlc_transport import HDLCTransport

logger = get_logger()


class DLMSSessionManager:
    """
    Centralized session management for DLMS connections.
    
    This class handles all the complexity of establishing, maintaining,
    and closing DLMS sessions, abstracting the details from the main API.
    """

    def __init__(self):
        """Initialize the session manager."""
        # Core components
        self.communication = None
        self.session = None
        self.frame_executor: Optional[DLMSExecutor] = None
        self.frame_builder: Optional[DLMSFrameBuilder] = None
        self.security_context: Optional[SecurityContext] = None
        self.is_connected: bool = False

        # Helper managers
        self._core_helper = CoreHelper()
        self._mod = {LoggingConstants.MODULES_NAME: "DLMSSessionManager"}  # module tag for logs

    def connect(self, config_manager: ConfigManager, client_name: str) -> None:
        """
        Establish connection to the DLMS device.
        Args:
            config_manager: Configuration manager instance
            client_name: Name of the client configuration to use
        Raises:
            RuntimeError: If configuration is not loaded or connection fails
        """
        self._core_helper.ensure_configuration_loaded(config_manager)

        # Initialize components if not already done
        self.security_context, self.frame_builder = self._core_helper.initialize_components(
            config_manager, client_name
        )

        logger.trace("Establishing connection to DLMS device",
                     **self._mod)

        try:
            # Get configuration proxies
            main_session_config: ConfigModuleProxy = config_manager[client_name]
            public_config: ConfigModuleProxy = config_manager[PUBLIC_CLIENT_NAME]

            # Extract session configuration safely
            public_config.communication.serial.port = main_session_config.communication.serial.port
            public_config.communication.serial.baudrate = main_session_config.communication.serial.baudrate
            public_config.communication.serial.timeout = main_session_config.communication.serial.timeout
            public_config.communication.mode_com = main_session_config.communication.mode_com
            session_type = self._core_helper.get_session_type(main_session_config)
            security_policy = self._core_helper.get_security_policy(main_session_config)

            logger.info(f"Initializing session with type: {session_type}",
                        **self._mod)

            # Check if frame counter retrieval is needed
            self._handle_frame_counter(
                main_session_config, public_config, session_type, security_policy
            )

            # Initialize communication and executor
            logger.info("Initializing communication with main session configuration",
                        **self._mod)
            self.communication, self.frame_executor = self._initialize_communication_and_executor(
                main_session_config, self.frame_builder
            )

            # Create and open the appropriate session
            self.session = self._create_session(
                session_type,
                main_session_config,
                self.communication,
                self.security_context
            )

            if self._open_session_safely(self.session):
                self.is_connected = True
            else:
                raise ConnectionError("Failed to open session")
        except (RuntimeError, ConnectionError, TimeoutError, OSError, ValueError) as e:
            logger.error(f"Failed to establish connection: {e}",
                         **self._mod)
            self.is_connected = False
            raise

    def disconnect(self) -> None:
        """
        Close the connection to the DLMS device.
        Raises:
            RuntimeError: If error occurs during disconnect
        """
        if not self.is_connected:
            logger.warning("Attempted to disconnect when not connected",
                           **self._mod)
            return

        logger.info("Closing connection to DLMS device",
                    **self._mod)

        try:
            if self.session:
                self.session.close()

            self.is_connected = False
            logger.info("Connection closed successfully",
                        **self._mod)

        except (RuntimeError, ConnectionError, OSError) as e:
            logger.error(f"Error during disconnect: {e}",
                         **self._mod)
            # Still mark as disconnected even if there was an error
            self.is_connected = False
            raise

    def _reset_attributes(self) -> None:
        """
        Reset all internal attributes of the session manager.
        Used to avoid code duplication when cleaning up state.
        """
        self.session = None
        self.communication = None
        self.frame_executor = None
        self.frame_builder = None
        self.security_context = None
        self.is_connected = False

    def clear_session(self) -> None:
        """
        Reset the session state and all associated components.
        This method returns the manager to its initial state, cleaning all component references.
        """
        logger.trace("Clearing session state",
                     **self._mod)

        try:
            # Disconnect if connected
            if self.is_connected:
                self.disconnect()
            self._reset_attributes()
            logger.trace("Session state cleared successfully",
                         **self._mod)
        except Exception as e:
            logger.error(f"Error during session clearing: {e}",
                         **self._mod)
            self._reset_attributes()
            raise

    @staticmethod
    def _initialize_communication(config: ConfigModuleProxy) -> AbstractCommunication:
        """
        Initialize the communication stack (physical + transport layer)
        according to configuration.
        Supports:
          - TCP (raw DLMS/TCP wrapper)
          - SERIAL + HDLC
          Args:
            config: Configuration proxy for the session
        Returns:
            Ready-to-use communication instance
        Raises:
            ValueError: If an unsupported type is specified
        """
        link_type = config.communication.link_type
        transport_type = config.communication.transport_type

        if link_type == "tcp":
            lower_comm = TCPCommunication(config)

        elif link_type == SERIAL_COMMUNICATION:
            lower_comm = SerialCommunication(config)

        else:
            raise ValueError(f"Unsupported link type: {link_type}. Expected 'tcp' or 'serial'.")

        if transport_type == "TCP":
            # TCP transport is only valid when link_type == "tcp"
            if link_type != "tcp":
                raise ValueError("TCP transport requires link_type='tcp'")
            return TCPCommunication(config)

        if transport_type == HDLC:
            mode_com = config.communication.mode_com
            if mode_com == HDLC_DIRECT:
                return HDLCCommunication(config, lower_comm, is_complete=HDLCTransport.hdlc_complete)
            elif mode_com == HDLC_MODE_E:
                return HDLCModeECommunication(config, lower_comm, is_complete=HDLCTransport.hdlc_complete)
            else:
                raise ValueError(f"Unsupported HDLC communication mode: {mode_com}. Expected 'DirectHDLC' or 'Mode_E'.")
        else:
            raise ValueError(f"Unsupported transport type: {transport_type}. Expected 'HDLC' or 'TCP'.")


    def _initialize_communication_and_executor(self, config: ConfigModuleProxy,
                                               frame_builder: DLMSFrameBuilder) -> Tuple[
        AbstractCommunication, DLMSExecutor]:
        """
        Initialize the communication stack and frame executor according to configuration.
        Limitation: only 'serial' (physical) and 'HDLC' (transport) are currently supported.
        Args:
            config: Configuration proxy for the session
            frame_builder: Frame builder instance
        Returns:
            Tuple (communication, DLMSExecutor)
        Raises:
            RuntimeError or ValueError in case of failure or unsupported type
        """
        try:
            logger.trace("Initializing communication and executor",
                         **self._mod)
            communication = DLMSSessionManager._initialize_communication(config)
            if config.features_activation.general_block_transfer  or Conformance.from_bytes(config.session.initiate_request.proposed_conformance).general_block_transfer:

                frame_executor = GBTDLMSExecutor(communication, frame_builder, config)
            else:
                frame_executor = DLMSExecutor(communication, frame_builder, config)

            logger.trace("Communication and executor initialized successfully",
                         **self._mod)
            return communication, frame_executor
        except Exception as e:
            logger.error(f"Failed to initialize communication and executor: {e}",
                         **self._mod)
            raise

    # =========================================================================
    # PRIVATE SESSION HELPER METHODS
    # =========================================================================

    def _create_session(self, session_type: str, config: ConfigModuleProxy,
                        communication: AbstractCommunication, security_context: SecurityContext) -> AbstractSession:
        """
        Create appropriate session based on session type.
        
        Args:
            session_type: Type of session to create
            config: Configuration proxy
            communication: Communication instance
            security_context: Security context instance
            
        Returns:
            Session instance
            
        Raises:
            ValueError: If session type is unknown
        """
        logger.info(f"Creating session of type: {session_type}",
                    **self._mod)

        if session_type == SESSION_TYPE_HLS:
            return DLMSHlsSession(communication, security_context, config)
        elif session_type == SESSION_TYPE_LLS:
            return DLMSPasswordSession(config, communication)
        else:
            return DLMSSession(config, communication)

    def _open_session_safely(self, session: AbstractSession) -> bool:
        """
        Safely open a session with error handling.
        
        Args:
            session: Session instance to open
            
        Returns:
            True if session opened successfully, False otherwise
        """
        try:
            logger.info("Opening session",
                        **self._mod)

            session.open()

            logger.trace("Session opened successfully",
                         **self._mod)
            return True

        except Exception as e:
            logger.error(f"Session not opened: {e}",
                         **self._mod)
            return False

    def _retrieve_frame_counter(self, public_config: ConfigModuleProxy,
                                main_config: ConfigModuleProxy) -> None:
        """
        Retrieve the current frame counter from the device via a public session.
        Limitation: only 'serial' (physical) and 'HDLC' (transport) are currently supported.
        Args:
            public_config: Public client config (will receive the frame counter)
            main_config: Main client config (context)
        Raises:
            RuntimeError: in case of failure
        """
        logger.info("****************************************************************", **self._mod)
        logger.info("Establishing Public association to retrieve frame counter", **self._mod)
        logger.info("****************************************************************", **self._mod)
        public_session = None
        try:
            public_communication = DLMSSessionManager._initialize_communication(public_config)
            public_session = DLMSSession(public_config, public_communication)
            public_session.open()
            public_session.get_frame_counter(main_config)
        except Exception as e:
            logger.error(f"Failed to retrieve frame counter: {e}",
                         **self._mod)
            raise RuntimeError(f"Frame counter retrieval failed: {e}") from e
        finally:
            try:
                if public_session:
                    public_session.close()
                logger.info("****************************************************************", **self._mod)
                logger.info("Public association closed successfully", **self._mod)
                logger.info("****************************************************************", **self._mod)
            except Exception as cleanup_error:
                logger.warning(f"Error during public session cleanup: {cleanup_error}",
                               **self._mod)

    def _handle_frame_counter(self, main_session_config, public_config, session_type, security_policy):
        """
        Handle frame counter retrieval and setup for secure sessions.
        
        For HLS sessions or policies requiring frame counters, this function:
        1. Uses public session to retrieve current frame counter from device
        2. Transfers the retrieved value to main session configuration
        3. Main session can then use this frame counter for secure communications
        
        Args:
            main_session_config: Main session configuration (will receive frame counter)
            public_config: Public session configuration (used for retrieval)
            session_type: Type of session (HLS or other)
            security_policy: Security policy configuration
        """
        if session_type == SESSION_TYPE_HLS or needs_frame_counter(security_policy):
            # Retrieve current frame counter from device using public session
            self._retrieve_frame_counter(public_config, main_session_config)
            # Transfer the retrieved frame counter value from public config to main session config
            main_session_config.security.frame_counter = public_config.security.frame_counter

    def get_session_info(self) -> dict:
        """
        Get information about the current session.
        
        Returns:
            Dictionary with session information
        """
        return {
            "is_connected": self.is_connected,
            "has_session": self.session is not None,
            "has_communication": self.communication is not None,
            "has_frame_executor": self.frame_executor is not None,
            "has_frame_builder": self.frame_builder is not None,
            "has_security_context": self.security_context is not None
        }
