"""
Frame details collector for DLMS operations.
Captures request and response frames in both encrypted and plain form.
"""
from typing import Dict, Any, Optional, List

from ng_sdk.frame_builder.abstract_frame_request import AbstractFrameRequest
from ng_sdk.frame_builder.abstract_frame_response import AbstractFrameResponse
from ng_sdk.security.security_context import SecurityContext


def extract_dlms_from_hdlc(hdlc_frame: bytes) -> Optional[bytes]:
    """
    Extract DLMS payload from HDLC frame.
    
    Args:
        hdlc_frame: Complete HDLC frame (7E...7E)
        
    Returns:
        DLMS payload (xDLMS APDU) or None if extraction fails
    """
    try:
        # HDLC frame format: 7E | Format&Length | Address | Control | HCS | LLC | xDLMS | FCS | 7E
        # Example: 7E A0 2D 02 21 05 DC 60 69 E6 E6 00 C81E30... 574C 7E
        #          ^  ^^^^^  ^^^^^^^^  ^^  ^^^^  ^^^^^^^^^^  ^^^^  ^
        #          |    |       |       |    |       |         |    |
        #        Flag Format  Addr   Ctrl  HCS    LLC      xDLMS  FCS+Flag

        if len(hdlc_frame) < 10 or hdlc_frame[0] != 0x7E:
            return None

        # Parse format and length (2 or 3 bytes depending on frame size)
        format_byte = hdlc_frame[1]
        if format_byte & 0x08:  # 3-byte format (long frame)
            frame_len = ((format_byte & 0x07) << 8) | hdlc_frame[2]
            offset = 3
        else:  # 2-byte format
            frame_len = format_byte & 0x07
            offset = 2

        # Parse destination address (LSB indicates last byte)
        while offset < len(hdlc_frame) and (hdlc_frame[offset] & 0x01) == 0:
            offset += 1
        offset += 1  # Include the last address byte (LSB=1)

        # Parse source address (LSB indicates last byte)
        while offset < len(hdlc_frame) and (hdlc_frame[offset] & 0x01) == 0:
            offset += 1
        offset += 1  # Include the last address byte (LSB=1)

        # Skip control byte (1 byte)
        offset += 1

        # Skip HCS (Header Check Sequence - 2 bytes)
        offset += 2

        # Skip LLC header if present
        # LLC is only present in I-frames and UI-frames, not in RR/RNR frames
        # The LLC header in DLMS typically ends with 00 (Control field)
        # Common patterns seen:
        # - E6 E6 00: Standard LLC for requests (3 bytes)
        # - E6 E7 00: Standard LLC for responses (3 bytes)
        # - 69 E6 E6 00: LLC with segmentation (4 bytes)
        # - 5F 9A E6 E7 00: LLC with additional info (5 bytes)
        # - 60 69 E6 E6 00: Another variant (5 bytes)
        #
        # Strategy: Look for patterns ending with 00, then check if next byte looks like xDLMS tag
        # xDLMS tags: C0-D3 range (AARQ, AARE, GET, SET, ACTION responses)

        if offset < len(hdlc_frame) - 3:
            # Scan ahead looking for 00 byte followed by xDLMS tag (C0-D3)
            found_llc = False
            for i in range(min(8, len(hdlc_frame) - offset - 2)):  # Check up to 8 bytes ahead
                if (hdlc_frame[offset + i] == 0x00 and
                        offset + i + 1 < len(hdlc_frame) and
                        0xC0 <= hdlc_frame[offset + i + 1] <= 0xD3):
                    # Found LLC ending (00) followed by xDLMS tag
                    offset += i + 1  # Skip to the xDLMS tag
                    found_llc = True
                    break

            # If no LLC pattern found, assume we're already at xDLMS

        # The rest until FCS (last 3 bytes: 2-byte FCS + 7E) is the xDLMS APDU
        dlms_payload = hdlc_frame[offset:-3]

        return dlms_payload
    except Exception:
        return None


class FrameDetailsCollector:
    """Collects detailed frame information during DLMS operations."""

    # Maps response class name prefix → (APDU tag, {choice suffix → choice byte}).
    # Defined once at class level to avoid re-creating the dict on every call.
    _RESPONSE_TAG_MAP: Dict[str, Any] = {
        'GetResponse': (0xC4, {'Normal': 0x01, 'WithList': 0x03}),
        'SetResponse': (0xC5, {'Normal': 0x01, 'WithList': 0x03}),
        'ActionResponse': (0xC7, {'Normal': 0x01, 'WithList': 0x03}),
    }

    @staticmethod
    def _extract_dlms_apdu(frame: bytes) -> str:
        """
        Extract and return the DLMS APDU from a transport frame as an uppercase hex string.

        If the frame is an HDLC frame (starts with 0x7E), the DLMS payload is extracted
        from it. Otherwise the frame is returned as-is (e.g. TCP/IP wrapper).

        Args:
            frame: Raw frame bytes (HDLC or bare DLMS APDU)

        Returns:
            Uppercase hex string of the DLMS APDU, or an error string if the
            frame type is invalid or the frame is empty.
        """
        if not isinstance(frame, (bytes, bytearray)):
            return f"Invalid frame type: expected bytes, got {type(frame).__name__}"
        if len(frame) == 0:
            return "Invalid frame: empty bytes"

        if frame[0:1] == b'\x7E':
            dlms_payload = extract_dlms_from_hdlc(frame)
            if dlms_payload:
                return dlms_payload.hex().upper()
        return frame.hex().upper()

    @staticmethod
    def _build_request_details(request: AbstractFrameRequest,
                               security_context: Optional[SecurityContext],
                               transmitted_frames: Optional[List[bytes]]) -> Dict[str, Any]:
        """
        Build the request section of frame details.

        Args:
            request: The DLMS request object
            security_context: Security context used for encryption
            transmitted_frames: List of transmitted frame bytes

        Returns:
            Dictionary with plain_frame, encrypted_frame and request metadata
        """
        details: Dict[str, Any] = {
            "type": type(request).__name__,
            "plain_frame": None,
            "encrypted_frame": None,
            "request_object": request,
        }

        if not hasattr(request, 'to_bytes'):
            return details

        # Plain frame (no encryption)
        try:
            details["plain_frame"] = request.to_bytes(None).hex().upper()
        except Exception as e:
            details["plain_frame"] = f"Error getting plain frame: {e}"

        # Encrypted frame — prefer actual transmitted bytes to avoid counter increment
        first_tx = transmitted_frames[0] if transmitted_frames else None
        if isinstance(first_tx, (bytes, bytearray)) and len(first_tx) > 0:
            # Valid frame available: extract DLMS APDU directly
            details["encrypted_frame"] = FrameDetailsCollector._extract_dlms_apdu(first_tx)
        elif security_context:
            # Fallback: re-encrypt (WARNING: frame counter will be different)
            try:
                details["encrypted_frame"] = request.to_bytes(security_context).hex().upper()
            except Exception as e:
                details["encrypted_frame"] = f"Error getting encrypted frame: {e}"
        else:
            details["encrypted_frame"] = "No security context"

        # Additional DLMS metadata
        for attr, key in [('class_id', 'class_id'), ('obis_code', 'obis_code'),
                          ('attribute', 'attribute_id'), ('method', 'method_id')]:
            if hasattr(request, attr):
                details[key] = getattr(request, attr)

        return details

    @staticmethod
    def _build_response_plain_frame(response: AbstractFrameResponse) -> Optional[bytes]:
        """
        Reconstruct the plain response APDU bytes from a response object.

        Tries ``response.to_bytes()`` first, then falls back to manual
        construction from the response type, tag, invoked_id and frame data.

        Args:
            response: The DLMS response object

        Returns:
            Plain APDU bytes, or None if reconstruction failed
        """
        # 1 — try the native serialiser
        if hasattr(response, 'to_bytes'):
            try:
                return response.to_bytes()
            except Exception:
                pass

        # 2 — manual reconstruction
        try:
            response_type = type(response).__name__
            parts = bytearray()

            for prefix, (tag, choices) in FrameDetailsCollector._RESPONSE_TAG_MAP.items():
                if prefix in response_type:
                    parts.append(tag)
                    for suffix, choice in choices.items():
                        if suffix in response_type:
                            parts.append(choice)
                            break
                    break

            if not parts:
                return None

            # Append frame body
            if hasattr(response, 'frame') and response.frame:
                frame_data = response.frame
                # Prepend invoked_id only if not already present
                if (hasattr(response, 'invoked_id') and
                        len(frame_data) > 0 and
                        frame_data[0] != (response.invoked_id & 0xFF)):
                    parts.append(response.invoked_id & 0xFF)
                parts.extend(frame_data)
            else:
                # No frame data: build minimal status bytes
                if hasattr(response, 'invoked_id'):
                    parts.append(response.invoked_id & 0xFF)
                if 'ActionResponse' in response_type:
                    parts.append(response.result.value if hasattr(response, 'result') else 0x00)
                    parts.append(0x00)  # No return parameters
                elif 'SetResponse' in response_type:
                    parts.append(
                        response.data_access_result.value
                        if hasattr(response, 'data_access_result') else 0x00
                    )

            return bytes(parts)

        except Exception:
            # Last resort: raw frame bytes
            if hasattr(response, 'frame') and response.frame:
                return response.frame
            return None

    @staticmethod
    def _build_response_details(response: AbstractFrameResponse,
                                received_frames: Optional[List[bytes]]) -> Dict[str, Any]:
        """
        Build the response section of frame details.

        Args:
            response: The DLMS response object
            received_frames: List of received frame bytes

        Returns:
            Dictionary with plain_frame, encrypted_frame and response metadata
        """
        details: Dict[str, Any] = {
            "type": type(response).__name__,
            "plain_frame": None,
            "encrypted_frame": None,
        }

        # Plain frame
        plain_bytes = FrameDetailsCollector._build_response_plain_frame(response)
        details["plain_frame"] = plain_bytes.hex().upper() if plain_bytes else "No response frame available"

        # Encrypted frame from wire
        first_rx = received_frames[0] if received_frames else None
        if isinstance(first_rx, (bytes, bytearray)) and len(first_rx) > 0:
            details["encrypted_frame"] = FrameDetailsCollector._extract_dlms_apdu(first_rx)
        else:
            details["encrypted_frame"] = "No received frames available"

        # Additional DLMS metadata
        if hasattr(response, 'data_access_result'):
            details["data_access_result"] = response.data_access_result.name
        if hasattr(response, 'result') and not isinstance(response.result, list):
            details["result"] = response.result.name

        return details

    @staticmethod
    def _build_security_details(security_context: Optional[SecurityContext]) -> Dict[str, Any]:
        """
        Build the security section of frame details.

        Args:
            security_context: Active security context, or None

        Returns:
            Dictionary with encryption status, policy and frame counter
        """
        if not security_context:
            return {"encryption_enabled": False}

        details: Dict[str, Any] = {"encryption_enabled": True}

        if hasattr(security_context, 'security_policy'):
            policy = security_context.security_policy
            details["security_policy"] = policy.name if hasattr(policy, 'name') else str(policy)

        if hasattr(security_context, 'frame_counter'):
            details["frame_counter"] = security_context.frame_counter

        return details

    @staticmethod
    def collect_frame_details(request: AbstractFrameRequest,
                              response: AbstractFrameResponse,
                              security_context: Optional[SecurityContext] = None,
                              transmitted_frames: Optional[List[bytes]] = None,
                              received_frames: Optional[List[bytes]] = None) -> Dict[str, Any]:
        """
        Collect comprehensive frame details for a DLMS operation.

        Args:
            request: The DLMS request object
            response: The DLMS response object
            security_context: Security context used for encryption/decryption
            transmitted_frames: List of transmitted frame bytes
            received_frames: List of received frame bytes

        Returns:
            Dictionary containing detailed frame information
        """
        frame_details: Dict[str, Any] = {}

        try:
            frame_details["request"] = FrameDetailsCollector._build_request_details(
                request, security_context, transmitted_frames
            )

            response_details = FrameDetailsCollector._build_response_details(
                response, received_frames
            )
            response_details["response_object"] = response
            frame_details["response"] = response_details

            # Full wire-level frame lists (skip invalid entries)
            if transmitted_frames:
                frame_details["transmitted_frames"] = [
                    f.hex().upper()
                    for f in transmitted_frames
                    if isinstance(f, (bytes, bytearray)) and len(f) > 0
                ]
            if received_frames:
                frame_details["received_frames"] = [
                    f.hex().upper()
                    for f in received_frames
                    if isinstance(f, (bytes, bytearray)) and len(f) > 0
                ]

            frame_details["security"] = FrameDetailsCollector._build_security_details(security_context)

        except Exception as e:
            frame_details["collection_error"] = f"Error collecting frame details: {e}"

        return frame_details

    @staticmethod
    def extract_request_info(request: AbstractFrameRequest) -> Dict[str, Any]:
        """
        Extract basic information from a request object.
        
        Args:
            request: The DLMS request object
            
        Returns:
            Dictionary with request information
        """
        info = {
            "type": type(request).__name__
        }

        # Common request properties
        if hasattr(request, 'class_id'):
            info["class_id"] = request.class_id
        if hasattr(request, 'obis_code'):
            info["obis_code"] = request.obis_code
        if hasattr(request, 'attribute'):
            info["attribute_id"] = request.attribute
        if hasattr(request, 'method'):
            info["method_id"] = request.method
        if hasattr(request, 'payload') and request.payload:
            info["payload_size"] = len(request.payload)
            info["payload_hex"] = request.payload.hex().upper()

        return info

    @staticmethod
    def extract_response_info(response: AbstractFrameResponse) -> Dict[str, Any]:
        """
        Extract basic information from a response object.
        
        Args:
            response: The DLMS response object
            
        Returns:
            Dictionary with response information
        """
        info = {
            "type": type(response).__name__
        }

        # Common response properties
        if hasattr(response, 'invoked_id'):
            info["invoked_id"] = hex(response.invoked_id)
        if hasattr(response, 'is_success'):
            info["success"] = response.is_success()
        if hasattr(response, 'data_access_result'):
            info["data_access_result"] = {
                "name": response.data_access_result.name,
                "value": response.data_access_result.value
            }
        if hasattr(response, 'result'):
            if isinstance(response.result, list):
                # WithList response: store each individual result
                info["action_result"] = [
                    {"name": r.name, "value": r.value}
                    for r in response.result
                    if hasattr(r, 'name') and hasattr(r, 'value')
                ]
            else:
                info["action_result"] = {
                    "name": response.result.name,
                    "value": response.result.value
                }
        if hasattr(response, 'data') and response.data:
            info["data_type"] = type(response.data).__name__
            if hasattr(response.data, 'value'):
                if isinstance(response.data.value, (bytes, bytearray)):
                    info["data_hex"] = bytes(response.data.value).hex().upper()
                    info["data_size"] = len(response.data.value)
                else:
                    info["data_value"] = str(response.data.value)

        return info
