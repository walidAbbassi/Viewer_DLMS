"""
Frame Journey Tracker - Captures complete lifecycle of DLMS frames.

This module provides a comprehensive tracking mechanism for DLMS frame processing,
capturing each transformation stage from plain DLMS APDU through encryption,
transport wrapping, transmission, reception, and decoding.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List, Dict, Any


@dataclass
class FrameStage:
    """Represents a single transformation stage in the frame journey."""
    stage_name: str
    timestamp: datetime
    data: bytes
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format."""
        return {
            "stage": self.stage_name,
            "timestamp": self.timestamp.isoformat(),
            "data_hex": self.data.hex().upper(),
            "data_size": len(self.data),
            "metadata": self.metadata
        }


@dataclass
class FrameJourney:
    """
    Tracks complete journey of a DLMS frame through the SDK pipeline.
    
    Journey stages:
    1. PLAIN_DLMS: Original DLMS APDU before encryption
    2. ENCRYPTED_DLMS: DLMS APDU after encryption (with security headers)
    3. TRANSPORT_WRAPPED: Frame wrapped in transport protocol (HDLC/TCP/etc.)
    4. TRANSMITTED: Actual bytes sent on wire
    5. RECEIVED: Actual bytes received from wire
    6. TRANSPORT_UNWRAPPED: Frame after removing transport wrapper
    7. DECRYPTED_DLMS: DLMS APDU after decryption
    8. PARSED_DATA: Final parsed data structure
    """

    # Request journey
    request_stages: List[FrameStage] = field(default_factory=list)

    # Response journey
    response_stages: List[FrameStage] = field(default_factory=list)

    # Operation metadata
    operation_type: Optional[str] = None
    class_id: Optional[int] = None
    obis_code: Optional[str] = None
    attribute_id: Optional[int] = None
    method_id: Optional[int] = None

    # Security metadata
    security_enabled: bool = False
    security_policy: Optional[str] = None
    frame_counter: Optional[int] = None

    # Transport metadata
    transport_protocol: Optional[str] = None  # HDLC, TCP, UDP, etc.

    # Timing
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None

    def add_request_stage(self, stage_name: str, data: bytes, **metadata):
        """Add a stage to the request journey."""
        stage = FrameStage(
            stage_name=stage_name,
            timestamp=datetime.now(),
            data=data,
            metadata=metadata
        )
        self.request_stages.append(stage)

    def add_response_stage(self, stage_name: str, data: bytes, **metadata):
        """Add a stage to the response journey."""
        stage = FrameStage(
            stage_name=stage_name,
            timestamp=datetime.now(),
            data=data,
            metadata=metadata
        )
        self.response_stages.append(stage)

    def get_request_stage(self, stage_name: str) -> Optional[FrameStage]:
        """Get a specific request stage by name."""
        for stage in self.request_stages:
            if stage.stage_name == stage_name:
                return stage
        return None

    def get_response_stage(self, stage_name: str) -> Optional[FrameStage]:
        """Get a specific response stage by name."""
        for stage in self.response_stages:
            if stage.stage_name == stage_name:
                return stage
        return None

    def get_plain_request(self) -> Optional[bytes]:
        """Get plain DLMS request APDU."""
        stage = self.get_request_stage("PLAIN_DLMS")
        return stage.data if stage else None

    def get_encrypted_request(self) -> Optional[bytes]:
        """Get encrypted DLMS request APDU."""
        stage = self.get_request_stage("ENCRYPTED_DLMS")
        return stage.data if stage else None

    def get_transmitted_frame(self) -> Optional[bytes]:
        """Get transmitted frame (with transport wrapper)."""
        stage = self.get_request_stage("TRANSMITTED")
        return stage.data if stage else None

    def get_received_frame(self) -> Optional[bytes]:
        """Get received frame (with transport wrapper)."""
        stage = self.get_response_stage("RECEIVED")
        return stage.data if stage else None

    def get_plain_response(self) -> Optional[bytes]:
        """Get plain DLMS response APDU."""
        stage = self.get_response_stage("DECRYPTED_DLMS")
        return stage.data if stage else None

    def get_parsed_data(self) -> Optional[Any]:
        """Get parsed response data."""
        stage = self.get_response_stage("PARSED_DATA")
        return stage.metadata.get("parsed_data") if stage else None

    def to_dict(self) -> Dict[str, Any]:
        """Convert complete journey to dictionary."""
        return {
            "operation": {
                "type": self.operation_type,
                "class_id": self.class_id,
                "obis_code": self.obis_code,
                "attribute_id": self.attribute_id,
                "method_id": self.method_id
            },
            "security": {
                "enabled": self.security_enabled,
                "policy": self.security_policy,
                "frame_counter": self.frame_counter
            },
            "transport": {
                "protocol": self.transport_protocol
            },
            "timing": {
                "start": self.start_time.isoformat() if self.start_time else None,
                "end": self.end_time.isoformat() if self.end_time else None,
                "duration_ms": (self.end_time - self.start_time).total_seconds() * 1000
                if self.start_time and self.end_time else None
            },
            "request_journey": [stage.to_dict() for stage in self.request_stages],
            "response_journey": [stage.to_dict() for stage in self.response_stages]
        }

    def format_summary(self) -> str:
        """Format a human-readable summary of the journey."""
        lines = []
        lines.append("=" * 80)
        lines.append(f"DLMS OPERATION: {self.operation_type}")

        if self.obis_code:
            lines.append(f"  OBIS Code: {self.obis_code}")
        if self.class_id:
            lines.append(f"  Class ID: {self.class_id}")
        if self.attribute_id:
            lines.append(f"  Attribute: {self.attribute_id}")
        if self.method_id:
            lines.append(f"  Method: {self.method_id}")

        lines.append("")
        lines.append(f"Transport Protocol: {self.transport_protocol or 'Unknown'}")
        lines.append(f"Security: {'Enabled' if self.security_enabled else 'Disabled'}")
        if self.security_enabled:
            lines.append(f"  Policy: {self.security_policy}")
            lines.append(f"  Frame Counter: {self.frame_counter}")

        lines.append("")
        lines.append("REQUEST JOURNEY:")
        lines.append("-" * 80)
        for i, stage in enumerate(self.request_stages, 1):
            lines.append(f"{i}. {stage.stage_name}")
            lines.append(
                f"   Data ({len(stage.data)} bytes): {stage.data.hex().upper()[:100]}{'...' if len(stage.data) > 50 else ''}")
            if stage.metadata:
                for key, value in stage.metadata.items():
                    lines.append(f"   {key}: {value}")

        lines.append("")
        lines.append("RESPONSE JOURNEY:")
        lines.append("-" * 80)
        for i, stage in enumerate(self.response_stages, 1):
            lines.append(f"{i}. {stage.stage_name}")
            lines.append(
                f"   Data ({len(stage.data)} bytes): {stage.data.hex().upper()[:100]}{'...' if len(stage.data) > 50 else ''}")
            if stage.metadata:
                for key, value in stage.metadata.items():
                    lines.append(f"   {key}: {value}")

        lines.append("=" * 80)
        return "\n".join(lines)

    def __str__(self) -> str:
        """String representation."""
        return self.format_summary()
