"""
Data Type Factory for DLMS/COSEM data types.

This module provides factory methods for creating DLMS data type objects
and converting them to their byte representations. Useful for Robot Framework
and other testing frameworks that need to create DLMS data structures.
"""


class DataTypeFactory:
    """Factory class for creating DLMS data type objects."""

    @staticmethod
    def create_integer8(value: int) -> bytes:
        """
        Create an Integer8 data type and return its byte representation.
        
        Args:
            value: Integer value to encode (-128 to 127)
            
        Returns:
            Byte representation of the Integer8 value
            
        Raises:
            ValueError: If value is out of range
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.integer_8 import Integer8
        return Integer8(value=value).to_bytes()

    @staticmethod
    def create_unsigned32(value: int) -> bytes:
        """
        Create an Unsigned32 data type and return its byte representation.
        
        Args:
            value: Unsigned integer value to encode (0 to 4294967295)
            
        Returns:
            Byte representation of the Unsigned32 value
            
        Raises:
            ValueError: If value is out of range
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_32 import Unsigned32
        return Unsigned32(value=value).to_bytes()

    @staticmethod
    def create_octet_string(value: str) -> bytes:
        """
        Create an OctetString data type and return its byte representation.
        
        Args:
            value: Hex string to encode (without spaces or 0x prefix)
            
        Returns:
            Byte representation of the OctetString value
            
        Raises:
            ValueError: If hex string is invalid
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.octet_string import OctetStringData
        return OctetStringData(value=value).to_bytes()

    @staticmethod
    def create_visible_string(value: str) -> bytes:
        """
        Create a VisibleString data type and return its byte representation.
        
        Args:
            value: String value to encode (ASCII printable characters)
            
        Returns:
            Byte representation of the VisibleString value
            
        Raises:
            ValueError: If string contains non-printable characters
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.visible_string import VisibleString
        return VisibleString(value=value).to_bytes()

    @staticmethod
    def create_boolean(value: bool) -> bytes:
        """
        Create a Boolean data type and return its byte representation.
        
        Args:
            value: Boolean value to encode
            
        Returns:
            Byte representation of the Boolean value
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.boolean import BooleanData
        return BooleanData(value=value).to_bytes()

    @staticmethod
    def create_integer16(value: int) -> bytes:
        """
        Create an Integer16 data type and return its byte representation.
        
        Args:
            value: Integer value to encode (-32768 to 32767)
            
        Returns:
            Byte representation of the Integer16 value
            
        Raises:
            ValueError: If value is out of range
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.integer_16 import Integer16
        return Integer16(value=value).to_bytes()

    @staticmethod
    def create_integer32(value: int) -> bytes:
        """
        Create an Integer32 data type and return its byte representation.
        
        Args:
            value: Integer value to encode (-2147483648 to 2147483647)
            
        Returns:
            Byte representation of the Integer32 value
            
        Raises:
            ValueError: If value is out of range
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.integer_32 import Integer32
        return Integer32(value=value).to_bytes()

    @staticmethod
    def create_unsigned8(value: int) -> bytes:
        """
        Create an Unsigned8 data type and return its byte representation.
        
        Args:
            value: Unsigned integer value to encode (0 to 255)
            
        Returns:
            Byte representation of the Unsigned8 value
            
        Raises:
            ValueError: If value is out of range
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_8 import Unsigned8
        return Unsigned8(value=value).to_bytes()

    @staticmethod
    def create_unsigned16(value: int) -> bytes:
        """
        Create an Unsigned16 data type and return its byte representation.
        
        Args:
            value: Unsigned integer value to encode (0 to 65535)
            
        Returns:
            Byte representation of the Unsigned16 value
            
        Raises:
            ValueError: If value is out of range
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_16 import Unsigned16
        return Unsigned16(value=value).to_bytes()

    @staticmethod
    def create_unsigned64(value: int) -> bytes:
        """
        Create an Unsigned64 data type and return its byte representation.
        
        Args:
            value: Unsigned integer value to encode (0 to 18446744073709551615)
            
        Returns:
            Byte representation of the Unsigned64 value
            
        Raises:
            ValueError: If value is out of range
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_64 import Unsigned64
        return Unsigned64(value=value).to_bytes()

    @staticmethod
    def create_integer64(value: int) -> bytes:
        """
        Create an Integer64 data type and return its byte representation.
        
        Args:
            value: Integer value to encode (-9223372036854775808 to 9223372036854775807)
            
        Returns:
            Byte representation of the Integer64 value
            
        Raises:
            ValueError: If value is out of range
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.integer_64 import Integer64
        return Integer64(value=value).to_bytes()

    @staticmethod
    def create_enum(value: int) -> bytes:
        """
        Create an Enum data type and return its byte representation.
        
        Args:
            value: Enum value to encode (0 to 255)
            
        Returns:
            Byte representation of the Enum value
            
        Raises:
            ValueError: If value is out of range
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.enum import EnumData
        return EnumData(value=value).to_bytes()

    @staticmethod
    def create_float32(value: float) -> bytes:
        """
        Create a Float32 data type and return its byte representation.
        
        Args:
            value: Float value to encode (IEEE 754 single precision)
            
        Returns:
            Byte representation of the Float32 value
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.float_32 import Float32
        return Float32(value=value).to_bytes()

    @staticmethod
    def create_float64(value: float) -> bytes:
        """
        Create a Float64 data type and return its byte representation.
        
        Args:
            value: Float value to encode (IEEE 754 double precision)
            
        Returns:
            Byte representation of the Float64 value
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.float_64 import Float64
        return Float64(value=value).to_bytes()

    @staticmethod
    def create_utf8_string(value: str) -> bytes:
        """
        Create a UTF8String data type and return its byte representation.
        
        Args:
            value: UTF-8 string value to encode
            
        Returns:
            Byte representation of the UTF8String value
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.utf8_string import Utf8String
        return Utf8String(value=value).to_bytes()

    @staticmethod
    def create_bcd(value: int) -> bytes:
        """
        Create a BCD (Binary Coded Decimal) data type and return its byte representation.
        
        Args:
            value: Integer value to encode as BCD
            
        Returns:
            Byte representation of the BCD value
            
        Raises:
            ValueError: If value contains invalid BCD digits
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.bcd import BCD
        return BCD(value=value).to_bytes()

    @staticmethod
    def create_bit_string(value: str) -> bytes:
        """
        Create a BitString data type and return its byte representation.
        
        Args:
            value: Binary string (e.g., "10110011") to encode
            
        Returns:
            Byte representation of the BitString value
            
        Raises:
            ValueError: If string contains non-binary characters
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.bit_string import BitString
        return BitString(value=value).to_bytes()

    @staticmethod
    def create_null_data() -> bytes:
        """
        Create a NullData data type and return its byte representation.
        
        Returns:
            Byte representation of the NullData value (single byte: 0x00)
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.null_data import NullData
        return NullData().to_bytes()

    @staticmethod
    def create_structure(elements: list) -> bytes:
        """
        Create a Structure data type and return its byte representation.
        
        A Structure is a collection of DLMS data type objects arranged in order.
        
        Args:
            elements: List of DLMS data type objects (not bytes)
            
        Returns:
            Byte representation of the Structure
            
        Example:
            >>> from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_8 import Unsigned8
            >>> from ng_sdk.frame_builder.dlms.xdlms.data_type.visible_string import VisibleString
            >>> elements = [Unsigned8(value=10), VisibleString(value="test")]
            >>> structure_bytes = DataTypeFactory.create_structure(elements)
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.structure import StructureData
        return StructureData(value=elements).to_bytes()

    @staticmethod
    def create_array(elements: list) -> bytes:
        """
        Create an Array data type and return its byte representation.
        
        An Array is a collection of DLMS data type objects (typically of the same type).
        
        Args:
            elements: List of DLMS data type objects (not bytes)
            
        Returns:
            Byte representation of the Array
            
        Example:
            >>> from ng_sdk.frame_builder.dlms.xdlms.data_type.unsigned_16 import Unsigned16
            >>> elements = [Unsigned16(value=100), Unsigned16(value=200), Unsigned16(value=300)]
            >>> array_bytes = DataTypeFactory.create_array(elements)
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.array import ArrayData
        return ArrayData(value=elements).to_bytes()

    @staticmethod
    def create_date_time(dt) -> bytes:
        """
        Create a DateTime data type and return its byte representation.
        
        Args:
            dt: Python datetime object or DLMS datetime representation
            
        Returns:
            Byte representation of the DateTime value (12 bytes)
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.date_time import DateTime
        return DateTime(value=dt).to_bytes()

    @staticmethod
    def create_date(date) -> bytes:
        """
        Create a Date data type and return its byte representation.
        
        Args:
            date: Python date object or DLMS date representation
            
        Returns:
            Byte representation of the Date value (5 bytes)
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.date import Date
        return Date(value=date).to_bytes()

    @staticmethod
    def create_time(time) -> bytes:
        """
        Create a Time data type and return its byte representation.
        
        Args:
            time: Python time object or DLMS time representation
            
        Returns:
            Byte representation of the Time value (4 bytes)
        """
        from ng_sdk.frame_builder.dlms.xdlms.data_type.time import Time
        return Time(value=time).to_bytes()
