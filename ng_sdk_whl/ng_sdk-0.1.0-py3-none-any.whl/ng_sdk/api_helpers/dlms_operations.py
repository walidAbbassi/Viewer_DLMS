"""
DLMS operation helper class for the DLMS API with enhanced frame details collection.
"""

from datetime import datetime
from typing import Any, Optional, Dict, List

from ng_sdk.api_helpers.frame_details_collector import FrameDetailsCollector
from ng_sdk.api_helpers.frame_journey import FrameJourney
from ng_sdk.api_helpers.response_processor import DLMSResponseProcessor
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_normal import DLMSActionRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.action.request.dlms_action_request_with_list import DLMSActionRequestWithList
from ng_sdk.frame_builder.dlms.xdlms.get.request.dlms_get_request_normal import DLMSGetRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.get.request.dlms_get_request_with_list import DLMSGetRequestWithList
from ng_sdk.frame_builder.dlms.xdlms.selective_access.abstract_selective_access import AbstractSelectiveAccess
from ng_sdk.frame_builder.dlms.xdlms.set.request.dlms_set_request_normal import DLMSSetRequestNormal
from ng_sdk.frame_builder.dlms.xdlms.set.request.dlms_set_request_with_list import DLMSSetRequestWithList
from ng_sdk.frame_executor.dlms.dlms_executor import DLMSExecutor
from ng_sdk.logger.logger import LoggingConstants, get_logger

logger = get_logger()


class EnhancedDLMSExecutor:
    """
    Wrapper for DLMSExecutor that captures complete frame journey.
    
    This executor wraps the entire DLMS pipeline to track each transformation:
    - Plain DLMS APDU creation
    - Encryption (if security enabled)
    - Transport wrapping (HDLC/TCP/etc.)
    - Transmission
    - Reception
    - Transport unwrapping
    - Decryption
    - Data parsing
    """

    def __init__(self, executor: DLMSExecutor):
        self._executor = executor
        self.last_transmitted_frames: List[bytes] = []
        self.last_received_frames: List[bytes] = []
        self.last_journey: Optional[FrameJourney] = None
        self._mod = {LoggingConstants.MODULES_NAME: "EnhancedDLMSExecutor"}  # module tag for logs

    def execute(self, request) -> Any:
        """Execute request and capture complete frame journey."""
        # Create new journey tracker
        journey = FrameJourney()
        journey.start_time = datetime.now()
        journey.operation_type = type(request).__name__

        # Extract operation metadata
        if hasattr(request, 'class_id'):
            journey.class_id = request.class_id
        if hasattr(request, 'obis_code'):
            journey.obis_code = request.obis_code
        if hasattr(request, 'attribute'):
            journey.attribute_id = request.attribute
        if hasattr(request, 'method'):
            journey.method_id = request.method

        # Get security context
        security_context = getattr(self._executor, 'builder', None)
        security_context = getattr(security_context, 'security_context', None) if security_context else None

        if security_context:
            journey.security_enabled = True
            if hasattr(security_context, 'security_policy'):
                journey.security_policy = security_context.security_policy.name if hasattr(
                    security_context.security_policy, 'name') else str(security_context.security_policy)
            if hasattr(security_context, 'frame_counter'):
                journey.frame_counter = security_context.frame_counter

        # Detect transport protocol
        if hasattr(self._executor.communication, 'lower'):
            journey.transport_protocol = "HDLC"
        elif hasattr(self._executor.communication, '__class__'):
            journey.transport_protocol = self._executor.communication.__class__.__name__

        # Stage 1: Capture plain DLMS APDU
        if hasattr(request, 'to_bytes'):
            try:
                plain_dlms = request.to_bytes(None)
                journey.add_request_stage("PLAIN_DLMS", plain_dlms)
            except Exception as e:
                logger.warning(f"Failed to capture plain DLMS: {e}", **self._mod)

        # Clear previous frame history
        self.last_transmitted_frames.clear()
        self.last_received_frames.clear()

        # Stage 3 & 4: Capture transport wrapping and transmission
        original_send = None
        original_receive = None
        original_transceive = None

        # Check if we have a lower layer (for HDLC communication)
        if hasattr(self._executor.communication, 'lower'):
            original_send = self._executor.communication.lower.send
            original_receive = self._executor.communication.lower.receive

            def capturing_send(frame_data: bytes):
                # Stage 3: Transport wrapped frame (before transmission)
                journey.add_request_stage("TRANSPORT_WRAPPED", frame_data,
                                          protocol=journey.transport_protocol)
                # Stage 4: Actually transmitted frame
                journey.add_request_stage("TRANSMITTED", frame_data)
                self.last_transmitted_frames.append(frame_data)
                return original_send(frame_data)

            def capturing_receive() -> bytes:
                frame_response = original_receive()
                # Stage 5: Received frame (with transport wrapper)
                journey.add_response_stage("RECEIVED", frame_response,
                                           protocol=journey.transport_protocol)
                self.last_received_frames.append(frame_response)
                return frame_response

            # Replace lower layer methods
            self._executor.communication.lower.send = capturing_send
            self._executor.communication.lower.receive = capturing_receive
        else:
            # Fallback: capture at communication.transceive level (non-HDLC)
            original_transceive = self._executor.communication.transceive

            def capturing_transceive(frame_data: bytes) -> bytes:
                # Stage 3: Transport wrapped (if any)
                journey.add_request_stage("TRANSPORT_WRAPPED", frame_data,
                                          protocol=journey.transport_protocol)
                # Stage 4: Transmitted
                journey.add_request_stage("TRANSMITTED", frame_data)
                self.last_transmitted_frames.append(frame_data)

                frame_response = original_transceive(frame_data)

                # Stage 5: Received
                journey.add_response_stage("RECEIVED", frame_response,
                                           protocol=journey.transport_protocol)
                self.last_received_frames.append(frame_response)
                return frame_response

            self._executor.communication.transceive = capturing_transceive

        try:
            # Execute the request (handles stages 6 & 7: unwrapping and decryption internally)
            response = self._executor.execute(request)

            # Stage 6 & 7: Transport unwrapped and decrypted (captured from response)
            if hasattr(response, 'frame'):
                # This is the decrypted DLMS response
                journey.add_response_stage("DECRYPTED_DLMS", response.frame)

            # Stage 8: Parsed data
            if hasattr(response, 'data'):
                parsed_data = response.data
                # Store the actual data object in metadata
                data_repr = str(parsed_data)
                if hasattr(parsed_data, 'value'):
                    data_repr = str(parsed_data.value)
                    if isinstance(parsed_data.value, (bytes, bytearray)):
                        data_repr = bytes(parsed_data.value).hex().upper()

                # Note: PARSED_DATA stage has empty bytes (b'') since it's not a frame
                # The actual parsed data object is stored in metadata
                journey.add_response_stage("PARSED_DATA",
                                           b'',  # No raw bytes for parsed data
                                           parsed_data=parsed_data,  # Store in metadata, not 'data' param
                                           data_type=type(parsed_data).__name__,
                                           data_repr=data_repr)

            journey.end_time = datetime.now()
            self.last_journey = journey

            return response
        finally:
            # Restore original methods
            if hasattr(self._executor.communication, 'lower') and original_send:
                self._executor.communication.lower.send = original_send
                self._executor.communication.lower.receive = original_receive
            elif original_transceive:
                self._executor.communication.transceive = original_transceive


class DLMSOperations:
    """
    Class for executing DLMS operations (GET, SET, ACTION) with comprehensive frame details.
    
    This class provides a structured way to perform DLMS operations
    with consistent logging, error handling, and frame transmission details.
    """

    def __init__(self, executor: DLMSExecutor, config_dir: Optional[str] = None):
        """
        Initialize DLMS operations with an executor.
        
        Args:
            executor: DLMS executor instance to use for operations
            config_dir: Optional path to configuration directory for error codes
        """
        self._executor = executor
        self._enhanced_executor = EnhancedDLMSExecutor(executor)
        self._response_processor = DLMSResponseProcessor(config_dir)
        self._frame_collector = FrameDetailsCollector()
        self._mod = {LoggingConstants.MODULES_NAME: "DLMSOperations"}  # module tag for logs

    def get(self, class_id: int, obis_code: str, attribute_id: int,
            raise_unknown_errors: bool = False,
            field_names: list = None,
            selective_access: AbstractSelectiveAccess = None) -> Dict[str, Any]:
        """
        Execute a DLMS GET operation.
        
        Args:
            class_id: COSEM class ID
            obis_code: OBIS code string
            attribute_id: Attribute ID
            raise_unknown_errors: Whether to raise exception for unknown error codes
            field_names: Optional list of field names for structure key mapping
            selective_access: Optional selective access filter (e.g. RangeSelectiveAccess, EntrySelectiveAccess)
            
        Returns:
            Dictionary with operation result:
            {
                "success": bool,
                "value": str (hex) or None,
                "error_code": int,
                "error_description": str,
                "raw_data": object or None
            }
            
        Raises:
            FrameExecutorException: If operation fails
            RuntimeError: If raise_unknown_errors=True and error code not in auto_tools.json5
        """
        logger.info("===========================================================",**self._mod)
        logger.info(f"GET operation: class_id={class_id}, obis={obis_code}, attr={attribute_id}"
                    f"{', selective_access=' + type(selective_access).__name__ if selective_access else ''}",
                    **self._mod)
        logger.info("===========================================================", **self._mod)
        try:
            # Create request
            get_request = DLMSGetRequestNormal(class_id, obis_code, attribute_id, selective_access)

            # Execute with frame capture
            response = self._enhanced_executor.execute(get_request)

            # Collect frame details
            security_context = getattr(self._executor, 'builder', None)
            security_context = getattr(security_context, 'security_context', None) if security_context else None

            frame_details = self._frame_collector.collect_frame_details(
                request=get_request,
                response=response,
                security_context=security_context,
                transmitted_frames=self._enhanced_executor.last_transmitted_frames,
                received_frames=self._enhanced_executor.last_received_frames
            )

            # Process response with frame details
            result = self._response_processor.process_get_response(response, raise_unknown_errors, frame_details,
                                                                    field_names=field_names)

            if result["success"]:
                logger.info(f"Retrieved value: {result['value']}",)
                logger.info(f"GET operation completed successfully\n",
                            **self._mod)
            else:
                logger.warning(f"GET operation failed: {result['error_description']}\n",
                               **self._mod)

            return result

        except Exception as e:
            logger.error(f"GET operation failed: {e}\n",
                         **self._mod)
            raise

    def get_with_list(self, objects_list: List[Dict[str, int]],
                     raise_unknown_errors: bool = False,
                     selective_access: AbstractSelectiveAccess = None) -> Dict[str, Any]:
        """
        Execute a DLMS GET-WITH-LIST operation to read multiple attributes in a single request.
        
        Args:
            objects_list: List of dictionaries, each containing:
                - class_id: int - COSEM class ID
                - obis_code: str - OBIS code string
                - attribute_id: int - Attribute ID
            raise_unknown_errors: Whether to raise exception for unknown error codes
            selective_access: Optional selective access filter applied to ALL objects in the list
                (e.g. RangeSelectiveAccess, EntrySelectiveAccess)
            
        Returns:
            Dictionary with operation result:
            {
                "success": bool,
                "results": [
                    {
                        "success": bool,
                        "value": str (hex) or None,
                        "error_code": int,
                        "error_description": str,
                        "raw_data": object or None
                    },
                    ...
                ],
                "total_requested": int,
                "successful_count": int,
                "failed_count": int,
                "frame_details": {...}
            }
            
        Raises:
            FrameExecutorException: If operation fails
            RuntimeError: If raise_unknown_errors=True and error code not in auto_tools.json5
            ValueError: If objects_list is empty or invalid
        """
        if not objects_list:
            raise ValueError("objects_list cannot be empty")
        
        logger.info("===========================================================",**self._mod)
        sa_info = f", selective_access={type(selective_access).__name__}" if selective_access else ""
        logger.info(f"GET-WITH-LIST operation: {len(objects_list)} objects requested{sa_info}",
                    **self._mod)
        for idx, obj in enumerate(objects_list):
            logger.info(f"  [{idx+1}] class_id={obj.get('class_id')}, "
                       f"obis={obj.get('obis_code')}, attr={obj.get('attribute_id')}",
                       **self._mod)
        logger.info("===========================================================", **self._mod)
        
        try:
            # Create list of individual GET requests
            get_request_list = []
            for obj in objects_list:
                if not all(k in obj for k in ['class_id', 'obis_code', 'attribute_id']):
                    raise ValueError(f"Invalid object in list: {obj}. Must contain 'class_id', 'obis_code', and 'attribute_id'")
                
                get_request = DLMSGetRequestNormal(
                    obj['class_id'],
                    obj['obis_code'],
                    obj['attribute_id'],
                    selective_access
                )
                get_request_list.append(get_request)
            
            # Create the GET-WITH-LIST request
            get_request_with_list = DLMSGetRequestWithList(get_request_list)

            # Execute with frame capture
            response = self._enhanced_executor.execute(get_request_with_list)

            # Collect frame details
            security_context = getattr(self._executor, 'builder', None)
            security_context = getattr(security_context, 'security_context', None) if security_context else None

            frame_details = self._frame_collector.collect_frame_details(
                request=get_request_with_list,
                response=response,
                security_context=security_context,
                transmitted_frames=self._enhanced_executor.last_transmitted_frames,
                received_frames=self._enhanced_executor.last_received_frames
            )

            # Process response with frame details and objects list
            result = self._response_processor.process_get_response_with_list(
                response, raise_unknown_errors, frame_details, objects_list
            )

            if result["success"]:
                logger.info(f"GET-WITH-LIST completed: {result['successful_count']}/{result['total_requested']} successful",
                           **self._mod)
            else:
                logger.warning(f"GET-WITH-LIST completed with errors: "
                             f"{result['successful_count']}/{result['total_requested']} successful, "
                             f"{result['failed_count']} failed\n",
                             **self._mod)

            return result

        except Exception as e:
            logger.error("GET-WITH-LIST operation failed: {}\n", e,
                         **self._mod)
            raise

    def set(self, class_id: int, obis_code: str, attribute_id: int, value: Any,
            raise_unknown_errors: bool = False) -> Dict[str, Any]:
        """
        Execute a DLMS SET operation.
        
        Args:
            class_id: COSEM class ID
            obis_code: OBIS code string
            attribute_id: Attribute ID
            value: Value to set
            raise_unknown_errors: Whether to raise exception for unknown error codes
            
        Returns:
            Dictionary with operation result:
            {
                "success": bool,
                "value": str or None,
                "error_code": int,
                "error_description": str,
                "raw_data": object or None
            }
            
        Raises:
            FrameExecutorException: If operation fails
            RuntimeError: If raise_unknown_errors=True and error code not in auto_tools.json5
        """
        logger.info("===========================================================", **self._mod)
        logger.info(f"SET operation: class_id={class_id}, obis={obis_code}, attr={attribute_id}",
                    **self._mod)
        logger.info("===========================================================", **self._mod)
        try:
            # Create request
            set_request = DLMSSetRequestNormal(class_id, obis_code, attribute_id, value)

            # Execute with frame capture
            response = self._enhanced_executor.execute(set_request)

            # Collect frame details
            security_context = getattr(self._executor, 'builder', None)
            security_context = getattr(security_context, 'security_context', None) if security_context else None

            frame_details = self._frame_collector.collect_frame_details(
                request=set_request,
                response=response,
                security_context=security_context,
                transmitted_frames=self._enhanced_executor.last_transmitted_frames,
                received_frames=self._enhanced_executor.last_received_frames
            )

            # Process response with frame details
            result = self._response_processor.process_set_response(response, raise_unknown_errors, frame_details)

            if result["success"]:
                logger.info(f"SET operation completed successfully\n",
                            **self._mod)
            else:
                logger.warning(f"SET operation failed: {result['error_description']}\n",
                               **self._mod)

            return result

        except Exception as e:
            logger.error(f"SET operation failed: {e}\n",
                         **self._mod)
            raise

    def set_with_list(self, objects_list: List[Dict[str, Any]],
                      raise_unknown_errors: bool = False) -> Dict[str, Any]:
        """
        Execute a DLMS SET-WITH-LIST operation to write multiple attributes in a single request.

        Args:
            objects_list: List of dictionaries, each containing:
                - class_id: int - COSEM class ID
                - obis_code: str - OBIS code string
                - attribute_id: int - Attribute ID
                - value: Any - Value to set for this attribute
            raise_unknown_errors: Whether to raise exception for unknown error codes

        Returns:
            Dictionary with operation result:
            {
                "success": bool,
                "results": [...],
                "total_requested": int,
                "successful_count": int,
                "failed_count": int,
                "objects_list": list,
                "frame_details": {...}
            }

        Raises:
            FrameExecutorException: If operation fails
            RuntimeError: If raise_unknown_errors=True and error code not in auto_tools.json5
            ValueError: If objects_list is empty or invalid
        """
        if not objects_list:
            raise ValueError("objects_list cannot be empty")

        logger.info("===========================================================", **self._mod)
        logger.info(f"SET-WITH-LIST operation: {len(objects_list)} objects requested",
                    **self._mod)
        for idx, obj in enumerate(objects_list):
            logger.info(f"  [{idx + 1}] class_id={obj.get('class_id')}, "
                        f"obis={obj.get('obis_code')}, attr={obj.get('attribute_id')}",
                        **self._mod)
        logger.info("===========================================================", **self._mod)

        try:
            set_request_list = []
            for obj in objects_list:
                if not all(k in obj for k in ['class_id', 'obis_code', 'attribute_id', 'value']):
                    raise ValueError(
                        f"Invalid object in list: {obj}. Must contain 'class_id', 'obis_code', 'attribute_id', and 'value'"
                    )

                set_request = DLMSSetRequestNormal(
                    obj['class_id'],
                    obj['obis_code'],
                    obj['attribute_id'],
                    obj['value']
                )
                set_request_list.append(set_request)

            set_request_with_list = DLMSSetRequestWithList(set_request_list)

            response = self._enhanced_executor.execute(set_request_with_list)

            security_context = getattr(self._executor, 'builder', None)
            security_context = getattr(security_context, 'security_context', None) if security_context else None

            frame_details = self._frame_collector.collect_frame_details(
                request=set_request_with_list,
                response=response,
                security_context=security_context,
                transmitted_frames=self._enhanced_executor.last_transmitted_frames,
                received_frames=self._enhanced_executor.last_received_frames
            )

            result = self._response_processor.process_set_response_with_list(
                response, raise_unknown_errors, frame_details, objects_list
            )

            if result["success"]:
                logger.info(f"SET-WITH-LIST completed: {result['successful_count']}/{result['total_requested']} successful",
                            **self._mod)
            else:
                logger.warning(f"SET-WITH-LIST completed with errors: "
                               f"{result['successful_count']}/{result['total_requested']} successful, "
                               f"{result['failed_count']} failed\n",
                               **self._mod)

            return result

        except Exception as e:
            logger.error("SET-WITH-LIST operation failed: {}\n", e,
                         **self._mod)
            raise

    def action(self, class_id: int, obis_code: str, method_id: int, parameters: Optional[Any] = None,
               raise_unknown_errors: bool = False) -> Dict[str, Any]:
        """
        Execute a DLMS ACTION operation.
        
        Args:
            class_id: COSEM class ID
            obis_code: OBIS code string
            method_id: Method ID
            parameters: Optional method parameters
            raise_unknown_errors: Whether to raise exception for unknown error codes
            
        Returns:
            Dictionary with operation result:
            {
                "success": bool,
                "value": str (hex) or None,
                "error_code": int,
                "error_description": str,
                "raw_data": object or None
            }
            
        Raises:
            FrameExecutorException: If operation fails
            RuntimeError: If raise_unknown_errors=True and error code not in auto_tools.json5
        """
        logger.info("===========================================================", **self._mod)
        logger.info(f"ACTION operation: class_id={class_id}, obis={obis_code}, method={method_id}",
                    **self._mod)
        logger.info("===========================================================", **self._mod)
        try:
            # Create request
            action_request = DLMSActionRequestNormal(class_id, obis_code, method_id, parameters)

            # Execute with frame capture
            response = self._enhanced_executor.execute(action_request)

            # Collect frame details
            security_context = getattr(self._executor, 'builder', None)
            security_context = getattr(security_context, 'security_context', None) if security_context else None

            frame_details = self._frame_collector.collect_frame_details(
                request=action_request,
                response=response,
                security_context=security_context,
                transmitted_frames=self._enhanced_executor.last_transmitted_frames,
                received_frames=self._enhanced_executor.last_received_frames
            )

            # Process response with frame details
            result = self._response_processor.process_action_response(response, raise_unknown_errors, frame_details)

            if result["success"]:
                logger.info(f"ACTION operation completed successfully\n",
                            **self._mod)
            else:
                logger.warning(f"ACTION operation failed: {result['error_description']}\n",
                               **self._mod)

            return result

        except Exception as e:
            logger.error(f"ACTION operation failed: {e}",
                         **self._mod)
            raise

    def action_with_list(self, objects_list: List[Dict[str, Any]],
                         raise_unknown_errors: bool = False) -> Dict[str, Any]:
        """
        Execute a DLMS ACTION-WITH-LIST operation to execute multiple methods in a single request.

        Args:
            objects_list: List of dictionaries, each containing:
                - class_id: int - COSEM class ID
                - obis_code: str - OBIS code string
                - method_id: int - Method ID
                - parameters: Optional[Any] - Method parameters
            raise_unknown_errors: Whether to raise exception for unknown error codes

        Returns:
            Dictionary with operation result:
            {
                "success": bool,
                "results": [...],
                "total_requested": int,
                "successful_count": int,
                "failed_count": int,
                "objects_list": list,
                "frame_details": {...}
            }

        Raises:
            FrameExecutorException: If operation fails
            RuntimeError: If raise_unknown_errors=True and error code not in auto_tools.json5
            ValueError: If objects_list is empty or invalid
        """
        if not objects_list:
            raise ValueError("objects_list cannot be empty")

        logger.info("===========================================================", **self._mod)
        logger.info(f"ACTION-WITH-LIST operation: {len(objects_list)} objects requested",
                    **self._mod)
        for idx, obj in enumerate(objects_list):
            logger.info(f"  [{idx + 1}] class_id={obj.get('class_id')}, "
                        f"obis={obj.get('obis_code')}, method={obj.get('method_id')}",
                        **self._mod)
        logger.info("===========================================================", **self._mod)

        try:
            action_request_list = []
            for obj in objects_list:
                if not all(k in obj for k in ['class_id', 'obis_code', 'method_id']):
                    raise ValueError(
                        f"Invalid object in list: {obj}. Must contain 'class_id', 'obis_code', and 'method_id'"
                    )

                action_request = DLMSActionRequestNormal(
                    obj['class_id'],
                    obj['obis_code'],
                    obj['method_id'],
                    obj.get('parameters')
                )
                action_request_list.append(action_request)

            action_request_with_list = DLMSActionRequestWithList(action_request_list)

            response = self._enhanced_executor.execute(action_request_with_list)

            security_context = getattr(self._executor, 'builder', None)
            security_context = getattr(security_context, 'security_context', None) if security_context else None

            frame_details = self._frame_collector.collect_frame_details(
                request=action_request_with_list,
                response=response,
                security_context=security_context,
                transmitted_frames=self._enhanced_executor.last_transmitted_frames,
                received_frames=self._enhanced_executor.last_received_frames
            )

            result = self._response_processor.process_action_response_with_list(
                response, raise_unknown_errors, frame_details, objects_list
            )

            if result["success"]:
                logger.info(f"ACTION-WITH-LIST completed: {result['successful_count']}/{result['total_requested']} successful",
                            **self._mod)
            else:
                logger.warning(f"ACTION-WITH-LIST completed with errors: "
                               f"{result['successful_count']}/{result['total_requested']} successful, "
                               f"{result['failed_count']} failed\n",
                               **self._mod)

            return result

        except Exception as e:
            logger.error("ACTION-WITH-LIST operation failed: {}\n", e,
                         **self._mod)
            raise


# =============================================================================
# BACKWARD COMPATIBILITY FUNCTIONS
# =============================================================================

def execute_get_operation(executor: DLMSExecutor, class_id: int, obis_code: str, attribute_id: int) -> Any:
    """Backward compatibility wrapper for get operation."""
    operations = DLMSOperations(executor)
    return operations.get(class_id, obis_code, attribute_id)


def execute_set_operation(executor: DLMSExecutor, class_id: int, obis_code: str, attribute_id: int, value: Any) -> Any:
    """Backward compatibility wrapper for set operation."""
    operations = DLMSOperations(executor)
    return operations.set(class_id, obis_code, attribute_id, value)


def execute_action_operation(executor: DLMSExecutor, class_id: int, obis_code: str, method_id: int,
                             parameters: Optional[Any] = None) -> Any:
    """Backward compatibility wrapper for action operation."""
    operations = DLMSOperations(executor)
    return operations.action(class_id, obis_code, method_id, parameters)


def execute_get_with_list_operation(executor: DLMSExecutor, objects_list: List[Dict[str, int]]) -> Dict[str, Any]:
    """Backward compatibility wrapper for get-with-list operation."""
    operations = DLMSOperations(executor)
    return operations.get_with_list(objects_list)


def execute_set_with_list_operation(executor: DLMSExecutor, objects_list: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Backward compatibility wrapper for set-with-list operation."""
    operations = DLMSOperations(executor)
    return operations.set_with_list(objects_list)


def execute_action_with_list_operation(executor: DLMSExecutor, objects_list: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Backward compatibility wrapper for action-with-list operation."""
    operations = DLMSOperations(executor)
    return operations.action_with_list(objects_list)
