import asyncio
import socket
import threading

from ng_sdk.configuration.config_manager import ConfigManager
from ng_sdk.frame_builder.dlms.dlms_enums import NotificationServiceClass
from ng_sdk.frame_builder.dlms.xdlms.data_notification.dlms_data_notification import DlmsDataNotification
from ng_sdk.frame_builder.dlms.xdlms.data_notification.dlms_data_notification_confirm import DlmsDataNotificationConfirm
from ng_sdk.frame_builder.dlms.xdlms.get_dlms_cipher import GetDlmsCipher
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.push_data_server.abstract_server import AbstractServer
from ng_sdk.push_data_server.communication.udp_communication import UdpCommunication
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.session.dlms_session import DLMSSession
from ng_sdk.transport.abstract_transport import AbstractTransport
from ng_sdk.transport.tcp.tcp_transport import TCPUDPTransport
from ng_sdk.util.bytes_util import encode_length

logger = get_logger()

_handle_push_mod = {LoggingConstants.MODULES_NAME: "UdpServer"}


class UdpServer(AbstractServer):

    _mod = {LoggingConstants.MODULES_NAME: "UdpServer"}

    def __init__(self, host, port, configuration,security_context: SecurityContext, transport: AbstractTransport, handler, is_complete=None):
        super().__init__(configuration, security_context, transport, is_complete)
        self.host = host
        self.port = port
        self.handler = handler
        self._sock: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._running = False

    # -------- AbstractServer --------

    async def start(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.bind((self.host, self.port))
        self._running = True
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()
        logger.info(f"[UDP] Listening on {self.host}:{self.port}", **self._mod)

    async def stop(self):
        self._running = False
        if self._sock:
            self._sock.close()
            self._sock = None
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None
        logger.info("[UDP] Server stopped", **self._mod)

    # -------- Sequential receive / send loop --------

    def _serve(self):

        while self._running:
            try:
                data, addr = self._sock.recvfrom(4096)
            except OSError:
                break  # socket closed
            comm = UdpCommunication(
                configuration=self.configuration,
                sock=self._sock,
                addr=addr,
            )
            data = comm.transport.unwrap(data)
            logger.info(f"Unwrapped data from {addr}: {data.hex()}", **self._mod)


            self._process_data(data, addr, comm, lambda: self._sock.recvfrom(4096)[0])


