import socket
from typing import Optional

from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.transport.tcp.tcp_transport import TCPUDPTransport


class UdpCommunication(AbstractCommunication):

    def __init__(
        self,
        configuration,
        sock: socket.socket,
        addr,
        is_complete=TCPUDPTransport.is_complete,
        timeout: float = 5.0,
    ):
        super().__init__(configuration, is_complete)
        self.sock = sock
        self.addr = addr
        self.timeout = timeout
        self.transport = TCPUDPTransport(configuration)

    def open(self):
        self.is_opened = True

    def close(self):
        self.is_opened = False

    # ----------------------------
    # Public API
    # ----------------------------
    def send(self, frame: bytes):
        self.sock.sendto(self.transport.wrap(frame), self.addr)

    def receive(self) -> bytes:


        data, _ = self.sock.recvfrom(4096)
        return self.transport.unwrap(data)

    def transceive(self, frame: bytes) -> bytes:
        self.send(frame)
        return self.receive()