import socket
import time

from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.transport.tcp.tcp_transport import TCPUDPTransport


class TcpCommunication(AbstractCommunication):

    def __init__(self, configuration, sock: socket.socket, is_complete=TCPUDPTransport.is_complete, timeout: float = 5.0):
        if is_complete is None:
            is_complete = TCPUDPTransport.is_complete
        super().__init__(configuration, is_complete)
        self.sock = sock
        self.transport = TCPUDPTransport(configuration)
        self.timeout = timeout

    def open(self):

        self.is_opened = True

    def close(self):

        self.is_opened = False

    def send(self, frame: bytes):
        wrapped = self.transport.wrap(frame)
        self.sock.sendall(wrapped)

    def receive(self) -> bytes:

        buffer = b""
        while True:

            chunk = self.sock.recv(2048)
            if not chunk:
                break
            buffer += chunk
            if self.is_complete and self.is_complete(buffer):
                break
        return self.transport.unwrap(buffer)

    def transceive(self, frame: bytes) -> bytes:
        self.send(frame)
        return self.receive()