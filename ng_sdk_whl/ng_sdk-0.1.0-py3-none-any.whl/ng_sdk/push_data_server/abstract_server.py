from abc import ABC, abstractmethod
from typing import Callable

from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.frame_builder.dlms.xdlms.data_notification.dlms_data_notification import DlmsDataNotification
from ng_sdk.frame_builder.dlms.xdlms.get_dlms_cipher import GetDlmsCipher
from ng_sdk.frame_executor.models.general_block_transfer import GeneralBlockTransfer
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.transport.abstract_transport import AbstractTransport
from ng_sdk.util.bytes_util import extract_length

logger = get_logger()


class AbstractServer(ABC):
    """
    Abstract network server (UDP / TCP / other).
    """

    _mod = {LoggingConstants.MODULES_NAME: "AbstractServer"}  # override in child classes

    def __init__(self, configuration, security_context: SecurityContext, transport: AbstractTransport, is_complete=None):
        self.configuration = configuration
        self.security_context = security_context
        self.is_complete = is_complete
        self.transport = transport

    # -------- Shared processing logic --------

    def _process_data(self, data: bytes, addr, comm:AbstractCommunication, recv_more: Callable[[], bytes]):
        """
        Handles GBT reassembly, GENERAL_CIPHERING decryption and calls self.handler.
        recv_more: callable that returns the next raw unwrapped chunk.
        """
        source_port = comm.transport.source_port
        dest_port = comm.transport.dest_port
        server_system_title = None
        final_response = bytearray()

        if data[0] == GeneralBlockTransfer.TAG:
            response_gbt = GeneralBlockTransfer.from_bytes(data)
            last_block = response_gbt.block_control.last_block
            _, block_data = extract_length(response_gbt.block_data.value)
            final_response.extend(block_data)
            while not last_block:
                chunk = comm.receive()
                if not chunk:
                    break
                #chunk = self.transport.unwrap(chunk)
                if chunk[0] != GeneralBlockTransfer.TAG:
                    break
                response_gbt = GeneralBlockTransfer.from_bytes(chunk)
                last_block = response_gbt.block_control.last_block
                _, block_data = extract_length(response_gbt.block_data.value)
                final_response.extend(block_data)
        else:
            final_response.extend(data)

        if final_response[0] == GetDlmsCipher.GENERAL_CIPHERING:
            raw = bytes(final_response)
            raw = raw[1:]
            ap_title_length = int.from_bytes(raw[:1], "big")
            raw = raw[1:]
            server_system_title = raw[:ap_title_length]
            self.security_context.set_server_system_title(server_system_title)
            raw = raw[8:]
            _, raw = extract_length(raw)
            logger.info(f"Data to decipher: {raw.hex()}", **self._mod)
            final_response = self.security_context.decipher(raw)

        logger.info(f"Final response from {addr}: {bytes(final_response).hex()}", **self._mod)
        self.handler(DlmsDataNotification(final_response), addr, comm, source_port, dest_port, server_system_title)

    @abstractmethod
    async def start(self):
        """Start the server"""
        pass

    @abstractmethod
    async def stop(self):
        """Stop the server"""
        pass