import asyncio
import queue
import threading
from dataclasses import dataclass
from typing import Optional

from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.frame_builder.dlms.xdlms.data_notification.dlms_data_notification import DlmsDataNotification
from ng_sdk.frame_builder.dlms.xdlms.data_notification.dlms_data_notification_confirm import DlmsDataNotificationConfirm
from ng_sdk.frame_builder.dlms.xdlms.get_dlms_cipher import GetDlmsCipher
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.push_data_server.abstract_server import AbstractServer
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.util.bytes_util import encode_length

logger = get_logger()
_mod = {LoggingConstants.MODULES_NAME: "PushDataServerManager"}


@dataclass
class PushNotification:
    """Holds all data received from a push notification."""
    notification: DlmsDataNotification
    addr: tuple
    communication: AbstractCommunication
    source_port: int
    dest_port: int
    server_system_title: Optional[bytes]


class PushDataServerManager:
    """
    Manages a push data server (TCP or UDP) and exposes a thread-safe queue
    so Robot Framework keywords can wait for notifications and send acks.
    """

    def __init__(self):
        self._server: Optional[AbstractServer] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._notification_queue: queue.Queue = queue.Queue()

    # ------------------------------------------------------------------ #
    #  Lifecycle                                                           #
    # ------------------------------------------------------------------ #

    def start(self, server: AbstractServer):
        """Start the server in a dedicated asyncio event loop thread."""
        if self._server is not None:
            raise RuntimeError("Server already started")
        self._server = server
        server.handler = self._on_notification
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=self._run_loop, daemon=True, name="PushServerLoop")
        self._thread.start()
        logger.info("Push data server manager started", **_mod)

    def stop(self):
        """Stop the server and the event loop."""
        if self._loop and self._server:
            asyncio.run_coroutine_threadsafe(self._server.stop(), self._loop).result(timeout=10)
        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread:
            self._thread.join(timeout=10)
        self._server = None
        self._loop = None
        self._thread = None
        logger.info("Push data server manager stopped", **_mod)

    # ------------------------------------------------------------------ #
    #  Robot-facing API                                                    #
    # ------------------------------------------------------------------ #

    def wait_for_notification(self, timeout: float = 30.0) -> PushNotification:
        """
        Block until a push notification arrives or timeout expires.

        Raises:
            TimeoutError if no notification arrives within timeout.
        """
        try:
            notif = self._notification_queue.get(timeout=timeout)
            logger.info(f"Notification received from {notif.addr}", **_mod)
            return notif
        except queue.Empty:
            raise TimeoutError(f"No push notification received within {timeout}s")

    def send_ack(self, push_notification: PushNotification, security_context: SecurityContext) -> None:
        """
        Build a ciphered GENERAL_CIPHERING ack and send it back to the device.

        Args:
            push_notification: The notification returned by wait_for_notification.
            security_context:  SecurityContext used to cipher the ack frame.
        """
        communication = push_notification.communication
        notification = push_notification.notification
        source_port = push_notification.source_port
        dest_port = push_notification.dest_port

        ciphered_data = security_context.cipher(
            DlmsDataNotificationConfirm(notification.invoke_id).to_bytes()
        )
        logger.info(f"Ciphered data: {ciphered_data.hex().upper()}", **_mod)

        system_title = security_context.get_system_title()
        logger.info(f"System title: {system_title.hex().upper()}", **_mod)

        data_to_send = (
            bytes([GetDlmsCipher.GENERAL_CIPHERING])
            + encode_length(len(system_title))
            + system_title
            + encode_length(len(ciphered_data))
            + ciphered_data
        )
        logger.info(f"Data to send: {data_to_send.hex().upper()}", **_mod)

        old_dest_port = communication.configuration.communication.tcp.association_id
        old_source_port = communication.configuration.communication.tcp.device_id
        communication.configuration.communication.tcp.association_id = dest_port
        communication.configuration.communication.tcp.device_id = source_port
        communication.send(data_to_send)
        communication.configuration.communication.tcp.association_id = old_dest_port
        communication.configuration.communication.tcp.device_id = old_source_port

        logger.info(f"Ack sent to {push_notification.addr}", **_mod)

    # ------------------------------------------------------------------ #
    #  Internal                                                            #
    # ------------------------------------------------------------------ #

    def _run_loop(self):
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._server.start())
        self._loop.run_forever()

    def _on_notification(
        self,
        notification: DlmsDataNotification,
        addr: tuple,
        communication: AbstractCommunication,
        source_port: int,
        dest_port: int,
        server_system_title: Optional[bytes],
    ):
        """Internal handler — enqueues the notification for Robot keywords."""
        self._notification_queue.put(PushNotification(
            notification=notification,
            addr=addr,
            communication=communication,
            source_port=source_port,
            dest_port=dest_port,
            server_system_title=server_system_title,
        ))
