import asyncio
import socket
import threading
import traceback
from datetime import datetime

from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.configuration.config_manager import ConfigManager
from ng_sdk.frame_builder.dlms.dlms_enums import NotificationServiceClass
from ng_sdk.frame_builder.dlms.xdlms.data_notification.dlms_data_notification import DlmsDataNotification
from ng_sdk.frame_builder.dlms.xdlms.data_notification.dlms_data_notification_confirm import DlmsDataNotificationConfirm
from ng_sdk.frame_builder.dlms.xdlms.data_type.date_time import DateTime
from ng_sdk.frame_builder.dlms.xdlms.get_dlms_cipher import GetDlmsCipher
from ng_sdk.logger.logger import LoggingConstants, get_logger
from ng_sdk.push_data_server.abstract_server import AbstractServer
from ng_sdk.push_data_server.communication.tcp_communication import TcpCommunication
from ng_sdk.security.security_context import SecurityContext
from ng_sdk.session.dlms_session import DLMSSession
from ng_sdk.transport.abstract_transport import AbstractTransport
from ng_sdk.transport.tcp.tcp_transport import TCPUDPTransport
from ng_sdk.util.bytes_util import encode_length

logger = get_logger()


class TcpServer(AbstractServer):

    _mod = {LoggingConstants.MODULES_NAME: "TcpServer"}

    def __init__(self, host, port, configuration, handler, security_context: SecurityContext, transport: AbstractTransport, is_complete=None):
        super().__init__(configuration, security_context, transport, is_complete)
        self.host = host
        self.port = port
        self.handler = handler
        self._sock: socket.socket | None = None
        self._accept_thread: threading.Thread | None = None
        self._running = False

    # -------- AbstractServer --------

    async def start(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((self.host, self.port))
        self._sock.listen(5)
        self._running = True
        self._accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._accept_thread.start()
        logger.info(f"[TCP] Listening on {self.host}:{self.port}", **self._mod)

    async def stop(self):
        self._running = False
        if self._sock:
            self._sock.close()
            self._sock = None
        if self._accept_thread:
            self._accept_thread.join(timeout=5)
            self._accept_thread = None
        logger.info("[TCP] Server stopped", **self._mod)

    # -------- Accept loop --------

    def _accept_loop(self):
        while self._running:
            try:
                conn, addr = self._sock.accept()
            except OSError:
                break  # socket closed
            t = threading.Thread(target=self._handle_client, args=(conn, addr), daemon=True)
            t.start()

    # -------- Per-client sequential receive / send loop --------

    def _handle_client(self, conn: socket.socket, addr):
        comm = TcpCommunication(
            configuration=self.configuration,
            sock=conn,
            is_complete=self.is_complete
        )
        try:
            data = comm.receive()
            if not data:
                logger.info("Received empty data", **self._mod)
                return
            logger.info(f"Received data from {addr}: {data.hex()}", **self._mod)
            #data = self.transport.unwrap(data)
            logger.info(f"Unwrapped data from {addr}: {data.hex()}", **self._mod)

            self._process_data(data, addr, comm, lambda: conn.recv(4096))
        except Exception as e:
            logger.error(f"Error handling client {addr}: {e}", **self._mod)
            traceback.print_exc()






