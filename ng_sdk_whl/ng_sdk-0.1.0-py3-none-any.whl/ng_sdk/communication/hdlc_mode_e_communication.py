import serial

from ng_sdk.constant.hdlc.constant import MODEE_BAUDRATE
from ng_sdk.communication.hdlc_communication import HDLCCommunication
from ng_sdk.constant.logger.constant import LoggingConstants
from ng_sdk.logger.logger import get_logger

log = get_logger()
_mod = {LoggingConstants.MODULES_NAME: "SerialCommunication"}  # module tag for logs
class HDLCModeECommunication(HDLCCommunication):

    def open(self):
        # mode e baudrate nego
        baudrate = self.configuration.communication.serial.baudrate
        modee_baudrate = self.configuration.communication.hdlc.modee_baudrate
        if modee_baudrate is None:
            modee_baudrate = MODEE_BAUDRATE

        self.configuration.communication.serial.baudrate = modee_baudrate
        self.configuration.communication.serial.parity = serial.PARITY_EVEN
        self.configuration.communication.serial.bytesize = serial.SEVENBITS
        log.info(
            f"[ModeE] switching serial to mode-e: baudrate={modee_baudrate}, parity=EVEN, bytesize=7",
            _mod,
        )
        self.lower.is_complete = self.mode_e_1_complete
        self.lower.open()
        response = self.lower.transceive(bytes.fromhex("2F3F210D0A"))
        log.info(
            "INFO",
            f"[ModeE] <- resp1 {response.hex().upper()}",
            _mod,
        )
        self.lower.send(bytes.fromhex("063235320D0A"))
        self.lower.close()
        self.configuration.communication.serial.baudrate = baudrate
        self.configuration.communication.serial.parity = None
        self.configuration.communication.serial.bytesize = None
        self.lower.open()
        self.lower.is_complete = self.mode_e_2_complete
        response = self.lower.receive()
        log.info(
            f"[ModeE] <- resp2 {response.hex().upper()}",
            _mod,
        )        # send SNRM
        self.lower.is_complete = self.is_complete
        log.debug( "[ModeE] negotiation done, calling super().open()", _mod)
        super().open()

    @staticmethod
    def mode_e_1_complete(frame: bytes) -> bool:
        if len(frame) < 2:
            return False

        return frame[0] == 0x2F and frame[len(frame)-1] == 0x0A

    @staticmethod
    def mode_e_2_complete(frame: bytes) -> bool:
        if len(frame) < 2:
            return False

        return frame[0] == 0x06 and frame[len(frame) - 1] == 0x0A
