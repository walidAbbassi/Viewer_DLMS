import time
from typing import Optional

import serial
from serial import PARITY_NONE
from serial.serialutil import EIGHTBITS

from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.configuration.config_manager import ConfigModuleProxy
from ng_sdk.constant.communication.constant import TIMEOUT, MAX_RETRIES, RETRY_DELAY
from ng_sdk.constant.logger.constant import LoggingConstants
from ng_sdk.error.communication_exception import  CommunicationException, CommunicationError
from ng_sdk.logger.logger import get_logger

log = get_logger()
_mod = {LoggingConstants.MODULES_NAME: "SerialCommunication"}  # module tag for logs
class SerialCommunication(AbstractCommunication):
    _ser: Optional[serial.Serial] = None
    _last_sent_frame: Optional[bytes] = None  # stored by send(), re-sent on retry
    _had_serial_error: bool = False            # True only when SerialException occurs

    def open(self):
        parity = PARITY_NONE
        if isinstance(self.configuration.communication.serial.parity, str):
            parity = self.configuration.communication.serial.parity
        log.trace(f"parity={parity}", _mod)
        bytesize = EIGHTBITS
        if isinstance(self.configuration.communication.serial.bytesize, int):
            bytesize = self.configuration.communication.serial.bytesize
        log.trace(f"bytesize={bytesize}", _mod)
        timeout = TIMEOUT
        if isinstance(self.configuration.communication.serial.timeout, (int, float)):
            timeout = self.configuration.communication.serial.timeout
            log.trace( f"timeout={timeout}", _mod)
        log.trace( f"timeout={timeout}", _mod)
        baudrate = self.configuration.communication.serial.baudrate
        if not isinstance(baudrate, int):
            log.error("Invalid baudrate (not int)", _mod)
            raise CommunicationException(CommunicationError.INVALID_BAUDRATE)
        port = self.configuration.communication.serial.port
        if port is None or isinstance(port, ConfigModuleProxy):
            log.error( "Invalid serial port", _mod)
            raise CommunicationException(CommunicationError.INVALID_SERIAL_PORT)
        self._ser = serial.Serial(port, baudrate, timeout=timeout, parity=parity, bytesize=bytesize)
        self.is_opened = True
        log.info(f"Serial port '{port}' opened ({baudrate}-{bytesize}-1-{parity})", _mod)

    def close(self):
        if self._ser and self._ser.is_open:
            time_waited = 0.1
            log.trace("Flushing before closing...", _mod)
            self._ser.flush()
            log.trace(f"Waiting {time_waited}s to ensure transmission completes...", _mod)
            time.sleep(time_waited)
            self._ser.close()
            log.info( "Serial port closed\n", _mod)
        self.is_opened = False

    def transceive(self, frame: bytes) -> bytes:
        self.send(frame)
        return self.receive()

    def send(self, frame: bytes):
        self._last_sent_frame = frame  # remember for retry re-send
        self._had_serial_error = False  # reset on each new send
        log.info("  Send Frame: " + frame.hex().upper(), _mod)
        if self._ser and self._ser.is_open:
            self._ser.write(frame)
            self._ser.flush()

    def receive(self) -> bytes:
        if not self.is_opened or self._ser is None:
            log.error("receive called while port not opened", _mod)
            raise CommunicationException(CommunicationError.SERIAL_PORT_CLOSED)
        timeout = self.configuration.communication.serial.timeout
        if isinstance(self.configuration.communication.serial.timeout, ConfigModuleProxy):
            timeout = TIMEOUT
        max_retries = self.configuration.communication.max_retries
        if isinstance(self.configuration.communication.max_retries, ConfigModuleProxy):
            max_retries = MAX_RETRIES
        retry_delay = self.configuration.communication.retry_delay
        if isinstance(self.configuration.communication.retry_delay, ConfigModuleProxy):
            retry_delay = RETRY_DELAY
        attempt = 0
        while True:
            attempt += 1
            buf = bytearray()
            start_time = last_byte = time.monotonic()
            absolute_deadline = start_time + timeout

            while True:
                # read whatever has arrived
                try:
                    n = self._ser.in_waiting
                    if n:
                        chunk = self._ser.read(n)
                        buf += chunk
                        last_byte = time.monotonic()
                except serial.SerialException:
                    self._had_serial_error = True
                    break

                # check completion
                if self.is_complete and self.is_complete(bytes(buf)):
                    log.info("  Receive Frame: " + buf.hex().upper(), _mod)
                    return bytes(buf)

                now = time.monotonic()

                # never got a byte before overall timeout
                if not buf and now >= absolute_deadline:
                    log.warning(
                        f"Attempt {attempt}: no data received before timeout",
                        _mod,
                    )
                    break  # retry if attempts remain

                # got partial data then idle timeout
                if buf and (now - last_byte) >= timeout:
                    log.info(
                        f"Attempt {attempt}: idle timeout, returning partial: {buf.hex().upper()}",
                        _mod,
                    )
                    if self.is_complete and self.is_complete(bytes(buf)):
                        return bytes(buf)
                    break  # retry if attempts remain
                time.sleep(0.005)

            # if we reach here, no data at all this attempt
            if attempt >= max_retries:
                log.error(
                    f"All {max_retries} attempts failed, meter not responding",
                    _mod,
                )
                if self._on_meter_unreachable:
                    self._on_meter_unreachable(max_retries)
                raise CommunicationException(CommunicationError.METER_NOT_RESPONDING)
            else:
                log.info(
                    f"Retrying receive (attempt {attempt + 1}/{max_retries}) in {retry_delay}s",
                    _mod,
                )
                if self._on_retry:
                    self._on_retry(attempt + 1, max_retries)
                time.sleep(retry_delay)
                if self._last_sent_frame is not None and self._ser and self._ser.is_open:
                    self._had_serial_error = False
                    log.info("  Re-sending frame for retry: " + self._last_sent_frame.hex().upper(), _mod)
                    self._ser.write(self._last_sent_frame)
                    self._ser.flush()
