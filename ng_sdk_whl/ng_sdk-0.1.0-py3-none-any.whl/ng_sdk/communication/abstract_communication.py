from abc import ABC, abstractmethod
from typing import Callable, Optional

from ng_sdk.configuration.config_manager import  ConfigModuleProxy


class AbstractCommunication(ABC):
    def __init__(self,configuration: ConfigModuleProxy,is_complete: Optional[Callable[[bytes], bool]] = None):
        self.is_opened = False
        self.is_complete = is_complete
        self.configuration = configuration
        self._on_retry: Optional[Callable[[int, int], None]] = None
        self._on_meter_unreachable: Optional[Callable[[int], None]] = None

    def set_retry_hooks(
        self,
        on_retry: Optional[Callable[[int, int], None]] = None,
        on_meter_unreachable: Optional[Callable[[int], None]] = None,
    ) -> None:
        """
        Register callbacks triggered during receive retries.

        :param on_retry: called on each retry attempt — on_retry(attempt, max_retries)
        :param on_meter_unreachable: called when all retries are exhausted — on_meter_unreachable(max_retries)
        """
        self._on_retry = on_retry
        self._on_meter_unreachable = on_meter_unreachable

    @abstractmethod
    def open(self):
        pass
    @abstractmethod
    def close(self):
        pass
    @abstractmethod
    def transceive(self,frame:bytes)->bytes:
        pass
    @abstractmethod
    def send(self,frame:bytes):
        pass
    @abstractmethod
    def receive(self)->bytes:
        pass