from typing import Optional, Callable

from ng_sdk.communication.abstract_communication import AbstractCommunication

from ng_sdk.configuration.config_manager import  ConfigModuleProxy
from ng_sdk.constant.hdlc.constant import WINDOW
from ng_sdk.constant.logger.constant import LoggingConstants
from ng_sdk.logger.logger import get_logger
from ng_sdk.transport.hdlc.hdlc_control import HDLCControl, FrameType
from ng_sdk.transport.hdlc.hdlc_transport import HDLCTransport
from ng_sdk.transport.hdlc.snrm_data import SnrmData

log = get_logger()
class HDLCCommunication(AbstractCommunication):
    hdlc_transport: Optional[HDLCTransport] = None
    _mod = {LoggingConstants.MODULES_NAME: "HDLC"}

    def __init__(self, configuration: ConfigModuleProxy, lower_layer: AbstractCommunication, is_complete: Optional[Callable[[bytes], bool]] = None):
        log.trace("HDLCCommunication.__init__", **self._mod)

        super().__init__(configuration, is_complete)
        self.lower = lower_layer
        self.lower.is_complete = is_complete
        self._nr = 0
        self._ns = 0

    def set_retry_hooks(
        self,
        on_retry: Optional[Callable[[int, int], None]] = None,
        on_meter_unreachable: Optional[Callable[[int], None]] = None,
    ) -> None:
        super().set_retry_hooks(on_retry, on_meter_unreachable)
        self.lower.set_retry_hooks(on_retry, on_meter_unreachable)

    def open(self):
        if not self.lower.is_opened:
            log.trace( "Lower layer opening…", **self._mod)
            self.lower.open()
            log.trace( "Lower layer opened", **self._mod)

        # send SNRM
        dest_addr = self.configuration.communication.server_addr
        dest_len = self.configuration.communication.server_addr_len
        src_addr = self.configuration.communication.client_addr
        src_len = self.configuration.communication.client_addr_len
        self.hdlc_transport = HDLCTransport(dest_addr, dest_len, src_addr, src_len)
        self.hdlc_transport.control = HDLCControl(FrameType.SNRM)
        snrm_data = b''
        if self.configuration.communication.hdlc.enable_hdlc_negociation and not isinstance(self.configuration.communication.hdlc.hdlc_negociation, ConfigModuleProxy):
            max_info_transmit_length = self.configuration.communication.hdlc.hdlc_negociation.max_info_transmit_length
            max_info_transmit_value = self.configuration.communication.hdlc.hdlc_negociation.max_info_transmit_value
            max_info_receive_length = self.configuration.communication.hdlc.hdlc_negociation.max_info_receive_length
            max_info_receive_value = self.configuration.communication.hdlc.hdlc_negociation.max_info_receive_value
            window_size_transmit_length = self.configuration.communication.hdlc.hdlc_negociation.window_size_transmit_length
            window_size_transmit_value = self.configuration.communication.hdlc.hdlc_negociation.window_size_transmit_value
            window_size_receive_length = self.configuration.communication.hdlc.hdlc_negociation.window_size_receive_length
            window_size_receive_value = self.configuration.communication.hdlc.hdlc_negociation.window_size_receive_value
            snrm_data = SnrmData(max_info_transmit_length, max_info_transmit_value, max_info_receive_length, max_info_receive_value, window_size_transmit_length, window_size_transmit_value, window_size_receive_length, window_size_receive_value).to_bytes()
        snrm = self.hdlc_transport.wrap(snrm_data)
        log.info("Build Frame : Set Normal Response Mode(SNRM)", **self._mod)
        log.trace(
            f"TX SNRM -> {snrm.hex().upper()} (data={snrm_data.hex().upper() if snrm_data else ''})",
            **self._mod,
        )
        snrm_response = self.lower.transceive(snrm)
        snrm_response = SnrmData.from_bytes(self.hdlc_transport.unwrap(snrm_response))

        self.configuration.communication.hdlc.max_info_transmit_value = snrm_response.maximum_information_field_length_value_transmit
        self.configuration.communication.hdlc.max_info_receive_value = snrm_response.maximum_information_field_length_value_transmit
        self.configuration.communication.hdlc.window_size_transmit_value = snrm_response.window_size_value_transmit
        self.configuration.communication.hdlc.window_size_receive_value = snrm_response.window_size_value_receive
        self.is_opened = True

    def close(self):
        self._nr = 0
        self._ns = 0
        # send disconnect
        log.info("Build Frame : Disconnect Command(DISC)", **self._mod)
        self.hdlc_transport.control = HDLCControl(FrameType.DISC)
        disc = self.hdlc_transport.wrap(b'')
        log.trace( f"TX DISC -> {disc.hex().upper()}", **self._mod)
        self.lower.transceive(disc)
        self.lower.close()
        self.is_opened = False
        log.trace( "Lower layer closed", **self._mod)

    def transceive(self, payload: bytes) -> bytes:
        dest_addr = self.configuration.communication.server_addr
        dest_len = self.configuration.communication.server_addr_len
        src_addr = self.configuration.communication.client_addr
        src_len = self.configuration.communication.client_addr_len
        self.hdlc_transport.dest_addr = dest_addr
        self.hdlc_transport.dest_len = dest_len
        self.hdlc_transport.src_addr = src_addr
        self.hdlc_transport.src_len = src_len
        log.trace(f"transceive: payload_len={len(payload)}", **self._mod)
        self.send(payload)
        return self.receive()

    def send(self, payload: bytes):

        max_apdu_size = self.configuration.communication.hdlc.max_info_transmit_value - 3
        window = self.configuration.communication.hdlc.window_size_transmit_value
        if not isinstance(window, int):
            window = WINDOW
        slices = [payload[i:i + max_apdu_size] for i in range(0, len(payload), max_apdu_size)]
        log.trace(
            f"send: total_len={len(payload)} chunks={len(slices)} max_apdu={max_apdu_size} window={window}",
            **self._mod,
        )
        sent = 0
        # send payload and fragment it if needed
        for idx, chunk in enumerate(slices):
            is_last = (idx == len(slices) - 1)
            self.hdlc_transport.control = HDLCControl(FrameType.I, with_suffix=idx == 0, ns=self._ns, nr=self._nr,
                                                      pf=0 if sent + 1 < window else 1)
            self.hdlc_transport.segmentation = 0 if is_last else 1
            frame = self.hdlc_transport.wrap(chunk)
            self.lower.send(frame)
            self._ns = (self._ns + 1) % 8
            sent += 1
            if sent >= window and len(slices) > 1 and idx < len(slices) - 1:
                sent = 0
                rr_response = self.lower.receive()
                self.hdlc_transport.unwrap(rr_response)
                resp_control = self.hdlc_transport.control
                log.debug(
                    f"RX RR <- {rr_response.hex().upper()}",
                    **self._mod,
                )
                if resp_control.frame_type == FrameType.RR:
                    log.info(
                        f"RR received: nr={resp_control.nr} (after sending ns={self._ns})",
                        **self._mod,
                    )                    # self._ns = (resp_control.nr + 1) % 8

    def receive(self) -> bytes:
        # receive response
        response = bytearray()
        resp = self.lower.receive()
        log.trace( f"RX <- {resp.hex().upper()}", **self._mod)
        data = self.hdlc_transport.unwrap(resp)
        log.trace( f"Unwrapped payload = {data.hex().upper()}", **self._mod)

        response.extend(data)
        received_control = self.hdlc_transport.control
        # handle received response by control
        last_block = self.hdlc_transport.segmentation == 1
        send_rr = received_control.pf == 1
        if received_control.frame_type == FrameType.I:
            self._nr = (self._nr + 1) % 8
            while last_block:
                if send_rr:
                    # send RR frame
                    self.hdlc_transport.control = HDLCControl(FrameType.RR, nr=self._nr)
                    self.hdlc_transport.segmentation = 0
                    rr_frame = self.hdlc_transport.wrap(b'')
                    log.trace( f"TX RR -> {rr_frame.hex().upper()}", **self._mod)
                    self.lower.send(rr_frame)

                resp = self.lower.receive()
                if resp:
                    try:
                        log.trace( f"RX <- {resp.hex().upper()}", **self._mod)
                        data = self.hdlc_transport.unwrap(resp)
                        received_control = self.hdlc_transport.control
                        if received_control.frame_type == FrameType.I:
                            last_block = self.hdlc_transport.segmentation == 1
                            send_rr = received_control.pf == 1
                            response.extend(data)
                            self._nr = (self._nr + 1) % 8
                            log.trace(
                                f"Cont I: nr={self._nr} seg={'LAST' if last_block else 'MORE'} pf={received_control.pf}",
                                **self._mod,
                            )
                        else:

                            last_block = False
                            log.info( f"Received frame: {received_control.frame_type.name}", **self._mod
                            )
                    except:
                        send_rr = True
                        log.warning( "Invalid HDLC frame while receiving (continue).", **self._mod)
                else:
                    send_rr = True

        return response
