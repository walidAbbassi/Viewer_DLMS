import socket
import time
from typing import Optional

from ng_sdk.communication.abstract_communication import AbstractCommunication
from ng_sdk.configuration.config_manager import ConfigModuleProxy
from ng_sdk.constant.communication.constant import TIMEOUT, MAX_RETRIES, RETRY_DELAY
from ng_sdk.constant.logger.constant import LoggingConstants
from ng_sdk.error.communication_exception import CommunicationException, CommunicationError
from ng_sdk.logger.logger import get_logger
from ng_sdk.transport.tcp.tcp_transport import TCPUDPTransport

log = get_logger()
_mod = {LoggingConstants.MODULES_NAME: "TCPCommunication"}




class TCPCommunication(AbstractCommunication):
    _sock: Optional[socket.socket] = None
    def __init__(self, configuration: ConfigModuleProxy):
        super().__init__(configuration, TCPUDPTransport.is_complete)

        tcp_cfg = configuration.communication.tcp

        # Optional at construction time
        self.device_id: Optional[int] = None

        if hasattr(tcp_cfg, "device_id") and not isinstance(tcp_cfg.device_id, ConfigModuleProxy):
            self.device_id = int(tcp_cfg.device_id)

        # Association ID is always required for ZIV DLMS/TCP
        self.association_id = int(
            tcp_cfg.association_id
            if not isinstance(tcp_cfg.association_id, ConfigModuleProxy)
            else 1
        )

    def set_device_id(self, device_id: int):
        self.device_id = int(device_id)

    def _build_tcp_wrapper(self, apdu: bytes) -> bytes:
        """
        Build DLMS/TCP wrapper frame:
        | Version(2) | Source(2) | Dest(2) | Length(2) | DLMS-APDU |
        """

        version = 0x0001

        # Read IDs from config (must exist in json)
        device_id = int(self.configuration.communication.tcp.device_id)
        assoc_id = int(self.configuration.communication.tcp.association_id)

        # DC → BN direction (client → meter)
        # SDK always acts as DC
        source_port = assoc_id
        dest_port = device_id

        length = len(apdu)

        header = (
                version.to_bytes(2, "big") +
                source_port.to_bytes(2, "big") +
                dest_port.to_bytes(2, "big") +
                length.to_bytes(2, "big")
        )
        return header + apdu

    def _unwrap_tcp_frame(self, data: bytes) -> bytes:
        """
        Remove DLMS/TCP wrapper and return DLMS APDU only.
        """
        print("frmae unwrapped",data.hex().upper())
        if len(data) < 8:
            raise CommunicationException(CommunicationError.INVALID_TCP_FRAME)

        version = int.from_bytes(data[0:2], "big")
        if version != 1:
            log.warning(f"Unexpected DLMS/TCP version: {version}", _mod)

        apdu_length = int.from_bytes(data[6:8], "big")
        apdu = data[8:8 + apdu_length]

        return apdu

    def open(self):
        host = self.configuration.communication.tcp.host
        port = self.configuration.communication.tcp.port
        timeout = self.configuration.communication.tcp.timeout

        if isinstance(timeout, ConfigModuleProxy):
            timeout = TIMEOUT

        if host is None or isinstance(host, ConfigModuleProxy):
            log.error("Invalid TCP host", _mod)
            raise CommunicationException(CommunicationError.INVALID_HOST)

        if port is None or isinstance(port, ConfigModuleProxy) or not isinstance(port, int):
            log.error("Invalid TCP port", _mod)
            raise CommunicationException(CommunicationError.INVALID_TCP_PORT)

        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.settimeout(timeout)

        try:

            self._sock.connect((host, port))
        except socket.error as e:
            log.error(f"TCP connection failed: {e}", _mod)
            raise CommunicationException(CommunicationError.CONNECTION_FAILED)

        self.is_opened = True
        log.info(f"TCP connected to {host}:{port} (timeout {timeout})", _mod)


    def close(self):
        if self._sock:
            try:
                self._sock.close()
                log.info("TCP connection closed", _mod)
            except Exception:
                pass
        self.is_opened = False

    def transceive(self, frame: bytes) -> bytes:
        self.send(frame)
        return self.receive()

    def send(self, frame: bytes):

        log.info("  Send Frame: " + self._build_tcp_wrapper(frame).hex().upper(), _mod)
        if self._sock and self.is_opened:
            try:
                wrapped = self._build_tcp_wrapper(frame)
                self._sock.sendall(wrapped)
            except socket.error as e:
                log.error(f"TCP send error: {e}", _mod)
                raise CommunicationException(CommunicationError.SEND_ERROR)

    def receive(self) -> bytes:
        if not self.is_opened or self._sock is None:
            log.error("receive called while socket not opened", _mod)
            raise CommunicationException(CommunicationError.TCP_SOCKET_CLOSED)

        timeout = self.configuration.communication.tcp.timeout
        if isinstance(timeout, ConfigModuleProxy):
            timeout = TIMEOUT

        max_retries = self.configuration.communication.max_retries
        if isinstance(max_retries, ConfigModuleProxy):
            max_retries = MAX_RETRIES

        retry_delay = self.configuration.communication.retry_delay
        if isinstance(retry_delay, ConfigModuleProxy):
            retry_delay = RETRY_DELAY

        attempt = 0

        while True:
            attempt += 1
            buf = bytearray()
            start_time = last_byte = time.monotonic()
            absolute_deadline = start_time + timeout

            while True:
                try:
                    self._sock.settimeout(0.1)
                    chunk = self._sock.recv(2048)
                except socket.timeout:
                    chunk = b""

                if chunk:
                    buf += chunk
                    last_byte = time.monotonic()

                    if self.is_complete and self.is_complete(bytes(buf)):
                        log.info("  Receive Frame: " + buf.hex().upper(), _mod)
                        apdu = self._unwrap_tcp_frame(bytes(buf))
                        return apdu

                now = time.monotonic()

                if not buf and now >= absolute_deadline:
                    log.warning(f"Attempt {attempt}: no data received before timeout", _mod)
                    break

                if buf and (now - last_byte) >= timeout:
                    apdu = self._unwrap_tcp_frame(bytes(buf))
                    return apdu

                time.sleep(0.005)

            # Outer retry loop

            if attempt >= max_retries:
                log.error(
                    f"All {max_retries} attempts failed, meter not responding",
                    _mod,
                )
                if self._on_meter_unreachable:
                    self._on_meter_unreachable(max_retries)

                if not buf:
                    raise CommunicationException(CommunicationError.METER_NOT_RESPONDING)

                apdu = self._unwrap_tcp_frame(bytes(buf))
                if apdu and apdu[0] in (0x60, 0x61, 0xA1):
                    return apdu

                raise CommunicationException(CommunicationError.METER_NOT_RESPONDING)

            log.info(
                f"Retrying receive (attempt {attempt + 1}/{max_retries}) in {retry_delay}s",
                _mod,
            )
            if self._on_retry:
                self._on_retry(attempt + 1, max_retries)
            time.sleep(retry_delay)

    def _send_ziv_control(self, payload: bytes):
        """
        Send a ZIV custom control message (wrapped in DLMS/TCP header).
        """
        wrapped = self._build_tcp_wrapper(payload)
        log.info(f"Send ZIV control: {payload.hex().upper()}", _mod)
        self._sock.sendall(wrapped)